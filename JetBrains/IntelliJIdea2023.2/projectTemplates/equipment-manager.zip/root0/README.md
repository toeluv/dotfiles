\# Equipment-manager
Приложение является backend к проекту "Редактор элементов ЭЭС"

Swagger расположен по адресу:
```
http://{host}:{port}/swagger-ui.html
```
Дефолтный порт: 8310

SWAGGER не защищён OAuth и доступен без токена