//package ru.nti.dtps.equipmentmanager.scheme.validator
//
//import org.assertj.core.api.Assertions
//import org.junit.jupiter.api.Test
//import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
//import ru.nti.dtps.equipmentmanager.scheme.domain.validator.PrimitivePortNumberValidator
//import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
//import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
//import ru.nti.dtps.equipmentmanager.scheme.domain.XyCoords
//import java.util.*
//
//class PrimitivePortNumberValidatorTest {
//
//    private val primitivePortNumberValidator = PrimitivePortNumberValidator(10)
//    private val equipmentId = EquipmentId.from(UUID.randomUUID())
//
//    private val port_1ph = PrimitiveEquipment(
//        id = UUID.randomUUID().toString(),
//        name = "Single phase port",
//        type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH,
//        coords = XyCoords(),
//        dimensions = PrimitiveEquipment.Dimensions(),
//    )
//
//    private val port_3ph = PrimitiveEquipment(
//        id = UUID.randomUUID().toString(),
//        name = "Three phase port",
//        type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH,
//        coords = XyCoords(),
//        dimensions = PrimitiveEquipment.Dimensions()
//    )
//
//    private val scheme = Scheme(
//        id = equipmentId,
//        primitiveNodes = mutableMapOf(
//            port_1ph.id to port_1ph,
//            port_3ph.id to port_3ph,
//            UUID.randomUUID().toString() to port_1ph,
//            UUID.randomUUID().toString() to port_3ph
//        )
//    )
//
//    @Test
//    fun `success validate scheme with primitive port count less then 10`() {
//        val validateResult = primitivePortNumberValidator.validate(scheme)
//
//        Assertions.assertThat(validateResult.isRight()).isTrue()
//    }
//
//    @Test
//    fun `fail validate scheme with primitive port count more then 10`() {
//        val scheme = Scheme(
//            id = equipmentId,
//            primitiveNodes = mutableMapOf(
//                port_1ph.id to port_1ph,
//                port_3ph.id to port_3ph,
//                UUID.randomUUID().toString() to port_1ph,
//                UUID.randomUUID().toString() to port_1ph,
//                UUID.randomUUID().toString() to port_1ph,
//                UUID.randomUUID().toString() to port_1ph,
//                UUID.randomUUID().toString() to port_1ph,
//                UUID.randomUUID().toString() to port_3ph,
//                UUID.randomUUID().toString() to port_3ph,
//                UUID.randomUUID().toString() to port_3ph,
//                UUID.randomUUID().toString() to port_3ph
//            )
//        )
//
//        val validateResult = primitivePortNumberValidator.validate(scheme)
//
//        Assertions.assertThat(validateResult.isLeft()).isTrue()
//    }
//}