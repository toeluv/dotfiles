package ru.nti.dtps.equipmentmanager.scheme.builder

import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipmentLink
import java.util.*

class PrimitiveEquipmentLinkBuilder {

    companion object {

        fun buildTwoPortEquipmentLink(
            sourceEquipment: PrimitiveEquipment,
            targetEquipment: PrimitiveEquipment
        ) = PrimitiveEquipmentLink(
            id = UUID.randomUUID().toString(),
            source = sourceEquipment.id,
            target = targetEquipment.id,
            sourcePort = sourceEquipment.ports.last().id,
            targetPort = targetEquipment.ports.first().id
        )

        fun buildTwoSpecificPortEquipmentLink(
            sourceEquipment: PrimitiveEquipment,
            targetEquipment: PrimitiveEquipment,
            sourcePort: PrimitiveEquipment.Port,
            targetPort: PrimitiveEquipment.Port
        ) = PrimitiveEquipmentLink(
            id = UUID.randomUUID().toString(),
            source = sourceEquipment.id,
            target = targetEquipment.id,
            sourcePort = sourcePort.id,
            targetPort = targetPort.id
        )
    }
}