package ru.nti.dtps.equipmentmanager.scheme.validator

import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.IslandsValidator
import ru.nti.dtps.equipmentmanager.scheme.builder.SchemesForTest
import ru.nti.dtps.equipmentmanager.scheme.builder.addIslandToScheme

class IslandsValidatorTest {

    private val islandsValidator = IslandsValidator()

    @Test
    fun `validate scheme with single island containing emf, resistor, grounding and 1ph port`() {
        val scheme =
            SchemesForTest.buildValidSchemeWithEmfResistorGroundAndPort()
        assertTrue(islandsValidator.validate(scheme).isRight())
    }

    @Test
    fun `validate scheme with single island containing emf and resistor`() {
        val scheme =
            SchemesForTest.buildInvalidSchemeWithEmfAndResistor()
        assertTrue(islandsValidator.validate(scheme).isLeft())
    }

    @Test
    fun `validate scheme with single island containing emf, ground and resistor`() {
        val scheme =
            SchemesForTest.buildInvalidSchemeWithEmfResistorAndGround()
        assertTrue(islandsValidator.validate(scheme).isLeft())
    }

    @Test
    fun `validate scheme with two islands each containing emf, resistor, grounding and 1ph port`() {
        val validIsland = SchemesForTest.buildValidSchemeWithEmfResistorGroundAndPort()
        val scheme = SchemesForTest.buildValidSchemeWithEmfResistorGroundAndPort()
            .apply { this.addIslandToScheme(validIsland) }
        assertTrue(islandsValidator.validate(scheme).isRight())
    }

    @Test
    fun `validate scheme with two islands with one invalid (no ground and port)`() {
        val invalidIsland = SchemesForTest.buildInvalidSchemeWithEmfAndResistor()
        val scheme = SchemesForTest.buildValidSchemeWithEmfResistorGroundAndPort()
            .apply { this.addIslandToScheme(invalidIsland) }
        assertTrue(islandsValidator.validate(scheme).isLeft())
    }

    @Test
    fun `validate scheme with two islands with one invalid (no port)`() {
        val invalidIsland = SchemesForTest.buildInvalidSchemeWithEmfResistorAndGround()
        val scheme = SchemesForTest.buildValidSchemeWithEmfResistorGroundAndPort()
            .apply { this.addIslandToScheme(invalidIsland) }
        assertTrue(islandsValidator.validate(scheme).isLeft())
    }
}
