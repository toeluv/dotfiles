//package ru.nti.dtps.equipmentmanager.scheme.validator
//
//import org.assertj.core.api.Assertions
//import org.junit.jupiter.api.Test
//import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
//import ru.nti.dtps.equipmentmanager.scheme.domain.validator.LinkConnectingPortValidator
//import ru.nti.dtps.equipmentmanager.scheme.domain.*
//import java.util.*
//
//class LinkConnectingPortValidatorTest {
//
//    private val linkConnectingPortValidator = LinkConnectingPortValidator()
//    private val equipmentId = EquipmentId.from(UUID.randomUUID())
//
//    private val grounding = PrimitiveEquipment(
//        id = UUID.randomUUID().toString(),
//        name = "Grounding",
//        type = PrimitiveEquipment.PrimitiveEquipmentLibId.GROUNDING,
//        coords = XyCoords(),
//        dimensions = PrimitiveEquipment.Dimensions(),
//        ports = listOf(
//            PrimitiveEquipment.Port(
//                id = UUID.randomUUID().toString(),
//                libId = PortLibId.FIRST,
//                coords = XyCoords(),
//                alignment = Alignment.TOP
//            )
//        )
//    )
//
//    private val port_1ph = PrimitiveEquipment(
//        id = UUID.randomUUID().toString(),
//        name = "Single phase port",
//        type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH,
//        coords = XyCoords(),
//        dimensions = PrimitiveEquipment.Dimensions(),
//        ports = listOf(
//            PrimitiveEquipment.Port(
//                id = UUID.randomUUID().toString(),
//                libId = PortLibId.FIRST,
//                coords = XyCoords(),
//                alignment = Alignment.TOP
//            )
//        )
//    )
//
//    private val link = PrimitiveEquipmentLink(
//        id = UUID.randomUUID().toString(),
//        source = grounding.id,
//        target = port_1ph.id,
//        sourcePort = grounding.ports.first().id,
//        targetPort = port_1ph.ports.first().id
//    )
//
//    private val scheme = Scheme(
//        id = equipmentId,
//        primitiveNodes = mutableMapOf(
//            grounding.id to grounding,
//            port_1ph.id to port_1ph
//        ),
//        links = mutableMapOf(
//            link.id to link
//        )
//    )
//
//    @Test
//    fun `success validate scheme without empty ports`() {
//        val validateResult = linkConnectingPortValidator.validate(scheme)
//
//        Assertions.assertThat(validateResult.isRight()).isTrue()
//    }
//
//    @Test
//    fun `fail validate scheme with empty ports`() {
//        val scheme = Scheme(
//            id = equipmentId,
//            primitiveNodes = mutableMapOf(
//                grounding.id to grounding
//            ),
//            links = mutableMapOf()
//        )
//
//        val validateResult = linkConnectingPortValidator.validate(scheme)
//
//        Assertions.assertThat(validateResult.isLeft()).isTrue()
//    }
//}