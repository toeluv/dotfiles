//package ru.nti.dtps.equipmentmanager.scheme.validator
//
//import org.apache.commons.lang3.StringUtils
//import org.assertj.core.api.Assertions
//import org.junit.jupiter.api.Test
//import ru.nti.dtps.equipmentmanager.scheme.domain.OptionLibId
//import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
//import ru.nti.dtps.equipmentmanager.scheme.domain.XyCoords
//import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoProvider
//import ru.nti.dtps.equipmentmanager.scheme.domain.validator.BasicNodeValidator
//import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.*
//import java.util.*
//import java.util.regex.Pattern
//
//class RequiredOptionsValidatorTest {
//
//    private val libInfoProvider = LibInfoProvider()
//
//    @Test
//    fun `emf source options field values are valid`() {
//        val emfSource = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "EMF source",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.EMF_SOURCE,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = mutableMapOf(
//                OptionLibId.VARIABLE_NAME to "test",
//                OptionLibId.RESISTANCE to "1.0",
//                OptionLibId.EMF_VALUE to "1.0",
//                OptionLibId.MUTUALITY to null
//            )
//        )
//
//        val validateResult = BasicNodeValidator.validateNode(emfSource, libInfoProvider)
//
//        Assertions.assertThat(validateResult.isRight()).isTrue()
//    }
//
//    @Test
//    fun `grounding with empty options valid`() {
//        val grounding = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "Grounding",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.GROUNDING,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions()
//        )
//
//        val validateResult = BasicNodeValidator.validateNode(grounding, libInfoProvider)
//
//        Assertions.assertThat(validateResult.isRight()).isTrue()
//    }
//
//    @Test
//    fun `primitive equipment has not name`() {
//        val grounding = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.GROUNDING,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions()
//        )
//
//        val validateResult = BasicNodeValidator.validateNode(grounding, libInfoProvider)
//
//        Assertions
//            .assertThat(validateResult.leftOrNull())
//            .isInstanceOf(PrimitiveEquipmentDoesNotHaveName::class.java)
//    }
//
//    @Test
//    fun `equipment has unexpected options`() {
//        val grounding = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "Grounding",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.GROUNDING,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = mutableMapOf(
//                OptionLibId.MUTUALITY to ""
//            )
//        )
//
//        Assertions
//            .assertThatExceptionOfType(IllegalArgumentException::class.java)
//            .isThrownBy {
//                BasicNodeValidator.validateNode(grounding, libInfoProvider)
//            }.withMessageContaining("contains unexpected option(-s)")
//    }
//
//    @Test
//    fun `option does not have value`() {
//        val emfSource = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "EMF source",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.EMF_SOURCE,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = mutableMapOf(
//                OptionLibId.VARIABLE_NAME to "test",
//                OptionLibId.RESISTANCE to "",
//                OptionLibId.EMF_VALUE to "1.0",
//                OptionLibId.MUTUALITY to "123"
//            )
//        )
//
//        val validateResult = BasicNodeValidator.validateNode(emfSource, libInfoProvider)
//
//        Assertions
//            .assertThat(validateResult.leftOrNull())
//            .isInstanceOf(RequiredFieldNotFoundError::class.java)
//    }
//
//    @Test
//    fun `number option value more then limit`() {
//        val emfSource = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "EMF source",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.EMF_SOURCE,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = mutableMapOf(
//                OptionLibId.VARIABLE_NAME to "test",
//                OptionLibId.RESISTANCE to "4.402823466e38",
//                OptionLibId.EMF_VALUE to "1.0",
//                OptionLibId.MUTUALITY to "123"
//            )
//        )
//
//        val validateResult = BasicNodeValidator.validateNode(emfSource, libInfoProvider)
//
//        Assertions
//            .assertThat(validateResult.leftOrNull())
//            .isInstanceOf(FieldValueMoreThenLimitValueError::class.java)
//    }
//
//    @Test
//    fun `number option value less then limit`() {
//        val emfSource = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "EMF source",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.EMF_SOURCE,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = mutableMapOf(
//                OptionLibId.VARIABLE_NAME to "test",
//                OptionLibId.RESISTANCE to "1.0",
//                OptionLibId.EMF_VALUE to "-1.0",
//                OptionLibId.MUTUALITY to "123"
//            )
//        )
//
//        val validateResult = BasicNodeValidator.validateNode(emfSource, libInfoProvider)
//
//        Assertions
//            .assertThat(validateResult.leftOrNull())
//            .isInstanceOf(FieldValueLessThenLimitValueError::class.java)
//    }
//
//    @Test
//    fun `text option value more then limit`() {
//        val emfSource = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "EMF source",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.EMF_SOURCE,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = mutableMapOf(
//                OptionLibId.VARIABLE_NAME to StringUtils.repeat("test", 20),
//                OptionLibId.RESISTANCE to "1.0",
//                OptionLibId.EMF_VALUE to "-1.0",
//                OptionLibId.MUTUALITY to "123"
//            )
//        )
//
//        val validateResult = BasicNodeValidator.validateNode(emfSource, libInfoProvider)
//
//        Assertions
//            .assertThat(validateResult.leftOrNull())
//            .isInstanceOf(TextFieldLengthMoreThenMaxValueError::class.java)
//    }
//
//    @Test
//    fun `regex from json is valid`() {
//        val regexFromJson = libInfoProvider.getEquipmentLibById(PrimitiveEquipment.PrimitiveEquipmentLibId.CURRENT_SOURCE)
//            .options
//            .first { it.id == OptionLibId.VARIABLE_NAME }
//            .regex!!
//        val validateResult = Pattern
//            .compile(regexFromJson, Pattern.CASE_INSENSITIVE)
//            .matcher("name").matches()
//
//        Assertions.assertThat(validateResult).isTrue()
//    }
//
//    @Test
//    fun `text option start with number and not valid by regex`() {
//        val emfSource = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "EMF source",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.EMF_SOURCE,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = mutableMapOf(
//                OptionLibId.VARIABLE_NAME to "12test",
//                OptionLibId.RESISTANCE to "1.0",
//                OptionLibId.EMF_VALUE to "-1.0",
//                OptionLibId.MUTUALITY to "123"
//            )
//        )
//
//        Assertions
//            .assertThatExceptionOfType(IllegalArgumentException::class.java)
//            .isThrownBy {
//                BasicNodeValidator.validateNode(emfSource, libInfoProvider)
//            }.withMessageContaining("doesn't match pattern")
//    }
//}