//package ru.nti.dtps.equipmentmanager.scheme.validator
//
//import org.assertj.core.api.Assertions
//import org.junit.jupiter.api.Test
//import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
//import ru.nti.dtps.equipmentmanager.scheme.domain.*
//import ru.nti.dtps.equipmentmanager.scheme.domain.validator.RequiredEquipmentsValidator
//import java.util.*
//
//class RequiredEquipmentsValidatorTest {
//
//    private val requiredEquipmentsValidator = RequiredEquipmentsValidator()
//    private val equipmentId = EquipmentId.from(UUID.randomUUID())
//
//    private val grounding = PrimitiveEquipment(
//        id = UUID.randomUUID().toString(),
//        name = "Grounding",
//        type = PrimitiveEquipment.PrimitiveEquipmentLibId.GROUNDING,
//        coords = XyCoords(),
//        dimensions = PrimitiveEquipment.Dimensions(),
//        ports = listOf(
//            PrimitiveEquipment.Port(
//                id = UUID.randomUUID().toString(),
//                libId = PortLibId.FIRST,
//                coords = XyCoords(),
//                alignment = Alignment.TOP
//            )
//        )
//    )
//
//    private val port_1ph = PrimitiveEquipment(
//        id = UUID.randomUUID().toString(),
//        name = "Single phase port",
//        type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH,
//        coords = XyCoords(),
//        dimensions = PrimitiveEquipment.Dimensions(),
//        ports = listOf(
//            PrimitiveEquipment.Port(
//                id = UUID.randomUUID().toString(),
//                libId = PortLibId.FIRST,
//                coords = XyCoords(),
//                alignment = Alignment.TOP
//            )
//        )
//    )
//
//    private val scheme = Scheme(
//        id = equipmentId,
//        primitiveNodes = mutableMapOf(
//            grounding.id to grounding,
//            port_1ph.id to port_1ph
//        )
//    )
//
//    @Test
//    fun `success validate scheme with all required equipments`() {
//        val validateResult = requiredEquipmentsValidator.validate(scheme)
//
//        Assertions.assertThat(validateResult.isRight()).isTrue()
//    }
//
//    @Test
//    fun `fail validate scheme without all required equipments`() {
//        val scheme = Scheme(
//            id = equipmentId,
//            primitiveNodes = mutableMapOf(
//                port_1ph.id to port_1ph
//            )
//        )
//        val validateResult = requiredEquipmentsValidator.validate(scheme)
//
//        Assertions.assertThat(validateResult.isLeft()).isTrue()
//    }
//}