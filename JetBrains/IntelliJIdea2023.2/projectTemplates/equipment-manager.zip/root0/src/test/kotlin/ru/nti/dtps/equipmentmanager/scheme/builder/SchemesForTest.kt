package ru.nti.dtps.equipmentmanager.scheme.builder

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.domain.OptionLibId
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipmentLink
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import java.util.*

class SchemesForTest {

    companion object {

        fun buildInvalidSchemeWithEmfAndResistor(): Scheme {
            val equipmentId = EquipmentId.from(UUID.randomUUID())
            val emfSource = PrimitiveEquipmentBuilder.buildEmfSource()
            val resistor = PrimitiveEquipmentBuilder.buildResistor()
            val emfResistorLink = PrimitiveEquipmentLinkBuilder.buildTwoPortEquipmentLink(emfSource, resistor)
            val resistorEmfLink = PrimitiveEquipmentLinkBuilder.buildTwoPortEquipmentLink(resistor, emfSource)
            return Scheme(
                id = equipmentId,
                primitiveNodes = mutableMapOf(
                    emfSource.id to emfSource,
                    resistor.id to resistor,
                ),
                links = mutableMapOf(
                    emfResistorLink.id to emfResistorLink,
                    resistorEmfLink.id to resistorEmfLink,
                ),
                version = 0L
            )
        }

        fun buildValidSchemeWithEmfResistorGroundAndPort(): Scheme {
            val equipmentId = EquipmentId.from(UUID.randomUUID())
            val emfSource = PrimitiveEquipmentBuilder.buildEmfSource()
            val resistor = PrimitiveEquipmentBuilder.buildResistor()
            val grounding = PrimitiveEquipmentBuilder.buildGrounding()
            val connectivityEmfPortResistor = PrimitiveEquipmentBuilder.buildConnectivity()
            val connectivityResistorGroundEmf = PrimitiveEquipmentBuilder.buildConnectivity()
            val port1ph = PrimitiveEquipmentBuilder.buildSinglePhasePort()

            val emfConnectivityLink = PrimitiveEquipmentLink(
                id = UUID.randomUUID().toString(),
                source = emfSource.id,
                target = connectivityEmfPortResistor.id,
                sourcePort = emfSource.ports.last().id,
                targetPort = connectivityEmfPortResistor.ports.first().id
            )
            val portConnectivityLink = PrimitiveEquipmentLink(
                id = UUID.randomUUID().toString(),
                source = port1ph.id,
                target = connectivityEmfPortResistor.id,
                sourcePort = port1ph.ports.first().id,
                targetPort = connectivityEmfPortResistor.ports[1].id
            )
            val connectivityResistorLink = PrimitiveEquipmentLink(
                id = UUID.randomUUID().toString(),
                source = connectivityEmfPortResistor.id,
                target = resistor.id,
                sourcePort = connectivityEmfPortResistor.ports.last().id,
                targetPort = resistor.ports.first().id
            )
            val resistorConnectivityLink = PrimitiveEquipmentLink(
                id = UUID.randomUUID().toString(),
                source = resistor.id,
                target = connectivityResistorGroundEmf.id,
                sourcePort = resistor.ports.last().id,
                targetPort = connectivityResistorGroundEmf.ports.last().id
            )
            val groundingConnectivityLink = PrimitiveEquipmentLink(
                id = UUID.randomUUID().toString(),
                source = grounding.id,
                target = connectivityResistorGroundEmf.id,
                sourcePort = grounding.ports.first().id,
                targetPort = connectivityResistorGroundEmf.ports[1].id
            )
            val connectivityEmfLink = PrimitiveEquipmentLink(
                id = UUID.randomUUID().toString(),
                source = connectivityResistorGroundEmf.id,
                target = emfSource.id,
                sourcePort = connectivityResistorGroundEmf.ports.first().id,
                targetPort = emfSource.ports.first().id
            )

            return Scheme(
                id = equipmentId,
                primitiveNodes = mutableMapOf(
                    emfSource.id to emfSource,
                    resistor.id to resistor,
                    grounding.id to grounding,
                    port1ph.id to port1ph,
                    connectivityEmfPortResistor.id to connectivityEmfPortResistor,
                    connectivityResistorGroundEmf.id to connectivityResistorGroundEmf,
                ),
                links = mutableMapOf(
                    emfConnectivityLink.id to emfConnectivityLink,
                    portConnectivityLink.id to portConnectivityLink,
                    connectivityResistorLink.id to connectivityResistorLink,
                    resistorConnectivityLink.id to resistorConnectivityLink,
                    groundingConnectivityLink.id to groundingConnectivityLink,
                    connectivityEmfLink.id to connectivityEmfLink,
                ),
                version = 0L

            )
        }

        fun buildInvalidSchemeWithEmfResistorAndGround(): Scheme {
            val equipmentId = EquipmentId.from(UUID.randomUUID())
            val emfSource = PrimitiveEquipmentBuilder.buildEmfSource()
            val resistor = PrimitiveEquipmentBuilder.buildResistor()
            val grounding = PrimitiveEquipmentBuilder.buildGrounding()
            val connectivityResistorGroundEmf = PrimitiveEquipmentBuilder.buildConnectivity()

            val emfResistorLink = PrimitiveEquipmentLinkBuilder.buildTwoPortEquipmentLink(emfSource, resistor)

            val resistorConnectivityLink = PrimitiveEquipmentLink(
                id = UUID.randomUUID().toString(),
                source = resistor.id,
                target = connectivityResistorGroundEmf.id,
                sourcePort = resistor.ports.last().id,
                targetPort = connectivityResistorGroundEmf.ports.last().id
            )
            val groundingConnectivityLink = PrimitiveEquipmentLink(
                id = UUID.randomUUID().toString(),
                source = grounding.id,
                target = connectivityResistorGroundEmf.id,
                sourcePort = grounding.ports.first().id,
                targetPort = connectivityResistorGroundEmf.ports[1].id
            )
            val connectivityEmfLink = PrimitiveEquipmentLink(
                id = UUID.randomUUID().toString(),
                source = connectivityResistorGroundEmf.id,
                target = emfSource.id,
                sourcePort = connectivityResistorGroundEmf.ports.first().id,
                targetPort = emfSource.ports.first().id
            )

            return Scheme(
                id = equipmentId,
                primitiveNodes = mutableMapOf(
                    emfSource.id to emfSource,
                    resistor.id to resistor,
                    grounding.id to grounding,
                    connectivityResistorGroundEmf.id to connectivityResistorGroundEmf,
                ),
                links = mutableMapOf(
                    emfResistorLink.id to emfResistorLink,
                    resistorConnectivityLink.id to resistorConnectivityLink,
                    groundingConnectivityLink.id to groundingConnectivityLink,
                    connectivityEmfLink.id to connectivityEmfLink,
                ),
                version = 0L
            )
        }

        fun buildValidSchemeWithAllTypesPrimitiveEquipment(): Scheme {
            val equipmentId = EquipmentId.from(UUID.randomUUID())
            val currentSource = PrimitiveEquipmentBuilder.buildCurrentSource().apply {
                this.options[OptionLibId.VARIABLE_NAME] = "current2"

            }
            val mutualCurrentSource = PrimitiveEquipmentBuilder.buildCurrentSource().apply {
                this.options[OptionLibId.VARIABLE_NAME] = "current1"
                this.options[OptionLibId.MUTUALITY] = currentSource.id
            }
            currentSource.apply { this.options[OptionLibId.MUTUALITY] = mutualCurrentSource.id }
            val emfSource = PrimitiveEquipmentBuilder.buildEmfSource().apply {
                this.options[OptionLibId.VARIABLE_NAME] = "emf"
            }
            val grounding = PrimitiveEquipmentBuilder.buildGrounding()
            val idealTransformer = PrimitiveEquipmentBuilder.buildIdealTransformer().apply {
                this.options[OptionLibId.VARIABLE_NAME] = "transformer"
            }
            val inductanceCoil = PrimitiveEquipmentBuilder.buildInductanceCoil().apply {
                this.options[OptionLibId.VARIABLE_NAME] = "inductance"
            }
            val capacitor = PrimitiveEquipmentBuilder.buildCapacitor().apply {
                this.options[OptionLibId.VARIABLE_NAME] = "capacitor"
            }
            val resistor = PrimitiveEquipmentBuilder.buildResistor().apply {
                this.options[OptionLibId.VARIABLE_NAME] = "resistor"
            }
            val port3Ph = PrimitiveEquipmentBuilder.buildThreePhasePort()
            val port1Ph = PrimitiveEquipmentBuilder.buildSinglePhasePort()
            val connectivity = PrimitiveEquipmentBuilder.buildConnectivity()

            val groundingInductanceLink =
                PrimitiveEquipmentLinkBuilder.buildTwoPortEquipmentLink(grounding, inductanceCoil)
            val inductanceCurrentSourceLink =
                PrimitiveEquipmentLinkBuilder.buildTwoPortEquipmentLink(inductanceCoil, currentSource)
            val currentSourceTransformerLink = PrimitiveEquipmentLinkBuilder
                .buildTwoSpecificPortEquipmentLink(
                    currentSource,
                    idealTransformer,
                    currentSource.ports.last(),
                    idealTransformer.ports[0]
                )
            val transformerPort1PhLink = PrimitiveEquipmentLinkBuilder
                .buildTwoSpecificPortEquipmentLink(
                    idealTransformer,
                    port1Ph,
                    idealTransformer.ports[1],
                    port1Ph.ports.first()
                )
            val transformerResistorLink = PrimitiveEquipmentLinkBuilder
                .buildTwoSpecificPortEquipmentLink(
                    idealTransformer,
                    resistor,
                    idealTransformer.ports[2],
                    resistor.ports.first()
                )
            val resistorPort3PhLink = PrimitiveEquipmentLinkBuilder
                .buildTwoSpecificPortEquipmentLink(
                    resistor,
                    port3Ph,
                    resistor.ports.last(),
                    port3Ph.ports[0]
                )
            val port3PhConnectivityLink = PrimitiveEquipmentLinkBuilder
                .buildTwoSpecificPortEquipmentLink(
                    port3Ph,
                    connectivity,
                    port3Ph.ports[1],
                    connectivity.ports[0]
                )
            val port3PhEmfSourceLink = PrimitiveEquipmentLinkBuilder
                .buildTwoSpecificPortEquipmentLink(
                    port3Ph,
                    emfSource,
                    port3Ph.ports[2],
                    emfSource.ports.first()
                )
            val emfSourceConnectivityLink = PrimitiveEquipmentLinkBuilder
                .buildTwoSpecificPortEquipmentLink(
                    emfSource,
                    connectivity,
                    emfSource.ports.last(),
                    connectivity.ports[1]
                )
            val connectivityCapacitorLink = PrimitiveEquipmentLinkBuilder
                .buildTwoSpecificPortEquipmentLink(
                    connectivity,
                    capacitor,
                    connectivity.ports[2],
                    capacitor.ports.first()
                )
            val capacitorTransformerLink = PrimitiveEquipmentLinkBuilder
                .buildTwoSpecificPortEquipmentLink(
                    capacitor,
                    idealTransformer,
                    capacitor.ports.last(),
                    idealTransformer.ports[3]
                )

            return Scheme(
                id = equipmentId,
                primitiveNodes = mutableMapOf(
                    currentSource.id to currentSource,
                    mutualCurrentSource.id to mutualCurrentSource,
                    emfSource.id to emfSource,
                    grounding.id to grounding,
                    idealTransformer.id to idealTransformer,
                    inductanceCoil.id to inductanceCoil,
                    capacitor.id to capacitor,
                    resistor.id to resistor,
                    port1Ph.id to port1Ph,
                    port3Ph.id to port3Ph,
                    connectivity.id to connectivity
                ),
                links = mutableMapOf(
                    groundingInductanceLink.id to groundingInductanceLink,
                    inductanceCurrentSourceLink.id to inductanceCurrentSourceLink,
                    currentSourceTransformerLink.id to currentSourceTransformerLink,
                    transformerPort1PhLink.id to transformerPort1PhLink,
                    transformerResistorLink.id to transformerResistorLink,
                    resistorPort3PhLink.id to resistorPort3PhLink,
                    port3PhConnectivityLink.id to port3PhConnectivityLink,
                    port3PhEmfSourceLink.id to port3PhEmfSourceLink,
                    emfSourceConnectivityLink.id to emfSourceConnectivityLink,
                    connectivityCapacitorLink.id to connectivityCapacitorLink,
                    capacitorTransformerLink.id to capacitorTransformerLink
                ),
                version = 0L
            )
        }
    }
}

fun Scheme.addIslandToScheme(island: Scheme) = this.apply {
    this.primitiveNodes.putAll(island.primitiveNodes)
    this.links.putAll(island.links)
}