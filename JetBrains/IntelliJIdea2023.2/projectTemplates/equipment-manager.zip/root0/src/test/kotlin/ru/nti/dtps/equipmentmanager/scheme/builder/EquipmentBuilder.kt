//package ru.nti.dtps.equipmentmanager.scheme.builder
//
//import arrow.core.getOrElse
//import ru.nti.dtps.equipmentmanager.common.types.*
//import ru.nti.dtps.equipmentmanager.equipment.domain.*
//import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
//import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
//import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
//import ru.nti.dtps.equipmentmanager.variable.domain.UserVariable
//import java.time.Instant
//import java.util.*
//
//class EquipmentBuilder {
//
//    companion object {
//
//        val equipmentId = EquipmentId.from(UUID.randomUUID())
//
//        private fun createMeasurement() = OutputSignal(
//            id = OutputSignalId.from(UUID.randomUUID()),
//            name = OutputSignalName.from("Test measurement").getOrElse { error("invalid measurement name") },
//            unitType = UnitType.AMPERE,
//            dataType = DataType.FLOAT,
//            equipmentId = equipmentId,
//            variableName = VariableName.from("test_measurement")
//                .getOrElse { error("invalid variable name") }
//        )
//
//        private fun createControl() = InputSignal(
//            id = InputSignalId.from(UUID.randomUUID()),
//            name = InputSignalName.from("Test control").getOrElse { error("invalid control name") },
//            unitType = UnitType.AMPERE,
//            dataType = DataType.FLOAT,
//            equipmentId = equipmentId,
//            variableName = VariableName.from("test_control")
//                .getOrElse { error("invalid variable name") }
//        )
//
//        private fun createOption() = Parameter(
//            id = ParameterId.from(UUID.randomUUID()),
//            equipmentId = EquipmentId.from(UUID.randomUUID()),
//            groupId = UUID.randomUUID().toString(),
//            name = ParameterName.from("Test option").getOrElse { error("invalid option name") },
//            unitType = UnitType.AMPERE,
//            dataType = DataType.FLOAT,
//            minValue = "0.0",
//            defaultValue = "4.0",
//            maxValue = "10.0",
//            variableName = VariableName.from("test_option").getOrElse { error("invalid variable name") }
//        )
//        private fun createUserVariable() = UserVariable(
//            id = VariableId.from(UUID.randomUUID()),
//            variableName = VariableName.from("test_user_variable").getOrElse { error("invalid variable name") },
//            dataType = DataType.FLOAT,
//            equipmentId = equipmentId,
//        )
//
//        fun createEquipment() = EquipmentFullView.restore(
//            EquipmentId.from(UUID.randomUUID()),
//            CompanyId.from(UUID.randomUUID()),
//            EquipmentName("Test equipment"),
//            null,
//            null,
//            "test",
//            Instant.now(),
//            setOf(createOption(), createOption(), createOption()),
//            setOf(createControl(), createControl(), createControl()),
//            setOf(createMeasurement(), createMeasurement(), createMeasurement()),
//            setOf(createUserVariable(), createUserVariable(), createUserVariable()),
//            false,
//            null,
//            0L,
//            null,
//            null,
//        )
//
//    }
//}