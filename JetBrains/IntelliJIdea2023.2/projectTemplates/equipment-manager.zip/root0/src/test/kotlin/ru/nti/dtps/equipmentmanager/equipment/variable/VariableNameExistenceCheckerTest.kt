package ru.nti.dtps.equipmentmanager.equipment.variable

import arrow.core.getOrElse
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.testcontainers.junit.jupiter.Testcontainers
import ru.nti.dtps.equipmentmanager.common.types.DataType
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserVariableId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.equipment.config.PostgreSQLTestContainerConfig
import ru.nti.dtps.equipmentmanager.equipment.usecase.access.CheckVariableNameAlreadyExists
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable
import ru.nti.dtps.equipmentmanager.userVariable.persist.UserVariableRepository
import java.util.*
import javax.sql.DataSource

private val EXISTING_USER_VARIABLE_NAME = VariableName.from("user_variable").getOrElse { error("") }

private val EXISTING_INPUT_VARIABLE_NAME = VariableName.from("input_variable").getOrElse { error("") }

private val EXISTING_EQUIPMENT_ID = EquipmentId.from("123e4567-e89b-12d3-a456-426614174000").getOrElse { error("") }

private val EXISTING_USER_VARIABLE_ID = UserVariableId.from("123e4567-e89b-12d3-a456-426614174001").getOrElse { error("") }

@Testcontainers
@SpringBootTest(classes = [PostgreSQLTestContainerConfig::class])
class VariableNameExistenceCheckerTest @Autowired constructor(
    dataSource: DataSource
) : PostgreSQLTestContainerConfig() {

    private val userVariablePersister = UserVariableRepository(dataSource)

    private val variableNameAlreadyExists = CheckVariableNameAlreadyExists(dataSource)

    private val userVariableToCreate = UserVariable.create(
        UserVariableId.from(UUID.randomUUID()),
        EXISTING_EQUIPMENT_ID,
        VariableName.from("new_user_variable").getOrElse { error("") },
        DataType.BOOLEAN
    )

    private val userVariableToUpdate = UserVariable.create(
        EXISTING_USER_VARIABLE_ID,
        EXISTING_EQUIPMENT_ID,
        EXISTING_USER_VARIABLE_NAME,
        DataType.BOOLEAN
    )

    @Test
    fun `check that pre-created variables are exist`() {
        assertThat(variableNameAlreadyExists(EXISTING_USER_VARIABLE_NAME, EXISTING_EQUIPMENT_ID)).isTrue()

        assertThat(variableNameAlreadyExists(EXISTING_INPUT_VARIABLE_NAME, EXISTING_EQUIPMENT_ID)).isTrue()
    }

    @Test
    fun `check before and after attempt to create new instance`() {
        assertThat(
            variableNameAlreadyExists(userVariableToCreate.variableName, userVariableToCreate.equipmentId)
        ).isFalse()

        userVariablePersister.save(userVariableToCreate)

        assertThat(
            variableNameAlreadyExists(userVariableToCreate.variableName, userVariableToCreate.equipmentId)
        ).isTrue()
    }

    @Test
    fun `check before and after attempt to update existing instance`() {
        assertThat(
            variableNameAlreadyExists(
                userVariableToUpdate.variableName,
                userVariableToUpdate.equipmentId, userVariableToUpdate.id.toUUID()
            )
        ).isFalse()

        userVariablePersister.update(userVariableToUpdate)

        assertThat(
            variableNameAlreadyExists(userVariableToUpdate.variableName, userVariableToUpdate.equipmentId)
        ).isTrue()
    }
}