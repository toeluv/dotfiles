package ru.nti.dtps.equipmentmanager.kafka

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import ru.nti.dtps.equipment.meta.info.dataclass.equipment.port.Port
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.types.ParameterName
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentFullView
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.kafka.EquipmentEventConverter
import ru.nti.dtps.equipmentmanager.equipment.kafka.EquipmentEventType
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalNameAlreadyExists
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalNameAlreadyExists
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import ru.nti.dtps.equipmentmanager.scheme.domain.Alignment
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.isPrimitivePort
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoProvider
import ru.nti.dtps.equipmentmanager.svg.domain.*
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SignalInfoDto
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgDto
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgInfoDto
import java.time.Instant
import java.util.*

class EquipmentEventConverterTest {

    private val equipmentMeasurementId = UUID.randomUUID()
    private val portMeasurementId = UUID.randomUUID()
    private val port3PhId = UUID.randomUUID()
    private val parameterGroupId = UUID.randomUUID().toString()
    private val equipmentId = EquipmentId.from(UUID.randomUUID())
    private val companyId = CompanyId.from(UUID.randomUUID())

    private val libInfoProvider = LibInfoProvider()
    object InputSignalNameAlreadyExistsImpl : InputSignalNameAlreadyExists {
        override operator fun invoke(name: InputSignalName, equipmentId: EquipmentId): Boolean {
            return false
        }

        override operator fun invoke(id: InputSignalId, name: InputSignalName, equipmentId: EquipmentId): Boolean {
            return false
        }
    }

    object OutputSignalNameAlreadyExistsImpl : OutputSignalNameAlreadyExists {
        override fun invoke(name: OutputSignalName, equipmentId: EquipmentId): Boolean {
            return false
        }

        override fun invoke(id: OutputSignalId, name: OutputSignalName, equipmentId: EquipmentId): Boolean {
            return false
        }
    }

    private val equipmentFullView = EquipmentFullView.restore(
        equipmentId,
        companyId,
        EquipmentName("Test equipment"),
        groupId = null,
        description = null,
        author = "bond",
        createdAt = Instant.now(),
        parameters = setOf(
            Parameter(
                ParameterId(UUID.randomUUID()),
                equipmentId,
                ParameterName("Test option"),
                groupId = UUID.randomUUID().toString(),
                UnitType.AMPERE,
                DataType.FLOAT,
                minValue = "0.0",
                maxValue = "10.0",
                defaultValue = "1.0",
                VariableName("Current")
            ),
            Parameter(
                ParameterId(UUID.randomUUID()),
                equipmentId,
                ParameterName("Test option 2"),
                groupId = parameterGroupId,
                UnitType.AMPERE,
                DataType.FLOAT,
                minValue = "0.0",
                maxValue = "10.0",
                defaultValue = "1.0",
                VariableName("Current A")
            )
        ),
        inputSignals = setOf(
            InputSignal.create(
                InputSignalId(UUID.randomUUID()),
                equipmentId,
                InputSignalName("Current value"),
                UnitType.AMPERE,
                DataType.FLOAT,
                VariableName("Current_control"),
                InputSignalNameAlreadyExistsImpl
            ).getOrNull()!!
        ),
        outputSignals = setOf(
            OutputSignal.create(
                OutputSignalId.from(equipmentMeasurementId),
                equipmentId,
                OutputSignalName("Current value"),
                UnitType.AMPERE,
                DataType.FLOAT,
                VariableName("Current_measurement"),
                OutputSignalNameAlreadyExistsImpl
            ).getOrNull()!!,
            OutputSignal.create(
                OutputSignalId.from(UUID.randomUUID()),
                equipmentId,
                OutputSignalName("Current value per metre"),
                UnitType.AMPERE_PER_METRE,
                DataType.FLOAT,
                VariableName("Current_meas"),
                OutputSignalNameAlreadyExistsImpl
            ).getOrNull()!!
        ),
        published = false,
        publicationInfo = null,
        version = 0,
        editor = null,
        updatedAt = null,
        userVariables = setOf()
    )

    private val svg = SvgDto.create(equipmentId.toUUID())

    private val svgInfo = SvgInfoDto.restore(
        equipmentId.toUUID(),
        coords = XyCoords(),
        dimensions = Dimensions(),
        hour = 1,
        ports = listOf(
            SvgPort.create(
                id = port3PhId,
                libId = "FIRST",
                XyCoords(),
                Alignment.TOP,
                hour = 1
            ),
            SvgPort.create(
                id = portMeasurementId,
                libId = "SECOND",
                XyCoords(),
                Alignment.BOTTOM,
                hour = 1
            )
        ),
        placeholders = listOf(
            Placeholder.create(
                id = UUID.randomUUID(),
                XyCoords(),
                hour = 1,
                mutableListOf(
                    equipmentMeasurementId.toString(),
                    portMeasurementId.toString()
                )
            ).getOrNull()!!
        )
    )

    private val parameterGroups = listOf(
        ParameterGroup.create(
            id = parameterGroupId,
            equipmentId.toStringValue(),
            name = "Коммуникацонные"
        )
    )

    private val scheme = Scheme.restore(
        equipmentId,

        mutableMapOf(
            portMeasurementId.toString() to PrimitiveEquipment(
                id = portMeasurementId.toString(),
                name = "Port 1Ph",
                type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH,
                coords = ru.nti.dtps.equipmentmanager.scheme.domain.XyCoords(),
                dimensions = PrimitiveEquipment.Dimensions(),
                payload = ""
            ),
            port3PhId.toString() to PrimitiveEquipment(
                id = port3PhId.toString(),
                name = "Port 3Ph",
                type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH,
                coords = ru.nti.dtps.equipmentmanager.scheme.domain.XyCoords(),
                dimensions = PrimitiveEquipment.Dimensions(),
                payload = ""
            )
        ),
        mutableMapOf(),
        0,
        mutableListOf(),
        true
    )

    private val signalInfo = SignalInfoDto.restore(
        equipmentId.toUUID(),
        signalsFromMeas = equipmentFullView.outputSignals.map { it.toSignalView() },
        signalsFromScheme = scheme.primitiveNodes.values
            .filter {
                it.type.isPrimitivePort()
            }.flatMap {
                SignalInfo.buildSignalsForPrimitivePort(it.id, libInfoProvider)
            }
    )

    @Test
    fun `convert all equipment info to kafka event`() {
        val result = EquipmentEventConverter.toEvent(
            equipmentFullView, svg, svgInfo, signalInfo, parameterGroups, scheme
        ).getOrNull()

        assertThat(result!!.eventType).isEqualTo(EquipmentEventType.UPDATE)
        assertThat(result.version).isEqualTo(1)
        assertThat(result.equipmentLib!!.fields.filter { it.groupId == parameterGroupId }.size).isEqualTo(1)
        assertThat(result.equipmentLib!!.fields.filter { it.groupId == "COMMON" }.size).isEqualTo(1)
        assertThat(result.equipmentLib!!.measurements.size).isEqualTo(
            libInfoProvider.getPrimitivePortSignalInfo().size *
                scheme.primitiveNodes.values.filter { it.type.isPrimitivePort() }.size +
                equipmentFullView.outputSignals.size
        )
        assertThat(result.equipmentLib!!.measurements.filter { it.show.onScheme }.size).isEqualTo(1)
        assertThat(result.equipmentLib!!.measurements.filter { it.show.inModal }.size).isEqualTo(0)
        assertThat(result.equipmentLib!!.ports.map { it.phases }).containsAll(Port.Phases.entries)
        assertThat(result.fieldTypes!!.size).isEqualTo(DataType.entries.size)
        assertThat(result.measurementTypes!!.size).isEqualTo(DataType.entries.size)
        assertThat(result.parameterGroups!!.size).isEqualTo(parameterGroups.size + 2)
    }
}