package ru.nti.dtps.equipmentmanager.scheme.validator

import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test
import ru.nti.dtps.equipmentmanager.scheme.builder.SchemesForTest
import ru.nti.dtps.equipmentmanager.scheme.domain.FieldTypeId
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoProvider
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.*

class Basic {

    private val libInfoProvider = LibInfoProvider()
    private val validatorService = ValidatorService(
        listOf(
            IslandsValidator(),
            LinkConnectingPortValidator(),
            PrimitivePortNumberValidator(10),
            RequiredEquipmentsValidator(),
            BasicNodeValidator(libInfoProvider)
        )
    )

    private val scheme = SchemesForTest.buildValidSchemeWithAllTypesPrimitiveEquipment().also {
        it.primitiveNodes.values.forEach { node ->
            val equipmentLib = libInfoProvider.getEquipmentLibById(node.type)
            equipmentLib.options.forEach { optionLib ->
                val defaultValue = when (optionLib.typeId) {
                    FieldTypeId.TEXT -> "text"
                    FieldTypeId.MUTUALITY_SELECT -> null
                    else -> optionLib.max!!.toString()
                }
                node.options[optionLib.id] = defaultValue
            }
        }
    }

    @Test
    fun `scheme with all types primitive equipment valid`() {
        val validateResult = validatorService.validate(scheme)

        Assertions.assertThat(validateResult.isRight()).isTrue()
    }
}