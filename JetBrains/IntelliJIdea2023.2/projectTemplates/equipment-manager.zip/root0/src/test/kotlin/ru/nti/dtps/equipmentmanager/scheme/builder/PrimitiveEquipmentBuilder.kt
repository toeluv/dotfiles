package ru.nti.dtps.equipmentmanager.scheme.builder

import ru.nti.dtps.equipmentmanager.scheme.domain.Alignment
import ru.nti.dtps.equipmentmanager.scheme.domain.PortLibId
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.XyCoords
import java.util.*

class PrimitiveEquipmentBuilder {

    companion object {

        fun buildCurrentSource() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "Current source",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.CURRENT_SOURCE,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.LEFT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""

                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.SECOND,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
            )
        )

        fun buildEmfSource() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "EMF source",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.EMF_SOURCE,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.LEFT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.SECOND,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
            )
        )

        fun buildGrounding() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "Grounding",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.GROUNDING,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.TOP,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                )
            )
        )

        fun buildResistor() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "Resistor",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.RESISTOR,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.LEFT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.SECOND,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
            )
        )

        fun buildInductanceCoil() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "Inductance coil",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.INDUCTANCE_COIL,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.LEFT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.SECOND,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
            )
        )

        fun buildCapacitor() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "Capacitor",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.CAPACITOR,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.LEFT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.SECOND,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
            )
        )

        fun buildIdealTransformer() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "Ideal Transformer",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.IDEAL_TRANSFORMER,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.LEFT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.SECOND,
                    coords = XyCoords(),
                    alignment = Alignment.LEFT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.THIRD,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                )
            )
        )

        fun buildSinglePhasePort() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "Single phase port",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                )
            )
        )

        fun buildThreePhasePort() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "Three phase port",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.SECOND,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.THIRD,
                    coords = XyCoords(),
                    alignment = Alignment.RIGHT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                )
            )
        )

        fun buildConnectivity() = PrimitiveEquipment(
            id = UUID.randomUUID().toString(),
            name = "Connectivity",
            type = PrimitiveEquipment.PrimitiveEquipmentLibId.CONNECTIVITY,
            coords = XyCoords(),
            dimensions = PrimitiveEquipment.Dimensions(),
            payload = "",
            ports = listOf(
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.FIRST,
                    coords = XyCoords(),
                    alignment = Alignment.TOP,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.SECOND,
                    coords = XyCoords(),
                    alignment = Alignment.LEFT,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                ),
                PrimitiveEquipment.Port(
                    id = UUID.randomUUID().toString(),
                    libId = PortLibId.THIRD,
                    coords = XyCoords(),
                    alignment = Alignment.BOTTOM,
                    links = listOf(),
                    parentNode = "",
                    payload = ""
                )
            )
        )
    }
}