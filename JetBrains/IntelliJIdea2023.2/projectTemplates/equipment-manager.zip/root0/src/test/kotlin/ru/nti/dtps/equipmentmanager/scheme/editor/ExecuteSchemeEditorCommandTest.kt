//package ru.nti.dtps.equipmentmanager.scheme.editor
//
//import org.assertj.core.api.Assertions
//import org.junit.jupiter.api.Test
//import ru.nti.dtps.equipmentmanager.common.types.*
//import ru.nti.dtps.equipmentmanager.common.types.ParameterName
//import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentFullView
//import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
//import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExist
//import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExists
//import ru.nti.dtps.equipmentmanager.scheme.builder.SchemesForTest
//import ru.nti.dtps.equipmentmanager.scheme.domain.*
//import ru.nti.dtps.equipmentmanager.scheme.domain.command.CommandType
//import ru.nti.dtps.equipmentmanager.scheme.domain.command.CreateNode
//import ru.nti.dtps.equipmentmanager.scheme.domain.command.CreateNodeCommand
//import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoProvider
//import ru.nti.dtps.equipmentmanager.scheme.domain.validator.CustomByNodeLibIdValidator
//import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.MutualityOptionValidator
//import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.VariableNameOptionValidator
//import ru.nti.dtps.equipmentmanager.scheme.usecase.VariableNameOnSchemeAlreadyExist
//import java.time.Instant
//import java.util.*
//import kotlin.math.sqrt
//
//class ExecuteSchemeEditorCommandTest {
//
//    private val libInfoProvider = LibInfoProvider()
//
//    private val scheme = SchemesForTest.buildValidSchemeWithAllTypesPrimitiveEquipment().also {
//        it.primitiveNodes.values.forEach { node ->
//            val equipmentLib = libInfoProvider.getEquipmentLibById(node.type)
//            equipmentLib.options.forEach { optionLib ->
//                val defaultValue = when (optionLib.typeId) {
//                    FieldTypeId.TEXT -> "test text"
//                    FieldTypeId.MUTUALITY_SELECT -> null
//                    else -> optionLib.max!!.toString()
//                }
//                node.options[optionLib.id] = defaultValue
//            }
//        }
//    }
//
//    private val equipmentFullView = EquipmentFullView.restore(
//        scheme.id,
//        CompanyId.from(UUID.randomUUID()),
//        EquipmentName("Test equipment"),
//        null,
//        null,
//        "test",
//        Instant.now(),
//        setOf(),
//        setOf(),
//        setOf(),
//        false,
//        null,
//        0L,
//        null,
//        null
//    )
//
//    private val createNodeCommand = CreateNodeCommand(
//        CommandType.NODE_CREATE,
//        equipmentFullView.id,
//        UserId.from(UUID.randomUUID()),
//        CreateNode(
//            UUID.randomUUID().toString(),
//            "Ideal transformer",
//            libEquipmentId = PrimitiveEquipment.PrimitiveEquipmentLibId.IDEAL_TRANSFORMER,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = PrimitiveEquipment.PrimitiveEquipmentLibId.IDEAL_TRANSFORMER.getDefaultOptionsByEquipmentLibId()
//        )
//    )
//
//    private val allowedPrimitivePortNumber = 10
//
//    private class VariableNameAlreadyExistImpl(val equipmentFullView: EquipmentFullView) : VariableNameAlreadyExists {
//        override fun onCreate(variableName: VariableName, equipmentId: EquipmentId): Boolean {
//            val variableNamesFromEquipment = (equipmentFullView.parameters.map { it.variableName.name } +
//                equipmentFullView.inputSignals.map { it.variableName.name } +
//                equipmentFullView.outputSignals.map { it.variableName.name }).toSet()
//            return variableNamesFromEquipment.contains(variableName.name)
//        }
//
//        override fun onUpdate(variableName: VariableName, equipmentId: EquipmentId, excludedId: UUID): Boolean {
//            val variableNamesFromEquipment = (equipmentFullView.parameters.map { it.variableName.name } +
//                equipmentFullView.inputSignals.map { it.variableName.name } +
//                equipmentFullView.outputSignals.map { it.variableName.name }).toSet()
//            return variableNamesFromEquipment.contains(variableName.name)
//        }
//    }
//
//    private class VariableNameOnSchemeAlreadyExistImpl(val scheme: Scheme) : VariableNameOnSchemeAlreadyExist {
//        override fun invoke(variableName: VariableName, equipmentId: EquipmentId): Boolean {
//            val variableNamesFromScheme = scheme.primitiveNodes.values
//                .flatMap { primitiveEquipment ->
//                    primitiveEquipment.options.filter { it.key == OptionLibId.VARIABLE_NAME }.values
//                }.toSet()
//
//            return variableNamesFromScheme.contains(variableName.name)
//        }
//    }
//
//    private val variableNameOptionValidator = VariableNameOptionValidator(
//        VariableNameAlreadyExistImpl(equipmentFullView),
//        VariableNameOnSchemeAlreadyExistImpl(scheme)
//    )
//    private val mutualityOptionValidator = MutualityOptionValidator()
//    private val businessValidator = CustomByNodeLibIdValidator(variableNameOptionValidator, mutualityOptionValidator)
//
//    @Test
//    fun `execute create ideal transformer success`() {
//        val result = scheme.execute(createNodeCommand, libInfoProvider, allowedPrimitivePortNumber, businessValidator)
//        val createdPrimitiveEquipment = scheme.primitiveNodes.values.find { it.id == createNodeCommand.body.id }
//
//        Assertions.assertThat(result.isRight()).isTrue()
//        Assertions.assertThat(createdPrimitiveEquipment).isNotNull
//    }
//
//    @Test
//    fun `count mutual inductance for ideal transformer success`() {
//        val options = PrimitiveEquipment.PrimitiveEquipmentLibId.IDEAL_TRANSFORMER.getDefaultOptionsByEquipmentLibId()
//
//        val k = options[OptionLibId.COUPLING_COEFFICIENT]!!.toDouble()
//        val l1 = options[OptionLibId.INDUCTANCE_L1]!!.toDouble()
//        val l2 = options[OptionLibId.INDUCTANCE_L2]!!.toDouble()
//
//        val countedMutualInductance = (k * sqrt(l1 * l2)).toString()
//
//        val idealTransformer = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "Test",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.IDEAL_TRANSFORMER,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = options
//        )
//
//        idealTransformer.countAndSetMutualInductanceIfNeed()
//
//        Assertions
//            .assertThat(idealTransformer.options[OptionLibId.MUTUAL_INDUCTANCE])
//            .isEqualTo(countedMutualInductance)
//    }
//
//    @Test
//    fun `variable name is not unique on scheme`() {
//        val idealTransformer = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "Test",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.IDEAL_TRANSFORMER,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = mutableMapOf(
//                OptionLibId.VARIABLE_NAME to "test"
//            )
//        )
//
//        scheme.primitiveNodes[idealTransformer.id] = idealTransformer
//
//        val result = variableNameOptionValidator.validate(idealTransformer, scheme)
//
//        Assertions
//            .assertThat(result.leftOrNull())
//            .isInstanceOf(SchemeEditorError.VariableNameOptionIsNotValidOrUniqueError::class.java)
//    }
//
//    @Test
//    fun `variable name is not unique in equipment`() {
//        val idealTransformer = PrimitiveEquipment(
//            id = UUID.randomUUID().toString(),
//            name = "Test",
//            type = PrimitiveEquipment.PrimitiveEquipmentLibId.IDEAL_TRANSFORMER,
//            coords = XyCoords(),
//            dimensions = PrimitiveEquipment.Dimensions(),
//            options = mutableMapOf(
//                OptionLibId.VARIABLE_NAME to "test"
//            )
//        )
//
//        equipmentFullView.parameters.add(
//            Parameter(
//                ParameterId(UUID.randomUUID()),
//                equipmentFullView.id,
//                ParameterName("some"),
//                groupId = "",
//                unitType = UnitType.RELATIVE_UNIT,
//                dataType = DataType.BOOLEAN,
//                minValue = "",
//                maxValue = "",
//                defaultValue = "",
//                variableName = VariableName("test")
//            )
//        )
//
//        val result = variableNameOptionValidator.validate(idealTransformer, scheme)
//
//        Assertions
//            .assertThat(result.leftOrNull())
//            .isInstanceOf(SchemeEditorError.VariableNameOptionIsNotValidOrUniqueError::class.java)
//    }
//
//    @Test
//    fun `mutuality is the same primitive equipment type`() {
//        scheme.execute(createNodeCommand, libInfoProvider, allowedPrimitivePortNumber, businessValidator)
//        val createdEquipment = scheme.primitiveNodes.values.first { it.id == createNodeCommand.body.id }
//        val otherTransformer = scheme.primitiveNodes.values
//            .first { it.id != createdEquipment.id && it.type == createNodeCommand.body.libEquipmentId }
//        createdEquipment.options[OptionLibId.MUTUALITY] = otherTransformer.id
//
//        val result = mutualityOptionValidator.validate(createdEquipment, scheme)
//
//        Assertions.assertThat(result.isRight()).isTrue()
//    }
//
//    @Test
//    fun `mutuality is NOT the same primitive equipment type`() {
//        scheme.execute(createNodeCommand, libInfoProvider, allowedPrimitivePortNumber, businessValidator)
//        val createdEquipment = scheme.primitiveNodes.values.first { it.id == createNodeCommand.body.id }
//        val otherTransformer = scheme.primitiveNodes.values
//            .first { it.type != createNodeCommand.body.libEquipmentId }
//        createdEquipment.options[OptionLibId.MUTUALITY] = otherTransformer.id
//
//        val result = mutualityOptionValidator.validate(createdEquipment, scheme)
//
//        Assertions
//            .assertThat(result.leftOrNull())
//            .isInstanceOf(SchemeEditorError.MutualityOptionIsNotValidError::class.java)
//    }
//
//    private fun PrimitiveEquipment.PrimitiveEquipmentLibId.getDefaultOptionsByEquipmentLibId(
//    ): MutableMap<OptionLibId, String?> {
//        return libInfoProvider
//            .getEquipmentLibById(this)
//            .options.associate { optionLib ->
//                val defaultValue = when (optionLib.typeId) {
//                    FieldTypeId.TEXT -> "test"
//                    FieldTypeId.MUTUALITY_SELECT -> null
//                    else -> optionLib.min!!.toString()
//                }
//                optionLib.id to defaultValue
//            }.toMutableMap()
//    }
//
//}