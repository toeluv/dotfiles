package ru.nti.dtps.equipmentmanager.signal

import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.XyCoords
import ru.nti.dtps.equipmentmanager.scheme.domain.isPrimitivePort
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoProvider
import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo
import java.util.*

class BuildSignalsForPrimitivePortTest {

    private val equipmentId = EquipmentId.from(UUID.randomUUID())
    private val port1Ph = UUID.randomUUID().toString()
    private val port3Ph = UUID.randomUUID().toString()
    private val schemeWithPrimitivePort = Scheme.restore(
        equipmentId,
        mutableMapOf(
            port1Ph to PrimitiveEquipment(
                id = port1Ph,
                name = "Port 1Ph",
                type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH,
                coords = XyCoords(),
                dimensions = PrimitiveEquipment.Dimensions(),
                payload = ""
            ),
            port3Ph to PrimitiveEquipment(
                id = port3Ph,
                name = "Port 3Ph",
                type = PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH,
                coords = XyCoords(),
                dimensions = PrimitiveEquipment.Dimensions(),
                payload = ""
            )
        ),
        mutableMapOf(),
        0,
        mutableListOf(),
        false
    )
    private val libInfoProvider = LibInfoProvider()

    @Test
    fun `build signals from scheme with primitive ports`() {
        val requiredSignalsCount = libInfoProvider.getPrimitivePortSignalInfo().size
        val signalsInfo = schemeWithPrimitivePort.primitiveNodes.values
            .filter {
                it.type.isPrimitivePort()
            }.flatMap {
                SignalInfo.buildSignalsForPrimitivePort(it.id, libInfoProvider)
            }

        Assertions.assertThat(signalsInfo.filter { it.groupId == port1Ph }.size).isEqualTo(requiredSignalsCount)
        Assertions.assertThat(signalsInfo.filter { it.groupId == port3Ph }.size).isEqualTo(requiredSignalsCount)
    }

    @Test
    fun `build signals from scheme without primitive ports`() {
        val scheme = Scheme.create(equipmentId)

        val signalsInfo = scheme.primitiveNodes.values
            .filter {
                it.type.isPrimitivePort()
            }.flatMap {
                SignalInfo.buildSignalsForPrimitivePort(it.id, libInfoProvider)
            }

        Assertions.assertThat(signalsInfo).isEmpty()
    }

}