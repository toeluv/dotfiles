package ru.nti.dtps.equipmentmanager.equipment.config

import liquibase.integration.spring.SpringLiquibase
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.jdbc.datasource.DriverManagerDataSource
import org.testcontainers.containers.PostgreSQLContainer
import org.testcontainers.junit.jupiter.Container
import javax.sql.DataSource

@Configuration
class PostgreSQLTestContainerConfig {

    @Bean
    fun dataSource(): DataSource {
        return DriverManagerDataSource().apply {
            setDriverClassName("org.postgresql.Driver")
            url = postgres.jdbcUrl
            username = postgres.username
            password = postgres.password

        }
    }

    @Bean
    fun springLiquibase(dataSource: DataSource?) = SpringLiquibase().apply {
        this.dataSource = dataSource
        contexts = "test"
        changeLog = "classpath:/db/changelog/changelog-master.yaml"
    }

    companion object {

        @Container
        val postgres = PostgreSQLContainer("postgres:15-alpine")
            .withDatabaseName("test-db")
            .withUsername("test_user")
            .withPassword("test_password")
            .also { it.start() }
    }
}


