package ru.nti.dtps.equipmentmanager.svg.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.equipment.rest.EquipmentShortView
import ru.nti.dtps.equipmentmanager.svg.domain.*
import ru.nti.dtps.equipmentmanager.svg.usecase.GetSvgWithInfoByEquipment
import ru.nti.dtps.equipmentmanager.svg.usecase.GetSvgWithInfoByEquipmentUseCaseError
import ru.nti.dtps.equipmentmanager.svg.usecase.scenarios.ComplexSvgInfo

@RestController
class GetSvgWithInfoEndpoint(
    private val messageSource: MessageSourceService,
    private val getSvgWithInfoByEquipment: GetSvgWithInfoByEquipment
) {

    @Operation(summary = "Get svg with info")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Get svg with info success", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = EquipmentShortView::class)
                    ))]
            ),
            ApiResponse(responseCode = "404", description = "Svg not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "404", description = "Svg info not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "500", description = "Something went wrong, go to admin",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                ))])]
    )
    @GetMapping("#[[\$]]#API_V1_EQUIPMENT_SVG/{equipmentId}/info")
    fun getSvgWithInfo(
        @PathVariable equipmentId: String
    ): ResponseEntity<*> {

        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    getSvgWithInfoByEquipment.execute(validEquipmentId)
                        .fold(
                            { it.toRestError() },
                            { ok(it.toResponseView()) }
                        )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun GetSvgWithInfoByEquipmentUseCaseError.toRestError() =
        when (this) {
            GetSvgWithInfoByEquipmentUseCaseError.SvgInfoNotFound ->
                restBusinessError(
                    messageSource.getMessage("api.svg.error.info.not-found"),
                    HttpStatus.NOT_FOUND
                )
            GetSvgWithInfoByEquipmentUseCaseError.SvgNotFound ->
                restBusinessError(
                    messageSource.getMessage("api.svg.error.not-found"),
                    HttpStatus.NOT_FOUND
                )
        }
}

private fun ComplexSvgInfo.toResponseView() =
    SvgInfoView(
        this.id.toString(),
        this.svgForScheme,
        this.svgForLibrary,
        this.coords,
        this.dimensions,
        this.hour,
        this.ports,
        this.placeholders
    )

data class SvgInfoView(
    val id: String,
    val svgForScheme: ByteArray?,
    val svgForLibrary: ByteArray?,
    val coords: XyCoords?,
    val dimensions: Dimensions?,
    val hour: Int?,
    val ports: List<SvgPort>,
    val placeholders: List<Placeholder>
)
