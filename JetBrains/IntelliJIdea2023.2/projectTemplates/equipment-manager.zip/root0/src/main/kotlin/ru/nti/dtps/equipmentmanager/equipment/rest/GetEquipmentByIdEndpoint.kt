package ru.nti.dtps.equipmentmanager.equipment.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.common.util.API_V1_EQUIPMENT
import ru.nti.dtps.equipmentmanager.common.util.GlobalErrorHandler
import ru.nti.dtps.equipmentmanager.equipment.usecase.GetEquipmentById
import ru.nti.dtps.equipmentmanager.equipment.usecase.GetEquipmentByIdUseCaseError

@RestController
class GetEquipmentByIdEndpoint(
    private val getEquipment: GetEquipmentById,
    private val messageSource: MessageSourceService
) {
    @Operation(summary = "Get existing equipment by id")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Equipment by id request success", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = EquipmentShortView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Invalid equipment id", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Equipment was not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(responseCode = "500", description = "Something went wrong, go to admin",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                ))])]
    )
    @GetMapping("#[[\$]]#API_V1_EQUIPMENT/{equipmentId}")
    fun getById(@PathVariable equipmentId: String): ResponseEntity<*> {
        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    getEquipment.execute(validEquipmentId)
                        .fold(
                            { useCaseError -> useCaseError.toRestError() },
                            { equipment -> ok(equipment.toShortView()) }
                        )
                })
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun GetEquipmentByIdUseCaseError.toRestError() =
        when (this) {
            is GetEquipmentByIdUseCaseError.EquipmentNotExistsUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.equipment.error.not-found"),
                    HttpStatus.NOT_FOUND
                )
        }
}
