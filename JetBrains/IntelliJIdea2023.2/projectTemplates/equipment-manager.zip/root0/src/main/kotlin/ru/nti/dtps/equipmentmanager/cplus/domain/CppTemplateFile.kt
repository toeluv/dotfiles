package ru.nti.dtps.equipmentmanager.cplus.domain

import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentFullView
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme

class CppTemplateFile(
    val name: String,
    val content: ByteArray
) {
    companion object {
        fun from(equipment: EquipmentFullView, scheme: Scheme) = CppTemplateFile(
            name = "#[[\$]]#{equipment.name.toStringValue()}.h",
            content = CppTemplate(equipment, scheme).generateTemplate().toByteArray()
        )
    }
}