package ru.nti.dtps.equipmentmanager.common.configuration.client

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.stereotype.Component
import org.springframework.web.reactive.function.client.WebClient
import java.util.*

private const val GET_ALL_USERS_API = "/v1/internal/users"

@ConditionalOnProperty(
    name = ["internal.client-enable"],
    havingValue = "true"
)
@Component
class IntegrationPlatformClient(
    private val internalClientProperties: InternalClientProperties,
    private val webClient: WebClient
) {

    fun getAllUsers(): List<UserDto> {
        return webClient
            .get()
            .uri(internalClientProperties.integrationPlatform + GET_ALL_USERS_API)
            .accept(MediaType.APPLICATION_JSON)
            .exchangeToFlux { response ->
                if (response.statusCode() == HttpStatus.OK) {
                    response.bodyToFlux(UserDto::class.java)
                } else {
                    response.createError<UserDto>().flux()
                }
            }
            .collectList()
            .block() ?: emptyList()
    }
}

class UserDto(
    val keycloakUserId: UUID,
    val companyId: UUID,
    val firstName: String,
    val lastName: String
)