package ru.nti.dtps.equipmentmanager.scheme.aaa.editor

import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import java.util.*

sealed interface EditorCommand

class CreateSchemeNodeEditorCommand(
    val schemeNode: SchemeNode
) : EditorCommand {
    companion object {
        fun build(userCommand: CreateNodeUserCommand) = CreateSchemeNodeEditorCommand(
            SchemeNode(
                id = userCommand.nodeId,
                parentId = userCommand.equipmentId.toUUID(),
                type = userCommand.body.type,
                ports = userCommand.body.ports,
                hour = userCommand.body.hour,
                coords = userCommand.body.coords,
                dimensions = userCommand.body.dimensions,
                payload = userCommand.body.payload
            )
        )
    }
}

class ChangeSchemeNodeEditorCommand(
    val schemeNode: SchemeNode
) : EditorCommand {
    companion object {
        fun build(
            userCommand: ChangeNodeOptionsUserCommand,
            currentNode: SchemeNode
        ) = ChangeSchemeNodeEditorCommand(
            SchemeNode(
                id = userCommand.nodeId,
                parentId = userCommand.equipmentId.toUUID(),
                type = currentNode.type,
                ports = currentNode.ports,
                hour = currentNode.hour,
                coords = currentNode.coords,
                dimensions = currentNode.dimensions,
                payload = userCommand.body.payload
            )
        )

        fun build(
            userCommand: ChangeNodeCoordsUserCommand,
            currentNode: SchemeNode
        ) = ChangeSchemeNodeEditorCommand(
            SchemeNode(
                id = userCommand.nodeId,
                parentId = userCommand.equipmentId.toUUID(),
                type = currentNode.type,
                ports = userCommand.body.ports,
                hour = currentNode.hour,
                coords = userCommand.body.coords,
                dimensions = currentNode.dimensions,
                payload = currentNode.payload
            )
        )

        fun build(
            userCommand: ChangeNodeDimensionsUserCommand,
            currentNode: SchemeNode
        ) = ChangeSchemeNodeEditorCommand(
            SchemeNode(
                id = userCommand.nodeId,
                parentId = userCommand.equipmentId.toUUID(),
                type = currentNode.type,
                hour = currentNode.hour,
                payload = currentNode.payload,

                coords = userCommand.body.coords,
                ports = userCommand.body.ports,
                dimensions = userCommand.body.dimensions
            )
        )

        fun build(
            userCommand: ChangeNodeRotationUserCommand,
            currentNode: SchemeNode
        ) = ChangeSchemeNodeEditorCommand(
            SchemeNode(
                id = userCommand.nodeId,
                parentId = userCommand.equipmentId.toUUID(),
                type = currentNode.type,
                ports = currentNode.ports,
                hour = userCommand.body.hour,
                coords = userCommand.body.coords,
                dimensions = currentNode.dimensions,
                payload = currentNode.payload
            )
        )
    }
}

class DeleteSchemeNodeEditorCommand(
    val id: UUID,
    val parentId: UUID,
) : EditorCommand {
    companion object {
        fun build(userCommand: DeleteNodeUserCommand) = DeleteSchemeNodeEditorCommand(
            id = userCommand.nodeId, parentId = userCommand.nodeId
        )
    }
}

class CreateSchemeLinkEditorCommand(
    val schemeLink: SchemeLink
) : EditorCommand {
    companion object {
        fun build(userCommand: CreateLinkUserCommand) = CreateSchemeLinkEditorCommand(
            SchemeLink(
                id = userCommand.nodeId,
                parentId = userCommand.equipmentId.toUUID(),
                alignmentType = userCommand.body.alignmentType,
                sourceNode = userCommand.body.sourceNode,
                targetNode = userCommand.body.targetNode,
                sourcePort = userCommand.body.sourcePort,
                targetPort = userCommand.body.targetPort,
                points = userCommand.body.points
            )
        )
    }
}

class ChangeLinkPointEditorCommand(
    val schemeLink: SchemeLink
) : EditorCommand {
    companion object {
        fun build(
            userCommand: ChangeLinkPointsUserCommand,
            currentLink: SchemeLink
        ) = ChangeLinkPointEditorCommand(
            SchemeLink(
                id = userCommand.nodeId,
                parentId = userCommand.equipmentId.toUUID(),
                alignmentType = currentLink.alignmentType,
                sourceNode = currentLink.sourceNode,
                targetNode = currentLink.targetNode,
                sourcePort = currentLink.sourcePort,
                targetPort = currentLink.targetPort,
                points = userCommand.body.points
            )
        )
    }
}

class DeleteSchemeLinkEditorCommand(
    val id: UUID,
    val parentId: UUID,
) : EditorCommand {
    companion object {
        fun build(userCommand: DeleteLinkUserCommand) = DeleteSchemeLinkEditorCommand(
            id = userCommand.nodeId,
            parentId = userCommand.equipmentId.toUUID()
        )
    }
}

class CreateNodeOptionsEditorCommand(
    val nodeOptions: NodeOptions
) : EditorCommand {
    companion object {
        fun build(command: CreateNodeUserCommand) = CreateNodeOptionsEditorCommand(
            NodeOptions(
                id = command.nodeId,
                parentId = command.equipmentId.toUUID(),
                nodeType = command.body.type,
                options = command.body.options
            )
        )
    }
}

class ChangeNodeOptionsEditorCommand(
    val nodeOptions: NodeOptions
) : EditorCommand {
    companion object {
        fun build(userCommand: ChangeNodeOptionsUserCommand, schemeNode: SchemeNode) = ChangeNodeOptionsEditorCommand(
            NodeOptions(
                id = userCommand.nodeId,
                parentId = userCommand.equipmentId.toUUID(),
                options = userCommand.body.options,
                nodeType = schemeNode.type
            )
        )
    }
}

class DeleteNodeOptionsEditorCommand(
    val id: UUID,
    val parentId: UUID,
) : EditorCommand {
    companion object {
        fun build(command: DeleteNodeUserCommand) = DeleteNodeOptionsEditorCommand(
            id = command.nodeId, parentId = command.equipmentId.toUUID()
        )
    }
}