package ru.nti.dtps.equipmentmanager.common.auth

import arrow.core.getOrElse
import org.springframework.security.core.context.SecurityContext
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.oauth2.jwt.Jwt
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.UserId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.user.usecase.access.GetUserIdFromContext

@Component
class UserIdExtractor : GetUserIdFromContext {

    override fun get(): UserId {
        return SecurityContextHolder.getContext().let { securityContext: SecurityContext ->
            val jwt: Jwt = securityContext.authentication.principal as Jwt
            val userId: String = jwt.getClaimAsString("sub")
            UserId.validated(userId).getOrElse {
                error("Invalid userId: #[[\$]]#userId")
            }
        }
    }
}
