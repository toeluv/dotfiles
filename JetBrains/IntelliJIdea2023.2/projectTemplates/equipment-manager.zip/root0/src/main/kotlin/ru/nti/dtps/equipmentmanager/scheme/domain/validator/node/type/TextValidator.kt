package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.NodeOptions
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.FieldType
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.OptionLib
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError

interface TextValidator {
    fun validate(
        optionValueString: String,
        optionLib: OptionLib,
        fieldType: FieldType,
        equipment: PrimitiveEquipment
    ): Either<SchemeValidationError, Unit>

    fun validate(
        optionValueString: String,
        optionLib: OptionLib,
        fieldType: FieldType,
        equipment: NodeOptions
    ): Either<SchemeValidationError, Unit>
}