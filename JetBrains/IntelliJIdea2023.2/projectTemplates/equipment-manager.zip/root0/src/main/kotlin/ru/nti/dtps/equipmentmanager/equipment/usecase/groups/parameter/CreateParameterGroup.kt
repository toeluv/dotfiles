package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.rest.groups.CreateParameterGroupCommand

interface CreateParameterGroup {
    fun execute(command: CreateParameterGroupCommand): Either<CreateParameterGroupUseCaseError, ParameterGroup>
}

sealed class CreateParameterGroupUseCaseError : UseCaseError {
    class ParameterGroupNameAlreadyExistUseCaseError(val name: String) : CreateParameterGroupUseCaseError()
}