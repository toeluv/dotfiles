package ru.nti.dtps.equipmentmanager.scheme.persist.adapter

import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import java.util.UUID

interface SchemeExtractor {
    fun getById(id: UUID): Scheme?
}