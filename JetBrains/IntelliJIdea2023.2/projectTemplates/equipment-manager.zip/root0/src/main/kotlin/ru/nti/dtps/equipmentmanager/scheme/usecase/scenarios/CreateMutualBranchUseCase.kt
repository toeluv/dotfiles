package ru.nti.dtps.equipmentmanager.scheme.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.MutualBranch
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.branch.MutualBranchVariableValidator
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemePersister
import ru.nti.dtps.equipmentmanager.scheme.rest.CreateBranchCommand
import ru.nti.dtps.equipmentmanager.scheme.usecase.CreateMutualBranch
import ru.nti.dtps.equipmentmanager.scheme.usecase.CreateMutualBranchUseCaseError

@Component
class CreateMutualBranchUseCase(
    private val schemeExtractor: SchemeExtractor,
    private val schemePersister: SchemePersister,
    private val mutualBranchVariableValidator: MutualBranchVariableValidator
) : CreateMutualBranch {
    override fun execute(
        createBranchCommand: CreateBranchCommand
    ): Either<CreateMutualBranchUseCaseError, MutualBranch> {
        val scheme = schemeExtractor.getById(createBranchCommand.equipmentId.toUUID())
            ?: return CreateMutualBranchUseCaseError.SchemeNotFoundError.left()
        return scheme.createMutualBranch(createBranchCommand, mutualBranchVariableValidator)
            .fold({
                CreateMutualBranchUseCaseError.VariableNameAlreadyExistsError(it.message).left()
            },
                { it.also { schemePersister.update(scheme) }.right() }
            )
    }
}