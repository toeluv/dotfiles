package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.validators

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExists
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.BusinessNodeValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.InvalidNodeValue
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeToValidate
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId
import java.util.*

@Component
class VariableNameOptionValidator(
    val variableNameAlreadyExists: VariableNameAlreadyExists
) : BusinessNodeValidator {

    private val variableNameKeySelector = OptionLibId.VARIABLE_NAME

    override fun order() = 1

    override fun validate(node: NodeToValidate): Either<NodeValidationError, Unit> {
        node.options()[variableNameKeySelector]?.let { variableName ->
            val validatedVariableName = VariableName.from(variableName)
                .getOrElse { return InvalidNodeValue(node.id(), node.equipmentId(), variableNameKeySelector).left() }

            if (variableNameAlreadyExists(validatedVariableName, node.equipmentId(), node.id())) {
                return VariableNameAlreadyExistValidationError(
                    node.id(), node.equipmentId(), validatedVariableName
                ).left()
            }
        }
        return Unit.right()
    }

}

data class VariableNameAlreadyExistValidationError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val variableName: VariableName
) : NodeValidationError

