package ru.nti.dtps.equipmentmanager.equipment.persist.adapter

import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentName
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment

interface EquipmentExtractor {
    fun getAll(): Collection<Equipment>
    fun getAllByCompanyId(companyId: CompanyId): Collection<Equipment>
    fun getAllByGroupIdAndCompanyId(groupId: String?, companyId: CompanyId): Collection<Equipment>
    fun getByIdAndCompanyId(equipmentId: EquipmentId, companyId: CompanyId): Equipment?
    fun getById(equipmentId: EquipmentId): Equipment?
    fun checkEquipmentNameExists(equipmentName: EquipmentName, companyId: CompanyId, equipmentGroupId: String?): Boolean
}