package ru.nti.dtps.equipmentmanager.equipment.usecase.scenarios

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentError
import ru.nti.dtps.equipmentmanager.equipment.domain.command.UpdateEquipmentCommand
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentPersister
import ru.nti.dtps.equipmentmanager.equipment.usecase.EquipmentNameAlreadyExists
import ru.nti.dtps.equipmentmanager.equipment.usecase.UpdateEquipment
import ru.nti.dtps.equipmentmanager.equipment.usecase.UpdateEquipmentUseCaseError
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserInfoProvider

@Component
class UpdateEquipmentUseCase(
    private val equipmentPersister: EquipmentPersister,
    private val equipmentExtractor: EquipmentExtractor,
    private val nameAlreadyExist: EquipmentNameAlreadyExists,
    private val userInfoProvider: CurrentUserInfoProvider,
) : UpdateEquipment {
    override fun execute(command: UpdateEquipmentCommand): Either<UpdateEquipmentUseCaseError, Equipment> {
        return equipmentExtractor.getById(command.id)?.let { equipment ->
            val updatedEquipment = equipment.update(
                command,
                nameAlreadyExist,
                userInfoProvider.get(),
            ).getOrElse { return it.toError().left() }

            equipmentPersister.update(updatedEquipment)
            return updatedEquipment.right()
        } ?: UpdateEquipmentUseCaseError.EquipmentNotExistError.left()
    }

    private fun EquipmentError.toError(): UpdateEquipmentUseCaseError {
        return when (this) {
            is EquipmentError.EquipmentExistWithSameNameError ->
                UpdateEquipmentUseCaseError.EquipmentNameAlreadyExistUseCaseError(name)
        }
    }
}