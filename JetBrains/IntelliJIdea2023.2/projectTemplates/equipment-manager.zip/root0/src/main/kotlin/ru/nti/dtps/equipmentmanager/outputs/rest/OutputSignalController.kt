package ru.nti.dtps.equipmentmanager.outputs.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.ArraySchema
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import ru.nti.dtps.equipmentmanager.outputs.usecase.*

@RestController
class OutputSignalController(
    private val messageSource: MessageSourceService,
    private val createOutputSignal: CreateOutputSignal,
    private val updateOutputSignal: UpdateOutputSignal,
    private val deleteOutputSignal: DeleteOutputSignal,
    private val getAllOutputSignalsByEquipment: GetAllOutputSignalsByEquipment
) {

    @Operation(summary = "Execute get all output signals command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "All output signals are found", content = [
                    (Content(
                        mediaType = "application/json",
                        array = ArraySchema(schema = Schema(implementation = OutputSignalView::class))
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @GetMapping("#[[\$]]#API_V1_EQUIPMENT_OUTPUTS/{equipmentId}")
    fun getAllByEquipment(
        @PathVariable equipmentId: String
    ): ResponseEntity<*> {
        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    ok(
                        getAllOutputSignalsByEquipment.execute(validEquipmentId).map { it.toView() }
                    )
                }
            )
    }

    @Operation(summary = "Execute create output signal command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Output signal was created", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = OutputSignalView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409",
                description = "Variable name has not unique value",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PostMapping("#[[\$]]#API_V1_EQUIPMENT_OUTPUTS/{equipmentId}")
    fun createOutputSignal(
        @PathVariable equipmentId: String,
        @RequestBody request: CreateOutputSignalRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    createOutputSignal.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { outputSignal -> ok(outputSignal.toView()) }
                        )
                }
            )
    }

    @Operation(summary = "Execute update output signal variable command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Output signal was updated", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = OutputSignalView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409", description = "Variable name has not unique value", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Output signal not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PutMapping("#[[\$]]#API_V1_EQUIPMENT_OUTPUTS/{equipmentId}")
    fun updateOutputSignal(
        @PathVariable equipmentId: String,
        @RequestBody request: UpdateOutputSignalRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    updateOutputSignal.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { outputSignal -> ok(outputSignal.toView()) }
                        )
                }
            )
    }

    @Operation(summary = "Execute delete output signal command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Output signal was deleted", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = Unit::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Output signal not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @DeleteMapping("#[[\$]]#API_V1_EQUIPMENT_OUTPUTS/{equipmentId}")
    fun delete(
        @PathVariable equipmentId: String,
        @RequestBody request: DeleteOutputSignalRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    deleteOutputSignal.execute(it).fold(
                        { error -> error.toRestError() },
                        { unit -> ok(unit) }
                    )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun CreateOutputSignalUseCaseError.toRestError() =
        when (this) {
            is CreateOutputSignalUseCaseError.VariableNameAlreadyExistsError ->
                restBusinessError(
                    messageSource.getMessage("api.variable.error.validation.twins").format(name),
                    HttpStatus.CONFLICT
                )

            is CreateOutputSignalUseCaseError.OutputSignalNameAlreadyExistError ->
                restBusinessError(
                    messageSource.getMessage("api.output.signal.error.validation.twins").format(name),
                    HttpStatus.CONFLICT
                )
        }

    private fun UpdateOutputSignalUseCaseError.toRestError() =
        when (this) {
            is UpdateOutputSignalUseCaseError.VariableNameAlreadyExistsError ->
                restBusinessError(
                    messageSource.getMessage("api.variable.error.validation.twins").format(name),
                    HttpStatus.CONFLICT
                )

            is UpdateOutputSignalUseCaseError.OutputSignalNotFoundError ->
                restBusinessError(
                    messageSource.getMessage("api.output.signal.error.not-found"),
                    HttpStatus.NOT_FOUND
                )

            is UpdateOutputSignalUseCaseError.OutputSignalNameAlreadyExistError ->
                restBusinessError(
                    messageSource.getMessage("api.output.signal.error.validation.twins").format(name),
                    HttpStatus.CONFLICT
                )
        }

    private fun DeleteOutputSignalUseCaseError.toRestError() =
        when (this) {
            DeleteOutputSignalUseCaseError.OutputSignalNotFoundError ->
                restBusinessError(
                    messageSource.getMessage("api.output.signal.error.not-found"),
                    HttpStatus.NOT_FOUND
                )
        }
}

data class OutputSignalView(
    val id: String,
    val equipmentId: String,
    val name: String,
    val unitType: String,
    val dataType: String,
    val variableName: String
)

private fun OutputSignal.toView() = OutputSignalView(
    this.id.toStringValue(),
    this.equipmentId.toStringValue(),
    this.name.toStringValue(),
    this.unitType.name,
    this.dataType.name,
    this.variableName.name
)
