package ru.nti.dtps.equipmentmanager.svg.persist

import com.fasterxml.jackson.databind.ObjectMapper
import org.postgresql.util.PGobject
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SignalInfoExtractor
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SignalInfoPersister
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SignalInfoDto
import java.util.*
import javax.sql.DataSource

@Component
class SignalInfoRepository(
    dataSource: DataSource,
    private val objectMapper: ObjectMapper
) : SignalInfoExtractor, SignalInfoPersister {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    override fun getById(id: UUID): SignalInfoDto? {
        return jdbcTemplate.query(
            "SELECT * FROM public.signal_info WHERE id = :id",
            mapOf("id" to id),
            SignalInfoResultSetExtractor()
        )
    }

    @Transactional
    override fun save(signalInfoDto: SignalInfoDto) {
        val params = mapOf(
            "id" to signalInfoDto.id,
            "signals_from_meas" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(signalInfoDto.signalsFromMeas)
            },
            "signals_from_scheme" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(signalInfoDto.signalsFromScheme)
            }
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.signal_info(id, signals_from_meas, signals_from_scheme)
            VALUES(
            :id, 
            :signals_from_meas, 
            :signals_from_scheme
            )
            """.trimMargin(), params
        )
    }

    @Transactional
    override fun update(signalInfoDto: SignalInfoDto) {
        val params = mapOf(
            "id" to signalInfoDto.id,
            "signals_from_meas" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(signalInfoDto.signalsFromMeas)
            },
            "signals_from_scheme" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(signalInfoDto.signalsFromScheme)
            }
        )

        val update = jdbcTemplate.update(
            """
            UPDATE public.signal_info SET
            signals_from_meas = :signals_from_meas, 
            signals_from_scheme = :signals_from_scheme
            WHERE id = :id
        """.trimIndent(), params
        )
        if (update == 0) {
            save(signalInfoDto)
        }
    }

    @Transactional
    override fun updateSignalsFromScheme(id: UUID, signalsFromScheme: List<SignalInfo>) {
        val params = mapOf(
            "id" to id,
            "signals_from_scheme" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(signalsFromScheme)
            }
        )
        jdbcTemplate.update(
            """
            UPDATE public.signal_info SET
            signals_from_scheme = :signals_from_scheme
            WHERE id = :id
            """.trimIndent(), params
        )
    }

    @Transactional
    override fun updateSignalsFromMeasurements(id: UUID, signalsFromMeasurements: List<SignalInfo>) {
        val params = mapOf(
            "id" to id,
            "signals_from_meas" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(signalsFromMeasurements)
            }
        )
        jdbcTemplate.update(
            """
            UPDATE public.signal_info SET
            signals_from_meas = :signals_from_meas
            WHERE id = :id
            """.trimIndent(), params
        )
    }

    override fun delete(id: UUID) {
        jdbcTemplate.update(
            "DELETE from public.signal_info WHERE id = :id",
            mapOf("id" to id)
        )
    }
}