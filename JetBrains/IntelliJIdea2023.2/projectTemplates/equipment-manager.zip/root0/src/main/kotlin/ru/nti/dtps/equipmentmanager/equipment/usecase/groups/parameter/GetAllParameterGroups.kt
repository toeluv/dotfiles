package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter

import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup

interface GetAllParameterGroups {
    fun execute(): Collection<ParameterGroup>
}