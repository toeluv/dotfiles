package ru.nti.dtps.equipmentmanager.scheme.rest.request

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.ValidationError
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.rest.CreateBranchCommand
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment.PrimitiveEquipmentLibId.*
import ru.nti.dtps.equipmentmanager.scheme.rest.UpdateBranchCommand

private const val MIN_VALUE = 1.175494351e-38

private const val MAX_VALUE = 3.402823466e+38

data class CreateBranchRequest(
    val id: String,
    val name: String,
    var isResistive: Boolean,
    var resistance: Double?,
    var conductivity: Double?,
    val elementType: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, CreateBranchCommand> {

        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }

        val variableName = VariableName.validated(name).getOrElse {
            return it.left()
        }

        val elementTypeEnum = when (PrimitiveEquipment.PrimitiveEquipmentLibId.valueOf(elementType)) {
            GROUNDING,
            CONNECTIVITY,
            PORT_1PH,
            PORT_3PH ->
                return ValidationError("api.scheme.validation.error.branch.not.supported.type").left()

            else -> PrimitiveEquipment.PrimitiveEquipmentLibId.valueOf(elementType)
        }
        return CreateBranchCommand(
            id = id,
            equipmentId = validEquipmentId,
            name = variableName,
            isResistive = isResistive,
            resistance = resistance?.validate()?.getOrElse
            { return it.left() } ?: 0.0,
            conductivity = conductivity?.validate()?.getOrElse
            { return it.left() } ?: 0.0,
            elementType = elementTypeEnum
        ).right()
    }
}

data class UpdateBranchRequest(
    val id: String,
    val name: String,
    var isResistive: Boolean,
    var resistance: Double?,
    var conductivity: Double?,
    val elementType: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, UpdateBranchCommand> {

        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }

        val variableName = VariableName.validated(name).getOrElse {
            return it.left()
        }

        val elementTypeEnum = when (PrimitiveEquipment.PrimitiveEquipmentLibId.valueOf(elementType)) {
            GROUNDING,
            CONNECTIVITY,
            PORT_1PH,
            PORT_3PH ->
                return ValidationError("api.scheme.validation.error.branch.not.supported.type").left()

            else -> PrimitiveEquipment.PrimitiveEquipmentLibId.valueOf(elementType)
        }
        return UpdateBranchCommand(
            id = id,
            equipmentId = validEquipmentId,
            name = variableName,
            isResistive = isResistive,
            resistance = resistance?.validate()?.getOrElse
            { return it.left() } ?: 0.0,
            conductivity = conductivity?.validate()?.getOrElse
            { return it.left() } ?: 0.0,
            elementType = elementTypeEnum
        ).right()
    }


}

private fun Double.validate(): Either<ValidationError, Double> {
    return if (this !in MIN_VALUE..MAX_VALUE) {
        ValidationError("api.scheme.validation.error.branch.value.not.in.bound").left()
    } else this.right()
}
