package ru.nti.dtps.equipmentmanager.inputs.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import ru.nti.dtps.equipmentmanager.inputs.rest.CreateInputSignalCommand

interface CreateInputSignal {
    fun execute(command: CreateInputSignalCommand): Either<CreateInputSignalUseCaseError, InputSignal>
}

sealed class CreateInputSignalUseCaseError {
    class InputSignalNameAlreadyExistError(val name: String) : CreateInputSignalUseCaseError()
    class VariableNameAlreadyExistsError(val name: String) : CreateInputSignalUseCaseError()
}
