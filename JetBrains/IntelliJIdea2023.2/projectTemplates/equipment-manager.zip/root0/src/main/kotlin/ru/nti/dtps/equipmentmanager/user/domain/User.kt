package ru.nti.dtps.equipmentmanager.user.domain

import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.UserId

data class User internal constructor(
    val id: UserId,
    val companyId: CompanyId,
    val firstName: String,
    val lastName: String
) {

    var removed: Boolean = false

    fun generateFullName() = "#[[\$]]#firstName #[[\$]]#lastName"

    companion object {
        fun create(
            id: UserId,
            companyId: CompanyId,
            firstName: String,
            lastName: String
        ): User {
            return User(id, companyId, firstName, lastName)
        }

        fun restore(
            id: UserId,
            companyId: CompanyId,
            firstName: String,
            lastName: String,
            removed: Boolean
        ): User {
            return User(id, companyId, firstName, lastName).apply { this.removed = removed }
        }
    }
}