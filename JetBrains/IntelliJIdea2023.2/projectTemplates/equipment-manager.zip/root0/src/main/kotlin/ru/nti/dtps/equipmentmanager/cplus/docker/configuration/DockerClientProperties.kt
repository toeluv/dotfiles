package ru.nti.dtps.equipmentmanager.cplus.docker.configuration

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.stereotype.Component

@Component
@ConfigurationProperties(prefix = "docker.client")
data class DockerClientProperties(
    var host: String = "",
    var username: String = "",
    var certPath: String = "",
)

