package ru.nti.dtps.equipmentmanager.scheme.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.command.Command
import ru.nti.dtps.equipmentmanager.scheme.usecase.scenarios.CommandExecutionError

interface ExecuteSchemeEditorCommand {
    fun execute(command: Command): Either<CommandExecutionError, Scheme>
}
