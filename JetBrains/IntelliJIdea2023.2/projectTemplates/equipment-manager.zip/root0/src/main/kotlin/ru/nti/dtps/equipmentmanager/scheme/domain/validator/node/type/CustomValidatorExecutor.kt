package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.SchemeEditorError

interface CustomValidatorExecutor {
    fun validateIfNeed(
        node: PrimitiveEquipment,
        scheme: Scheme
    ): Either<SchemeEditorError, Unit>
}

interface CustomValidator {
    fun validate(node: PrimitiveEquipment, scheme: Scheme): Either<SchemeEditorError, Unit>
}