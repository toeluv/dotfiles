package ru.nti.dtps.equipmentmanager.cplus.domain

import ru.nti.dtps.equipmentmanager.common.types.DataType
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentFullView
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import ru.nti.dtps.equipmentmanager.scheme.domain.OptionLibId
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment.PrimitiveEquipmentLibId.*
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme

private const val WIDE_WHITESPACE = "        "
private const val SHORT_WHITESPACE = "    "

class CppTemplate(
    val equipmentFullView: EquipmentFullView,
    val scheme: Scheme
) {

    fun generateTemplate() =
        """
        \#include Magic.h

        class Element{
        public:
        
         struct Settings{
            #[[\$]]#{buildSettings(equipmentFullView)}
         };

         struct Input{
            #[[\$]]#{buildInputs(equipmentFullView)}
         };

         struct Output{
            #[[\$]]#{buildOutputs(equipmentFullView)}
         };

         struct Electrical{
            #[[\$]]#{buildBranches(scheme)}
            #[[\$]]#{buildNodes(scheme)}
         };

         struct MutualElectrical{
            #[[\$]]#{buildMutualities(scheme)}
         };
        };
        """.trimStart().replace(WIDE_WHITESPACE, "")

    private fun buildSettings(equipmentFullView: EquipmentFullView) = equipmentFullView.parameters
        .joinToString("\n#[[\$]]#SHORT_WHITESPACE") { generateSetting(it) }

    private fun buildInputs(equipmentFullView: EquipmentFullView) = equipmentFullView.inputSignals
        .joinToString("\n#[[\$]]#SHORT_WHITESPACE") { generateInput(it) }

    private fun buildOutputs(equipmentFullView: EquipmentFullView) = equipmentFullView.outputSignals
        .joinToString("\n#[[\$]]#SHORT_WHITESPACE") { generateOutput(it) }

    private fun buildBranches(scheme: Scheme) = scheme.primitiveNodes.values
        .filterNot { it.type in equipmentsWithoutVariableNameOption }
        .joinToString("\n#[[\$]]#SHORT_WHITESPACE") { generateBranch(it) }

    private fun buildNodes(scheme: Scheme) = scheme.primitiveNodes.values
        .filter { it.type in listOf(PORT_1PH, PORT_3PH) }
        .joinToString("\n#[[\$]]#SHORT_WHITESPACE") { generateNode(it) }

    private fun buildMutualities(scheme: Scheme) =
        scheme.mutualBranches.map { it.variableName.toStringValue() }.joinToString(("\n#[[\$]]#SHORT_WHITESPACE")) {
            "MUTUAL_BRANCH(#[[\$]]#{it})"
        }

    private fun generateSetting(parameter: Parameter) =
        when (parameter.dataType) {
            DataType.FLOAT -> "real_T #[[\$]]#{parameter.variableName.toStringValue()}{0};"
            DataType.INTEGER -> "int32_T #[[\$]]#{parameter.variableName.toStringValue()}{0};"
            DataType.BOOLEAN -> "boolean_T #[[\$]]#{parameter.variableName.toStringValue()}{false};"
        }

    private fun generateInput(inputSignal: InputSignal) =
        when (inputSignal.dataType) {
            DataType.FLOAT -> "REAL_INPUT #[[\$]]#{inputSignal.variableName.toStringValue()}"
            DataType.INTEGER -> "INT_INPUT #[[\$]]#{inputSignal.variableName.toStringValue()}"
            DataType.BOOLEAN -> "BOOL_INPUT #[[\$]]#{inputSignal.variableName.toStringValue()}"
        }

    private fun generateOutput(outputSignal: OutputSignal) =
        when (outputSignal.dataType) {
            DataType.FLOAT -> "REAL_OUTPUT #[[\$]]#{outputSignal.variableName.toStringValue()}"
            DataType.INTEGER -> "INT_OUTPUT #[[\$]]#{outputSignal.variableName.toStringValue()}"
            DataType.BOOLEAN -> "BOOL_OUTPUT #[[\$]]#{outputSignal.variableName.toStringValue()}"
        }

    private fun generateBranch(primitiveEquipment: PrimitiveEquipment) =
        "BRANCH(#[[\$]]#{primitiveEquipment.options[OptionLibId.VARIABLE_NAME]})"

    private fun generateNode(primitiveEquipment: PrimitiveEquipment) =
        if (primitiveEquipment.type == PORT_1PH) {
            "NODE(#[[\$]]#{primitiveEquipment.options[OptionLibId.VARIABLE_NAME]})"
        } else {
            "THREE_PHASE_NODE(#[[\$]]#{primitiveEquipment.options[OptionLibId.VARIABLE_NAME]})"
        }
}

private val equipmentsWithoutVariableNameOption = setOf(
    GROUNDING,
    CONNECTIVITY
)