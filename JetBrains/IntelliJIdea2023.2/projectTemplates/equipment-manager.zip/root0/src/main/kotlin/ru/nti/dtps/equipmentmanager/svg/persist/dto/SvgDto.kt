package ru.nti.dtps.equipmentmanager.svg.persist.dto

import java.util.*

class SvgDto(
    val id: UUID,
    val svgScheme: ByteArray?,
    val svgLib: ByteArray?
)  {
    companion object {
        fun create(id: UUID) = SvgDto(id, null, null)
        fun restore(
            id: UUID,
            svgScheme: ByteArray,
            svgLib: ByteArray
        ) = SvgDto(
            id, svgScheme, svgLib
        )
    }
}
