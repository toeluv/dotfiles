package ru.nti.dtps.equipmentmanager.cplus.usecase.access

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.cplus.adapter.CppFolderManager
import ru.nti.dtps.equipmentmanager.cplus.docker.adapter.getVolumeName
import ru.nti.dtps.equipmentmanager.cplus.usecase.DeleteTemplateFile

@Component
class DeleteCppTemplateFile(
    private val cppFolderManager: CppFolderManager
): DeleteTemplateFile {
    override fun execute(equipmentId: EquipmentId) {
        cppFolderManager.deleteFolder(equipmentId.getVolumeName())
    }
}