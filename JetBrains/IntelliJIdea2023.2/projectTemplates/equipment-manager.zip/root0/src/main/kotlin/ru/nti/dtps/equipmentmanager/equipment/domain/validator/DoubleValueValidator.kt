package ru.nti.dtps.equipmentmanager.equipment.domain.validator

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.DataType

@Component
class DoubleValueValidator : InputValueValidator {
    override fun validate(
        minValue: String,
        maxValue: String,
        defaultValue: String
    ): Either<InputValueError, Unit> {
        val minValueDouble = minValue.toDoubleOrNull()
        val maxValueDouble = maxValue.toDoubleOrNull()
        val lowLimit = 3.4E-38
        val highLimit = 3.4E+38
        val defaultValueDouble = defaultValue.toDoubleOrNull()
        return if (minValueDouble == null || maxValueDouble == null || defaultValueDouble == null
            || minValueDouble !in lowLimit..highLimit
            || maxValueDouble !in lowLimit..highLimit
            || defaultValueDouble !in lowLimit..highLimit
        ) {
            InputValueError.InvalidInputValueFormat.left()
        } else if (minValueDouble >= maxValueDouble || defaultValueDouble !in minValueDouble..maxValueDouble) {
            InputValueError.InvalidInputValueRange.left()
        } else Unit.right()
    }

    override fun getDataType() = DataType.FLOAT
}