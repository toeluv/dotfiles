package ru.nti.dtps.equipmentmanager.scheme.domain.validator

abstract class AbstractSchemeValidator(private val level: Level) : SchemeValidator {
    enum class Level(val number: Int) {
        ZERO(0),
        FIRST(1),
        SECOND(2),
        THIRD(3),
        FOURTH(4)
    }

    override fun getLevelNumber() = level.number
}
