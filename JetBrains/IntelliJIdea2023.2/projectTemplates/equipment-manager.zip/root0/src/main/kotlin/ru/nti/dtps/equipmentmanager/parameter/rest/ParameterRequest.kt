package ru.nti.dtps.equipmentmanager.parameter.rest


import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.types.ParameterName
import ru.nti.dtps.equipmentmanager.common.util.ValidationError

data class CreateParameterRequest(
    val id: String,
    val name: String,
    val groupId: String,
    val unitType: String,
    val dataType: String,
    val minValue: String,
    val maxValue: String,
    val defaultValue: String,
    val variableName: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, CreateParameterCommand> {
        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }
        val parameterId = ParameterId.validated(id).getOrElse { return it.left() }
        val name = ParameterName.validated(name).getOrElse { return it.left() }
        val variableName = VariableName.validated(variableName).getOrElse { return it.left() }
        return CreateParameterCommand(
            parameterId,
            validEquipmentId,
            name,
            groupId,
            UnitType.valueOf(unitType),
            DataType.valueOf(dataType),
            minValue,
            maxValue,
            defaultValue,
            variableName
        ).right()
    }
}

data class UpdateParameterRequest(
    val id: String,
    val name: String,
    val groupId: String,
    val unitType: String,
    val dataType: String,
    val minValue: String,
    val maxValue: String,
    val defaultValue: String,
    val variableName: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, UpdateParameterCommand> {
        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }
        val parameterId = ParameterId.validated(id).getOrElse { return it.left() }
        val name = ParameterName.validated(name).getOrElse { return it.left() }
        val variableName = VariableName.validated(variableName).getOrElse { return it.left() }
        return UpdateParameterCommand(
            parameterId,
            validEquipmentId,
            name,
            groupId,
            UnitType.valueOf(unitType),
            DataType.valueOf(dataType),
            minValue,
            maxValue,
            defaultValue,
            variableName
        ).right()
    }
}

data class DeleteParameterRequest(
    val id: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, DeleteParameterCommand> {
        EquipmentId.validated(equipmentId).mapLeft { return it.left() }
        val parameterId = ParameterId.validated(id).getOrElse { return it.left() }
        return DeleteParameterCommand(parameterId).right()
    }
}