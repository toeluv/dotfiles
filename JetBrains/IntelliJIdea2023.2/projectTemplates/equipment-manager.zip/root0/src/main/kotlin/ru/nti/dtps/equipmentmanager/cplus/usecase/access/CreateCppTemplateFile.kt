package ru.nti.dtps.equipmentmanager.cplus.usecase.access

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.cplus.domain.CppTemplateFile
import ru.nti.dtps.equipmentmanager.cplus.adapter.CppFolderManager
import ru.nti.dtps.equipmentmanager.cplus.docker.adapter.getVolumeName
import ru.nti.dtps.equipmentmanager.cplus.usecase.CreateTemplateFile
import ru.nti.dtps.equipmentmanager.cplus.usecase.CreateTemplateFileError
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentFullView
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalExtractor
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalExtractor
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterExtractor
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.userVariable.adapter.UserVariableExtractor
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable

@Component
class CreateCppTemplateFile(
    private val cppFolderManager: CppFolderManager,
    private val equipmentExtractor: EquipmentExtractor,
    private val inputSignalExtractor: InputSignalExtractor,
    private val outputSignalExtractor: OutputSignalExtractor,
    private val equipmentParameterExtractor: ParameterExtractor,
    private val userVariableExtractor: UserVariableExtractor,
    private val schemeExtractor: SchemeExtractor
) : CreateTemplateFile {
    override fun execute(equipmentId: EquipmentId): Either<CreateTemplateFileError, Unit> {
        val equipment = equipmentExtractor.getById(equipmentId)
            ?: return CreateTemplateFileError.EquipmentNotExistsError.left()

        val equipmentFullView = equipment.buildEquipmentFullView(
            equipmentParameterExtractor.getAllByEquipmentId(equipment.id).toSet(),
            inputSignalExtractor.getAllByEquipmentId(equipment.id).toSet(),
            outputSignalExtractor.getAllByEquipmentId(equipment.id).toSet(),
            userVariableExtractor.getAllByEquipmentId(equipment.id).toSet()
        )

        val scheme = schemeExtractor.getById(equipmentId.toUUID())
            ?: return CreateTemplateFileError.SchemeNotExistsError.left()

        CppTemplateFile.from(equipmentFullView, scheme).let { template ->
            cppFolderManager.createFolderIfNotExists(equipmentId.getVolumeName())
            cppFolderManager.createFile(equipmentId.getVolumeName(), template.name, template.content)
            return Unit.right()
        }
    }

    private fun Equipment.buildEquipmentFullView(
        parameters: Set<Parameter>,
        inputSignals: Set<InputSignal>,
        outputSignals: Set<OutputSignal>,
        userVariables: Set<UserVariable>
    ): EquipmentFullView {

        return EquipmentFullView.restore(
            id = this.id,
            companyId = this.companyId,
            name = this.name,
            groupId = this.groupId,
            description = this.description,
            author = this.author,
            createdAt = this.createdAt,
            publicationInfo = this.publicationInfo,
            published = this.published,
            version = this.version,
            editor = this.editor,
            updatedAt = this.updatedAt,
            parameters = parameters,
            inputSignals = inputSignals,
            outputSignals = outputSignals,
            userVariables = userVariables
        )
    }
}