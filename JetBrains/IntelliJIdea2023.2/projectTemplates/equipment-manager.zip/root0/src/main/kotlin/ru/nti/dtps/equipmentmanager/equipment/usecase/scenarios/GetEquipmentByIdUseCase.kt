package ru.nti.dtps.equipmentmanager.equipment.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.GetEquipmentById
import ru.nti.dtps.equipmentmanager.equipment.usecase.GetEquipmentByIdUseCaseError
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class GetEquipmentByIdUseCase(
    private val equipmentExtractor: EquipmentExtractor,
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider
) : GetEquipmentById {
    override fun execute(equipmentId: EquipmentId): Either<GetEquipmentByIdUseCaseError, Equipment> {
        val equipment = equipmentExtractor
            .getByIdAndCompanyId(equipmentId, currentUserCompanyIdProvider.get())
            ?: return GetEquipmentByIdUseCaseError.EquipmentNotExistsUseCaseError.left()
        return equipment.right()
    }
}