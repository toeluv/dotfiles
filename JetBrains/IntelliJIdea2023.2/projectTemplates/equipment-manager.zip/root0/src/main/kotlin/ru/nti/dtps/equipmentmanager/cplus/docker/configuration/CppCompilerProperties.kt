package ru.nti.dtps.equipmentmanager.cplus.docker.configuration

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.cplus.docker.domain.Image
import ru.nti.dtps.equipmentmanager.cplus.docker.domain.RequiredImageProvider

@Component
@ConfigurationProperties(prefix = "docker.cpp-compiler")
class CppCompilerImageProperties : RequiredImageProvider {
    var image = ""
    var tag = ""

    fun getImageTag() = "#[[\$]]#image:#[[\$]]#tag"

    override fun invoke() = Image(image, tag)
}