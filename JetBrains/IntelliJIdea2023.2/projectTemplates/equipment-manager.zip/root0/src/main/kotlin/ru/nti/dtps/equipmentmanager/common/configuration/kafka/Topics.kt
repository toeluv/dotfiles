package ru.nti.dtps.equipmentmanager.common.configuration.kafka

object Topics {
    const val USER_EVENT = "user.event"
    const val EQUIPMENT_EVENT = "equipment.event"
}