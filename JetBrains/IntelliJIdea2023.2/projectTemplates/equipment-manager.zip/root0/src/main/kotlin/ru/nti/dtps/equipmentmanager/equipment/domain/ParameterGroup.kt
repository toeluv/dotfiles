package ru.nti.dtps.equipmentmanager.equipment.domain

class ParameterGroup private constructor(
    val id: String,
    val companyId: String,
    val name: String
) {
    companion object {
        fun create(
            id: String,
            companyId: String,
            name: String
        ) = ParameterGroup(
            id, companyId, name
        )

        fun restore(
            id: String,
            companyId: String,
            name: String
        ) = ParameterGroup(
            id, companyId, name
        )
    }
}