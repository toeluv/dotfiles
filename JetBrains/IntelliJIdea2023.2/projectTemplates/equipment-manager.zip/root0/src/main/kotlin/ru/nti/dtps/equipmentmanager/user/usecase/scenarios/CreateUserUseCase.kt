package ru.nti.dtps.equipmentmanager.user.usecase.scenarios

import arrow.core.Either
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import ru.nti.dtps.equipmentmanager.user.persist.adapter.UserPersister
import ru.nti.dtps.equipmentmanager.user.domain.command.CreateUserCommand
import ru.nti.dtps.equipmentmanager.user.domain.User
import ru.nti.dtps.equipmentmanager.user.usecase.CreateUser

@Service
class CreateUserUseCase(
    private val userPersister: UserPersister
) : CreateUser {

    private val logger = LoggerFactory.getLogger(CreateUserUseCase::class.java)

    override fun execute(command: CreateUserCommand) {
        return Either.catch {
            userPersister.save(
                User.create(command.userId, command.companyId, command.firstName, command.lastName)
            )
        }.fold(
            { error -> logger.error("Error create user cause: {}", error.message, error) },
            { logger.info("User {} was created", command.userId.toStringValue()) }

        )
    }
}