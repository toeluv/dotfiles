package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipment.meta.info.dataclass.common.Language
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.FieldType
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.OptionLib
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.NumberValidator

@Component
class MaxNumberValidator : NumberValidator {
    override fun validate(
        optionValueString: String,
        optionLib: OptionLib,
        fieldType: FieldType,
        equipment: PrimitiveEquipment
    ): Either<SchemeValidationError, Unit> {
        val optionValueDouble = try {
            optionValueString.toDouble()
        } catch (e: NumberFormatException) {
            throw IllegalArgumentException(
                "Equipment #[[\$]]#{equipment.name} (#[[\$]]#{equipment.type}) has field #[[\$]]#{optionLib.name[Language.RU.name]} " +
                    "with value #[[\$]]#optionValueString that must be a number"
            )
        }
        val max = (optionLib.max ?: fieldType.max)!!
        return if (optionValueDouble > max) {
            FieldValueMoreThenLimitValueError(
                equipment.id,
                equipment.name,
                optionLib,
                max
            ).left()
        } else {
            Unit.right()
        }
    }
}

class FieldValueMoreThenLimitValueError(
    val equipmentId: String,
    val equipmentName: String,
    val optionLib: OptionLib,
    val boundValue: Double
) : SchemeValidationError
