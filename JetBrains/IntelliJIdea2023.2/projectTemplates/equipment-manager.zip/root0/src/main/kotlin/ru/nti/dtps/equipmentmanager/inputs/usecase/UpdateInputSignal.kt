package ru.nti.dtps.equipmentmanager.inputs.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import ru.nti.dtps.equipmentmanager.inputs.rest.UpdateInputSignalCommand

interface UpdateInputSignal {
    fun execute(command: UpdateInputSignalCommand): Either<UpdateInputSignalUseCaseError, InputSignal>
}

sealed class UpdateInputSignalUseCaseError {
    class VariableNameAlreadyExistsError(val name: String) : UpdateInputSignalUseCaseError()
    class InputSignalNameAlreadyExistError(val name: String) : UpdateInputSignalUseCaseError()
    object InputSignalNotFoundError : UpdateInputSignalUseCaseError()
}
