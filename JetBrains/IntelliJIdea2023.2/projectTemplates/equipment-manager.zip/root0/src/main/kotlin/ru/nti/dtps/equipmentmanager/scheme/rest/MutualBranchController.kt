package ru.nti.dtps.equipmentmanager.scheme.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.ArraySchema
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.scheme.domain.MutualBranch
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.rest.request.CreateBranchRequest
import ru.nti.dtps.equipmentmanager.scheme.rest.request.UpdateBranchRequest
import ru.nti.dtps.equipmentmanager.scheme.usecase.*

@RestController
class MutualBranchController(
    private val messageSource: MessageSourceService,
    private val createBranch: CreateMutualBranch,
    private val getAllBranches: GetMutualBranches,
    private val updateBranch: UpdateMutualBranch,
    private val deleteBranch: DeleteMutualBranch
) {
    @Operation(summary = "Execute get all mutual branches command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Mutual branches were found", content = [
                    (Content(
                        mediaType = "application/json",
                        array = ArraySchema(schema = Schema(implementation = MutualBranchView::class))
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Scheme not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )

    @GetMapping("#[[\$]]#API_V1_SCHEME_MUTUALITY/{equipmentId}")
    fun getAllMutualBranches(
        @PathVariable equipmentId: String
    ): ResponseEntity<*> {
        return EquipmentId.validated(equipmentId)
            .fold({ it.toRestError() },
                { validEquipmentId ->
                    getAllBranches.execute(validEquipmentId)
                        .fold(
                            { error -> error.toRestError() },
                            { branches -> ok(branches.map { it.toView() }) }
                        )
                })
    }

    @Operation(summary = "Execute create mutual branch command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Mutual branch was created", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = MutualBranchView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported mutual branch type", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400",
                description = "Primitive equipment option \"Variable name\" has not unique value",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Scheme not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PostMapping("#[[\$]]#API_V1_SCHEME_MUTUALITY/{equipmentId}")
    fun createMutualBranch(
        @PathVariable equipmentId: String,
        @RequestBody createBranchRequest: CreateBranchRequest
    ): ResponseEntity<*> {
        return createBranchRequest.buildCommand(equipmentId)
            .fold({ it.toRestError() },
                {
                    createBranch.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { branch -> ok(branch.toView()) }
                        )
                })
    }

    @Operation(summary = "Execute update mutual branch command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Mutual branch was updated", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = MutualBranchView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported mutual branch type", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400",
                description = "Primitive equipment option \"Variable name\" has not unique value",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Scheme not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Mutual branch not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PutMapping("#[[\$]]#API_V1_SCHEME_MUTUALITY/{equipmentId}")
    fun updateMutualBranch(
        @PathVariable equipmentId: String,
        @RequestBody updateBranchRequest: UpdateBranchRequest
    ): ResponseEntity<*> {
        return updateBranchRequest.buildCommand(equipmentId)
            .fold({ it.toRestError() },
                {
                    updateBranch.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { branch -> ok(branch.toView()) }
                        )
                })
    }

    @Operation(summary = "Execute delete mutual branch command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Mutual branch was deleted", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = MutualBranchView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Scheme not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Mutual branch not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @DeleteMapping("#[[\$]]#API_V1_SCHEME_MUTUALITY/{equipmentId}")
    fun deleteMutualBranch(
        @PathVariable equipmentId: String,
        @RequestBody deleteBranchCommand: DeleteBranchCommand
    ): ResponseEntity<*> {
        return EquipmentId.validated(equipmentId)
            .fold({ it.toRestError() },
                {
                    deleteBranch.execute(it, deleteBranchCommand)
                        .fold(
                            { error -> error.toRestError() },
                            { ok(Unit) }
                        )
                })
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun GetAllBranchesUseCaseError.toRestError() = when (this) {
        GetAllBranchesUseCaseError.SchemeNotFoundError -> restBusinessError(
            messageSource.getMessage("api.scheme.error.not-found"),
            HttpStatus.NOT_FOUND
        )
    }

    private fun CreateMutualBranchUseCaseError.toRestError() = when (this) {
        is CreateMutualBranchUseCaseError.VariableNameAlreadyExistsError ->
            restBusinessError(
                messageSource.getMessage("api.scheme.error.equipment.variable.name.twins").format(this.value),
                HttpStatus.CONFLICT
            )

        CreateMutualBranchUseCaseError.SchemeNotFoundError -> restBusinessError(
            messageSource.getMessage("api.scheme.error.not-found"),
            HttpStatus.NOT_FOUND
        )
    }

    private fun UpdateBranchUseCaseError.toRestError() = when (this) {
        is UpdateBranchUseCaseError.VariableNameAlreadyExistsError -> restBusinessError(
            messageSource.getMessage("api.scheme.error.equipment.variable.name.twins").format(this.value),
            HttpStatus.CONFLICT
        )

        is UpdateBranchUseCaseError.MutualBranchNotFoundError -> restBusinessError(
            messageSource.getMessage("api.scheme.error.branch.not-found"),
            HttpStatus.NOT_FOUND
        )

        UpdateBranchUseCaseError.SchemeNotFoundError -> restBusinessError(
            messageSource.getMessage("api.scheme.error.not-found"),
            HttpStatus.NOT_FOUND
        )

    }

    private fun DeleteBranchUseCaseError.toRestError() = when (this) {
        is DeleteBranchUseCaseError.SchemeNotFoundError -> restBusinessError(
            messageSource.getMessage("api.scheme.error.not-found"),
            HttpStatus.NOT_FOUND
        )

        is DeleteBranchUseCaseError.MutualBranchNotFoundError -> restBusinessError(
            messageSource.getMessage("api.scheme.error.branch.not-found"),
            HttpStatus.NOT_FOUND
        )
    }
}

data class CreateBranchCommand(
    val id: String,
    val equipmentId: EquipmentId,
    var name: VariableName,
    var isResistive: Boolean,
    var resistance: Double,
    var conductivity: Double,
    val elementType: PrimitiveEquipment.PrimitiveEquipmentLibId
)

data class UpdateBranchCommand(
    val id: String,
    val equipmentId: EquipmentId,
    var name: VariableName,
    var isResistive: Boolean,
    var resistance: Double,
    var conductivity: Double,
    val elementType: PrimitiveEquipment.PrimitiveEquipmentLibId
)

data class DeleteBranchCommand(
    val id: String
)

data class MutualBranchView(
    val id: String,
    var name: String,
    var isResistive: Boolean,
    var resistance: Double,
    var conductivity: Double,
    var elementType: String
)

private fun MutualBranch.toView() = MutualBranchView(
    id,
    variableName.toStringValue(),
    isResistive,
    resistance,
    conductivity,
    elementType.name
)