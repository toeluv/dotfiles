package ru.nti.dtps.equipmentmanager.userVariable.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserVariableId
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable

interface UserVariableExtractor {
    fun getAllByEquipmentId(equipmentId: EquipmentId): Collection<UserVariable>
    fun getById(id: UserVariableId): UserVariable?
}