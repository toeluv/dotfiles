package ru.nti.dtps.equipmentmanager.scheme.aaa.jdbc

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.Point
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeLink
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeLinkExtractor
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeLinkPersister
import ru.nti.dtps.proto.scheme.link.EquipmentLink
import java.sql.ResultSet
import java.util.*

@Component
class SchemeLinkRepository(
    private val jdbcTemplate: NamedParameterJdbcTemplate,
) : SchemeLinkExtractor, SchemeLinkPersister {
    private val jackObjectMapper: ObjectMapper = jacksonObjectMapper()

    override fun extract(equipmentId: EquipmentId, linkId: UUID): SchemeLink? {
        val params = mapOf(
            "link_id" to linkId,
            "parent_id" to equipmentId.toUUID()
        )
        return jdbcTemplate.query(
            "SELECT * FROM public.scheme_link WHERE link_id = :link_id AND parent_id = :parent_id",
            params,
            SchemeLinkResultSetExtractor()
        )?.toDomain()
    }

    override fun insert(schemeLink: SchemeLink) {
        val params = mapOf(
            "link_id" to schemeLink.id,
            "parent_id" to schemeLink.parentId,
            "params" to jackObjectMapper.writeValueAsString(schemeLink.toJdbcDto().params),
        )
        jdbcTemplate.update(
            """
        INSERT INTO public.scheme_link(link_id, parent_id, params)
        VALUES(
            :link_id, 
            :parent_id,
            :params, 
        )
        """.trimIndent(), params
        )
    }

    override fun update(schemeLink: SchemeLink) {
        val params = mapOf(
            "link_id" to schemeLink.id,
            "parent_id" to schemeLink.parentId,
            "params" to jackObjectMapper.writeValueAsString(schemeLink.toJdbcDto().params),
        )
        jdbcTemplate.update(
            """
            UPDATE public.scheme_link SET
            params = :params
            WHERE link_id = :link_id AND parent_id = :parent_id
        """.trimIndent(), params
        )
    }

    override fun delete(parentId: UUID, id: UUID) {
        val params = mapOf(
            "link_id" to id,
            "parent_id" to parentId,
        )
        jdbcTemplate.update(
            "DELETE from public.scheme_link where link_id = :link_id AND parent_id = :parent_id",
            params
        )
    }

    class SchemeLinkJdbc(
        val id: UUID,
        val parentId: UUID,
        val params: SchemeLinkParamsJdbc
    )

    class SchemeLinkParamsJdbc(
        val alignmentType: EquipmentLink.AlignmentType,
        val sourceNode: UUID,
        val targetNode: UUID,
        val sourcePort: UUID,
        val targetPort: UUID,
        val points: List<Point>,
    )

    private fun SchemeLink.toJdbcDto() = SchemeLinkJdbc(
        id = this.id,
        parentId = this.parentId,
        params = SchemeLinkParamsJdbc(
            alignmentType = this.alignmentType,
            sourceNode = this.sourceNode,
            targetNode = this.targetNode,
            sourcePort = this.sourcePort,
            targetPort = this.targetPort,
            points = this.points
        )
    )

    private fun SchemeLinkJdbc.toDomain() = SchemeLink(
        id = this.id,
        parentId = this.parentId,
        alignmentType = this.params.alignmentType,
        sourceNode = this.params.sourceNode,
        targetNode = this.params.targetNode,
        sourcePort = this.params.sourcePort,
        targetPort = this.params.targetPort,
        points = this.params.points
    )
}

class SchemeLinkResultSetExtractor : ResultSetExtractor<SchemeLinkRepository.SchemeLinkJdbc> {
    override fun extractData(rs: ResultSet): SchemeLinkRepository.SchemeLinkJdbc? {
        return if (rs.next()) {
            SchemeLinkRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class SchemeLinkRowMapper : RowMapper<SchemeLinkRepository.SchemeLinkJdbc> {
    private val objectMapper = jacksonObjectMapper()

    override fun mapRow(rs: ResultSet, rowNum: Int): SchemeLinkRepository.SchemeLinkJdbc {
        val id = rs.getObject("id", UUID::class.java)
        val parentId = rs.getObject("parent_id", UUID::class.java)
        val paramsString = rs.getString("params")

        val params =
            objectMapper.readValue(paramsString, SchemeLinkRepository.SchemeLinkParamsJdbc::class.java)

        return SchemeLinkRepository.SchemeLinkJdbc(
            id, parentId, params
        )
    }
}