package ru.nti.dtps.equipmentmanager.common.configuration

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.stereotype.Component
import java.util.*

@Component
@ConfigurationProperties(prefix = "app")
data class AppProperties(
    var language: String = "ru"
) {
    fun getLocale(): Locale = Locale.forLanguageTag(language)
}