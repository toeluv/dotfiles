package ru.nti.dtps.equipmentmanager.equipment.persist.groups

import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.EquipmentGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.EquipmentGroupPersister
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.ParameterGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.ParameterGroupPersister
import java.util.*
import javax.sql.DataSource

@Component
class GroupRepository(
    dataSource: DataSource,
) : ParameterGroupPersister, ParameterGroupExtractor,
    EquipmentGroupPersister, EquipmentGroupExtractor {

    /*
    * group types:
    * 1 - equipment_group
    * 2 - parameter_group
    * */

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)


    override fun getAllEquipmentGroupsByCompanyId(companyId: CompanyId): Collection<EquipmentGroup> {
        return jdbcTemplate.query(
            "SELECT * FROM public.groups WHERE company_id=:company_id AND group_type = 1",
            mapOf("company_id" to companyId.toUUID()),
            EquipmentGroupRowMapper()
        )
    }

    override fun getEquipmentGroupById(equipmentGroupId: String): EquipmentGroup? {
        return jdbcTemplate.query(
            "SELECT * FROM public.groups WHERE id = :id AND group_type = 1",
            mapOf("id" to equipmentGroupId),
            EquipmentGroupResultSetExtractor()
        )
    }

    override fun getEquipmentGroupByIdAndCompanyId(equipmentGroupId: String, companyId: CompanyId): EquipmentGroup? {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.groups 
            WHERE id = :id 
            AND company_id = :company_id 
            AND group_type = 1
            """.trimMargin(),
            mapOf("id" to equipmentGroupId, "company_id" to companyId.toUUID()),
            EquipmentGroupResultSetExtractor()
        )

    }

    @Transactional
    override fun save(equipmentGroup: EquipmentGroup) {
        val params = mapOf(
            "id" to equipmentGroup.id,
            "company_id" to UUID.fromString(equipmentGroup.companyId),
            "group_type" to 1,
            "name" to equipmentGroup.name,
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.groups(id, company_id, group_type, name)
            VALUES(
            :id, 
            :company_id, 
            :group_type, 
            :name)
            """.trimMargin(), params
        )
    }

    override fun delete(equipmentGroup: EquipmentGroup) {
        jdbcTemplate.update(
            "DELETE FROM public.groups WHERE id=:id AND group_type = 1",
            mapOf("id" to equipmentGroup.id)
        )
    }

    override fun checkEquipmentGroupAlreadyExists(groupName: String, companyId: CompanyId): Boolean {
        return jdbcTemplate.query(
            """
            SELECT EXISTS 
            ( SELECT 1 FROM public.groups 
              WHERE name =:name 
              AND company_id =:company_id 
              AND group_type = 1 )
            """.trimMargin(),
            mapOf("name" to groupName, "company_id" to companyId.toUUID()),
            ResultSetExtractor {
                it.next()
                return@ResultSetExtractor it.getBoolean(1)
            }
        )!!
    }

    override fun getAllParameterGroupsByCompanyId(companyId: CompanyId): Collection<ParameterGroup> {
        return jdbcTemplate.query(
            "SELECT * FROM public.groups WHERE company_id=:company_id AND group_type = 1",
            mapOf("company_id" to companyId.toUUID()),
            ParameterGroupRowMapper()
        )
    }

    override fun getParameterGroupById(parameterGroupId: String): ParameterGroup? {
        return jdbcTemplate.query(
            "SELECT * FROM public.groups WHERE id = :id AND group_type = 2",
            mapOf("id" to parameterGroupId),
            ParameterGroupResultSetExtractor()
        )
    }

    override fun getParameterGroupByIdAndCompanyId(parameterGroupId: String, companyId: CompanyId): ParameterGroup? {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.groups 
            WHERE id = :id 
            AND company_id = :company_id 
            AND group_type = 2
            """.trimMargin(),
            mapOf("id" to parameterGroupId, "company_id" to companyId.toUUID()),
            ParameterGroupResultSetExtractor()
        )

    }

    @Transactional
    override fun save(parameterGroup: ParameterGroup) {
        val params = mapOf(
            "id" to parameterGroup.id,
            "company_id" to UUID.fromString(parameterGroup.companyId),
            "group_type" to 2,
            "name" to parameterGroup.name,
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.groups(id, company_id, group_type, name)
            VALUES(
            :id, 
            :company_id, 
            :group_type, 
            :name)
            """.trimMargin(), params
        )
    }

    override fun delete(parameterGroup: ParameterGroup) {
        jdbcTemplate.update(
            "DELETE FROM public.groups WHERE id=:id AND group_type = 2",
            mapOf("id" to parameterGroup.id)
        )
    }

    override fun checkParameterGroupAlreadyExists(groupName: String, companyId: CompanyId): Boolean {
        return jdbcTemplate.query(
            """
            SELECT EXISTS 
            ( SELECT 1 FROM public.groups 
              WHERE name =:name 
              AND company_id =:company_id 
              AND group_type = 2 )
            """.trimMargin(),
            mapOf("name" to groupName, "company_id" to companyId),
            ResultSetExtractor {
                it.next()
                return@ResultSetExtractor it.getBoolean(1)
            }
        )!!
    }
}