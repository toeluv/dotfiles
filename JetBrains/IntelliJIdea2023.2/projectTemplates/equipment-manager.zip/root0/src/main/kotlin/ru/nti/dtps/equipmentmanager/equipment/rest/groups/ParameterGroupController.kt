package ru.nti.dtps.equipmentmanager.equipment.rest.groups

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.ArraySchema
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.*

@RestController
class ParameterGroupController(
    private val getAllGroups: GetAllParameterGroups,
    private val createGroup: CreateParameterGroup,
    private val getGroupById: GetParameterGroupById,
    private val deleteGroup: DeleteParameterGroup,
    private val messageSource: MessageSourceService
) {
    
    @Operation(summary = "Get all parameter groups")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Get all parameter groups request success", content = [
                    (Content(
                        mediaType = "application/json",
                        array = ArraySchema(schema = Schema(implementation = ParameterGroupShortView::class))
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )]
    )
    @GetMapping(API_V1_PARAMETER_GROUP)
    fun getAll(): ResponseEntity<*> {
        return getAllGroups.execute()
            .map { it.toShortView() }
            .let { ok(it) }
    }

    @Operation(summary = "Create new parameter group")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Parameter group created", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = ParameterGroupShortView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409", description = "Parameter group with current name is already exist", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )]
    )
    @PostMapping(API_V1_PARAMETER_GROUP)
    fun create(@RequestBody command: CreateParameterGroupCommand): ResponseEntity<*> {
        return createGroup.execute(command)
            .fold(
                { it.toRestError() },
                { createdGroup ->
                    ok(createdGroup)
                }
            )
    }

    @Operation(summary = "Get parameter group by id")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Parameter group by id request success", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = ParameterGroupShortView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Parameter group was not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )]
    )
    @GetMapping("#[[\$]]#API_V1_PARAMETER_GROUP/{groupId}")
    fun getById(@PathVariable groupId: String): ResponseEntity<*> {
        return getGroupById.execute(groupId)
            .fold(
                { it.toRestError() },
                { parameterGroup -> ok(parameterGroup) }
            )
    }

    @Operation(summary = "Delete existing parameter group")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Parameter group deleted", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = ParameterGroupShortView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Parameter group was not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Parameter group is not empty", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )]
    )
    @DeleteMapping("#[[\$]]#API_V1_PARAMETER_GROUP/{groupId}")
    fun deleteIfEmpty(@PathVariable groupId: String): ResponseEntity<*> {
        return deleteGroup.execute(DeleteParameterGroupCommand(groupId))
            .fold(
                { it.toRestError() },
                { deletedGroup -> ok(deletedGroup) }
            )
    }

    private fun CreateParameterGroupUseCaseError.toRestError() =
        when (this) {
            is CreateParameterGroupUseCaseError.ParameterGroupNameAlreadyExistUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.parameter.group.error.validation.twins").format(name),
                    HttpStatus.CONFLICT
                )
        }

    private fun GetParameterGroupByIdUseCaseError.toRestError() =
        when (this) {
            is GetParameterGroupByIdUseCaseError.ParameterGroupNotExistsUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.parameter.group.error.not-exist"),
                    HttpStatus.CONFLICT
                )
        }

    private fun DeleteParameterGroupUseCaseError.toRestError() =
        when (this) {
            is DeleteParameterGroupUseCaseError.ParameterGroupNotExistUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.parameter.group.error.not-exist"),
                    HttpStatus.NOT_FOUND
                )

            is DeleteParameterGroupUseCaseError.ParameterGroupIsNotEmptyUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.parameter.group.error.not-empty"),
                    HttpStatus.BAD_REQUEST
                )
        }

}

private fun ParameterGroup.toShortView() = ParameterGroupShortView(
    this.id,
    this.name
)

data class ParameterGroupShortView(
    val id: String,
    val name: String
)

data class CreateParameterGroupCommand(
    val id: String,
    val name: String
)

data class DeleteParameterGroupCommand(
    val id: String
)
