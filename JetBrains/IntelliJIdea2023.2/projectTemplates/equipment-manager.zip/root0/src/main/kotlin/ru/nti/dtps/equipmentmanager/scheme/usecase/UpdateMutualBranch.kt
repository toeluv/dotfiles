package ru.nti.dtps.equipmentmanager.scheme.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.scheme.domain.MutualBranch
import ru.nti.dtps.equipmentmanager.scheme.rest.UpdateBranchCommand

interface UpdateMutualBranch {
    fun execute(updateBranchCommand: UpdateBranchCommand): Either<UpdateBranchUseCaseError, MutualBranch>
}

sealed class UpdateBranchUseCaseError {
    object SchemeNotFoundError : UpdateBranchUseCaseError()
    class MutualBranchNotFoundError(val value: String) : UpdateBranchUseCaseError()
    class VariableNameAlreadyExistsError(val value: String) : UpdateBranchUseCaseError()

}
