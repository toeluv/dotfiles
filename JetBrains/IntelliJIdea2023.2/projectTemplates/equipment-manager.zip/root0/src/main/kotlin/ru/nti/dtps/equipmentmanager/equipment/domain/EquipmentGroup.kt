package ru.nti.dtps.equipmentmanager.equipment.domain

class EquipmentGroup private constructor(
    val id: String,
    val companyId: String,
    val name: String
) {
    companion object {
        fun create(
            id: String,
            companyId: String,
            name: String
        ) = EquipmentGroup (
            id, companyId, name
        )

        fun restore(
            id: String,
            companyId: String,
            name: String
        ) = EquipmentGroup(
            id, companyId, name
        )
    }
}