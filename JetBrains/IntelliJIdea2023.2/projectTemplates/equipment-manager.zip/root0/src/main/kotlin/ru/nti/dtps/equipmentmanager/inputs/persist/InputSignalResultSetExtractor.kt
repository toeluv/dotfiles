package ru.nti.dtps.equipmentmanager.inputs.persist

import arrow.core.getOrElse
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import java.sql.ResultSet

class InputSignalResultSetExtractor : ResultSetExtractor<InputSignal> {
    override fun extractData(rs: ResultSet): InputSignal? {
        return if (rs.next()) {
            InputSignalRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class InputSignalRowMapper : RowMapper<InputSignal> {

    private val logger = LoggerFactory.getLogger(InputSignalRowMapper::class.java)

    override fun mapRow(rs: ResultSet, rowNum: Int): InputSignal? {
        val idString = rs.getString("id")
        val equipmentIdString = rs.getString("equipment_id")
        val nameString = rs.getString("name")
        val unitTypeString = rs.getString("unit_type")
        val dataTypeString = rs.getString("data_type")
        val variableNameString = rs.getString("variable_name")

        return InputSignal.restore(
            id = InputSignalId.from(idString).getOrElse {
                logger.error("Incorrect input signal id #[[\$]]#idString")
                return null
            },
            equipmentId = EquipmentId.from(idString).getOrElse {
                logger.error("Incorrect equipment id #[[\$]]#equipmentIdString")
                return null
            },
            name = InputSignalName.from(nameString).getOrElse {
                logger.error("Incorrect input signal name #[[\$]]#nameString")
                return null
            },
            unitType = UnitType.valueOf(unitTypeString),
            dataType = DataType.valueOf(dataTypeString),
            variableName = VariableName.from(variableNameString).getOrElse {
                logger.error("Incorrect variable name #[[\$]]#variableNameString")
                return null
            }
        )
    }
}
