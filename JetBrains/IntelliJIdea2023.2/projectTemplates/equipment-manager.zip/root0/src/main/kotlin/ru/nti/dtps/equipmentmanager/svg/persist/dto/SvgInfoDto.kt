package ru.nti.dtps.equipmentmanager.svg.persist.dto

import ru.nti.dtps.equipmentmanager.svg.domain.Dimensions
import ru.nti.dtps.equipmentmanager.svg.domain.Placeholder
import ru.nti.dtps.equipmentmanager.svg.domain.SvgPort
import ru.nti.dtps.equipmentmanager.svg.domain.XyCoords
import java.util.UUID

class SvgInfoDto(
    val id: UUID,
    val coords: XyCoords?,
    val dimensions: Dimensions?,
    val hour: Int?,
    val ports: List<SvgPort>,
    val placeholders: List<Placeholder>
) {
    companion object {
        fun create(id: UUID) = SvgInfoDto(
            id,
            null,
            null,
            null,
            listOf(),
            listOf()
        )

        fun create(
            id: UUID,
            coords: XyCoords?,
            dimensions: Dimensions?,
            hour: Int?,
            ports: List<SvgPort>,
            placeholders: List<Placeholder>
        ) = SvgInfoDto(
            id, coords, dimensions, hour, ports, placeholders
        )

        fun restore(
            id: UUID,
            coords: XyCoords?,
            dimensions: Dimensions?,
            hour: Int?,
            ports: List<SvgPort>,
            placeholders: List<Placeholder>
        ) = SvgInfoDto(
            id, coords, dimensions, hour, ports, placeholders
        )
    }
}
