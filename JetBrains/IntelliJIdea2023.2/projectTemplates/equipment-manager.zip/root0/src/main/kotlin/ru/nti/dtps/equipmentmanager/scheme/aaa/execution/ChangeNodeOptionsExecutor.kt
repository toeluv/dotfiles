package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.NodeOptionsExtractor
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeNodeExtractor
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.ComplexNodeValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeToValidate
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId

@Component
class ChangeNodeOptionsExecutor(
    private val nodeOptionsExtractor: NodeOptionsExtractor,
    private val schemeNodeExtractor: SchemeNodeExtractor,
    private val validator: ComplexNodeValidator
) : CommandExecutor<ChangeNodeOptionsUserCommand> {

    private val logger = LoggerFactory.getLogger(ChangeNodeOptionsExecutor::class.java)

    override fun execute(command: ChangeNodeOptionsUserCommand): Either<CommandExecutionError, ChangeNodeOptionsUserCommandSuccessResult> {

        val nodeOptions = nodeOptionsExtractor.extract(command.equipmentId, command.nodeId)
        val schemeNode = schemeNodeExtractor.extract(command.equipmentId, command.nodeId)

        if (nodeOptions == null || schemeNode == null) {
            //todo update while unredoable creation
            logger.warn("Node with id #[[\$]]#{command.nodeId} not found, unredoable was canceled for batch command")
            return NodeNotFoundError(command.nodeId.toString()).left()
        }

        return ChangeNodeOptionsUserCommandSuccessResult(schemeNode, nodeOptions, command).let { commandResult ->
            validator.validate(commandResult.getNodeToValidate()).fold(
                { ValidationCommandExecutionError(it).left() },
                { commandResult.right() }
            )
        }
    }
}

class ChangeNodeOptionsUserCommandSuccessResult(
    val schemeNode: SchemeNode,
    val nodeOptions: NodeOptions,

    val command: ChangeNodeOptionsUserCommand
) : CommandSuccessResult {
    override fun undo() = ChangeNodeOptionsUserCommand(
        nodeId = command.nodeId,
        equipmentId = command.equipmentId,
        body = ChangeNodeParams(
            id = command.nodeId,
            options = nodeOptions.options,
            payload = schemeNode.payload
        )
    )

    override fun editorCommands(): List<EditorCommand> {
        return listOf(
            ChangeSchemeNodeEditorCommand.build(command, schemeNode),
            ChangeNodeOptionsEditorCommand.build(command, schemeNode)
        )
    }

    fun getNodeToValidate(): NodeToValidate {
        return object : NodeToValidate {
            override fun id() = command.nodeId

            override fun equipmentId() = command.equipmentId

            override fun options(): Map<OptionLibId, String?> = command.body.options

            override fun type(): PrimitiveEquipmentLibId = nodeOptions.nodeType

        }
    }
}