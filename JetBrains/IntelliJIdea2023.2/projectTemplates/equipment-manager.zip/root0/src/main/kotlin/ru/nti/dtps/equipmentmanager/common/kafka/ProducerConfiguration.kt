package ru.nti.dtps.equipmentmanager.common.kafka

import org.apache.kafka.clients.producer.ProducerConfig
import org.apache.kafka.common.serialization.Serializer
import org.apache.kafka.common.serialization.StringSerializer
import org.springframework.boot.autoconfigure.kafka.KafkaProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.kafka.annotation.EnableKafka
import org.springframework.kafka.core.DefaultKafkaProducerFactory
import org.springframework.kafka.core.KafkaTemplate
import org.springframework.kafka.core.ProducerFactory
import ru.nti.dtps.equipmentmanager.common.configuration.kafka.KafkaSaslProperties
import ru.nti.dtps.equipmentmanager.common.configuration.kafka.Topics.EQUIPMENT_EVENT
import ru.nti.dtps.equipmentmanager.equipment.kafka.EquipmentEventMessage
import ru.nti.dtps.equipmentmanager.equipment.kafka.EquipmentEventMessageSerializer

@EnableKafka
@Configuration
class ProducerConfiguration(
    private val kafkaProperties: KafkaProperties,
    private val kafkaSaslProperties: KafkaSaslProperties
) {
    @Bean
    fun equipmentEventTemplate(): KafkaTemplate<String, EquipmentEventMessage> {
        return createKafkaTemplate(EquipmentEventMessageSerializer::class.java).apply {
            defaultTopic = EQUIPMENT_EVENT
        }
    }

    private fun <S, V> createKafkaTemplate(
        serializerClass: Class<S>
    ): KafkaTemplate<String, V> where S : Serializer<V> {
        val saslProperties = kafkaSaslProperties.getSaslProperties()
        val producerFactory: ProducerFactory<String, V> = DefaultKafkaProducerFactory(
            mapOf(
                ProducerConfig.ACKS_CONFIG to kafkaProperties.producer.acks,
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG to kafkaProperties.bootstrapServers,
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG to StringSerializer::class.java,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG to serializerClass,
            ).plus(saslProperties)
        )
        return KafkaTemplate(producerFactory)
    }
}