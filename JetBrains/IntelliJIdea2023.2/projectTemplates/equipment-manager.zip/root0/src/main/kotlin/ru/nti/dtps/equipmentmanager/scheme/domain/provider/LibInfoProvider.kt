package ru.nti.dtps.equipmentmanager.scheme.domain.provider

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.*
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment.PrimitiveEquipmentLibId
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.*
import java.util.*

const val EQUIPMENT_LIB_PATH = "library/PrimitiveEquipmentLibrary.json"
const val FIELD_TYPES_PATH = "library/PrimitiveFieldTypes.json"
const val PRIMITIVE_PORT_SIGNAL_INFO_PATH = "library/PrimitivePortSignalInfo.json"

@Component
class LibInfoProvider : LibInfoExtractor {

    private val equipmentLibIdToInfoMap: MutableMap<PrimitiveEquipmentLibId, EquipmentLib> = mutableMapOf()
    private val fieldTypeIdToInfoMap: MutableMap<FieldTypeId, FieldType> = mutableMapOf()
    private val primitivePortSignalInfo: MutableList<PrimitivePortSignalInfo> = mutableListOf()

    init {
        val objectMapper = jacksonObjectMapper()
        val classLoader = Thread.currentThread().contextClassLoader

        val equipmentsInputStream = load(objectMapper, classLoader, Array<EquipmentLib>::class.java, EQUIPMENT_LIB_PATH)
        val fieldTypesInputStream = load(objectMapper, classLoader, Array<FieldType>::class.java, FIELD_TYPES_PATH)
        val primitivePortSignalInfoStream = load(
            objectMapper, classLoader, Array<PrimitivePortSignalInfo>::class.java, PRIMITIVE_PORT_SIGNAL_INFO_PATH
        )

        equipmentLibIdToInfoMap.putAll(equipmentsInputStream.associateBy { it.id })
        fieldTypeIdToInfoMap.putAll(fieldTypesInputStream.associateBy { it.id })
        primitivePortSignalInfo.addAll(primitivePortSignalInfoStream)
    }

    override fun getEquipmentLibById(equipmentLibId: PrimitiveEquipmentLibId): EquipmentLib {
        return equipmentLibIdToInfoMap[equipmentLibId] ?: error("There is no equipment with id: #[[\$]]#equipmentLibId")
    }

    override fun getFieldTypeLibById(fieldTypeId: FieldTypeId): FieldType {
        return fieldTypeIdToInfoMap[fieldTypeId] ?: error("There is no field type with id: #[[\$]]#fieldTypeId")
    }

    override fun getPrimitivePortSignalInfo(): List<PrimitivePortSignalInfo> {
        return primitivePortSignalInfo
    }

    private fun <K> load(
        objectMapper: ObjectMapper,
        classloader: ClassLoader,
        clazz: Class<Array<K>>?,
        path: String?,
    ): Array<K> {
        val inputStream = classloader.getResourceAsStream(path)
        val libElements = objectMapper.readValue(Objects.requireNonNull(inputStream).readAllBytes(), clazz)
        inputStream?.close()
        return libElements
    }
}

data class EquipmentLib(
    val id: PrimitiveEquipmentLibId,
    val height: Double,
    val width: Double,
    val name: Map<String, String>,
    val labelDirection: String,
    val svg: String,
    val ports: List<PortLib> = listOf(),
    val options: List<OptionLib> = listOf()
)

data class OptionLib(
    val id: OptionLibId,
    val typeId: FieldTypeId,
    val name: Map<String, String>,
    val regex: String?,
    val minLength: Long?,
    val maxLength: Long?,
    val min: Double?,
    val max: Double?,
    val step: Double?,
    val optional: Boolean = false
)

data class PortLib(
    val libId: PortLibId,
    val alignment: Alignment,
    val x: Double,
    val y: Double
)

data class FieldType(
    val id: FieldTypeId,
    val valueType: OptionValueType,
    val min: Double?,
    val max: Double?,
    val step: Double?,
    val regex: String?,
    val length: Int?,
    val minLength: Int?,
    val maxLength: Int?,
    val options: List<Option> = listOf(),
) {
    data class Option(
        val key: String,
        val value: String
    )
}

data class PrimitivePortSignalInfo(
    val id: String,
    val name: String,
    val dimension: String
)
