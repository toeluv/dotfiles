package ru.nti.dtps.equipmentmanager.parameter.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import ru.nti.dtps.equipmentmanager.parameter.rest.UpdateParameterCommand

interface UpdateParameter {
    fun execute(command: UpdateParameterCommand): Either<UpdateParameterUseCaseError, Parameter>
}
sealed class UpdateParameterUseCaseError {
    object ParameterHasInvalidValueFormatError : UpdateParameterUseCaseError()
    object ParameterHasInvalidValueRangeError : UpdateParameterUseCaseError()
    object ParameterNotFoundError : UpdateParameterUseCaseError()
    class ParameterNameAlreadyExistsError(val name: String) : UpdateParameterUseCaseError()
    class VariableNameAlreadyExistsError(val name: String) : UpdateParameterUseCaseError()
}