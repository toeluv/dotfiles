package ru.nti.dtps.equipmentmanager.scheme.domain

enum class PortLibId {
    FIRST,
    SECOND,
    THIRD,
    FOURTH
}