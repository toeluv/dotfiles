package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.ChangeLinkPointEditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.EditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeLink
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeLinkExtractor

@Component
class ChangeLinkPointsExecutor(
    val schemeLinkExtractor: SchemeLinkExtractor
) : CommandExecutor<ChangeLinkPointsUserCommand> {

    private val logger = LoggerFactory.getLogger(ChangeLinkPointsUserCommand::class.java)

    override fun execute(command: ChangeLinkPointsUserCommand): Either<CommandExecutionError, ChangeLinkPointsUserCommandSuccessResult> {
        return schemeLinkExtractor.extract(command.equipmentId, command.nodeId)?.let {
            ChangeLinkPointsUserCommandSuccessResult(it, command).right()
        } ?: LinkNotFoundError(command.nodeId.toString()).left()

    }
}

class ChangeLinkPointsUserCommandSuccessResult(
    val schemeLink: SchemeLink,
    val command: ChangeLinkPointsUserCommand
) : CommandSuccessResult {
    override fun undo() = ChangeLinkPointsUserCommand(
        nodeId = command.nodeId,
        equipmentId = command.equipmentId,
        body = ChangeLinkPoints(
            id = command.nodeId,
            points = schemeLink.points
        )
    )

    override fun editorCommands(): List<EditorCommand> {
        return listOf(
            ChangeLinkPointEditorCommand.build(command, schemeLink),
        )
    }
}