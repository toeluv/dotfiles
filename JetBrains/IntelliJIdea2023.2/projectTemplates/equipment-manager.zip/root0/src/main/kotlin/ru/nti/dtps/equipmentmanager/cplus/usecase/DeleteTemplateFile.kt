package ru.nti.dtps.equipmentmanager.cplus.usecase

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId

interface DeleteTemplateFile {
    fun execute(equipmentId: EquipmentId)
}

