package ru.nti.dtps.equipmentmanager.userVariable.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserVariableId
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable

interface UserVariablePersister {
    fun save(userVariable: UserVariable)
    fun update(userVariable: UserVariable)
    fun delete(id: UserVariableId)
    fun deleteAllByEquipmentId(equipmentId: EquipmentId)
}