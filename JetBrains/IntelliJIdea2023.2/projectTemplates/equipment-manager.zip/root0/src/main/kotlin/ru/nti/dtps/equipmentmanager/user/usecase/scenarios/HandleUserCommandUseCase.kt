package ru.nti.dtps.equipmentmanager.user.usecase.scenarios

import org.springframework.stereotype.Service
import ru.nti.dtps.equipmentmanager.user.domain.command.CreateUserCommand
import ru.nti.dtps.equipmentmanager.user.domain.command.DeleteUserCommand
import ru.nti.dtps.equipmentmanager.user.domain.command.UpdatedUserCommand
import ru.nti.dtps.equipmentmanager.user.domain.command.UserCommand
import ru.nti.dtps.equipmentmanager.user.usecase.CreateUser
import ru.nti.dtps.equipmentmanager.user.usecase.DeleteUser
import ru.nti.dtps.equipmentmanager.user.usecase.HandleUserCommand
import ru.nti.dtps.equipmentmanager.user.usecase.UpdateUser

@Service
class HandleUserCommandUseCase(
    private val createUser: CreateUser,
    private val deleteUser: DeleteUser,
    private val updateUser: UpdateUser
) : HandleUserCommand {

    override fun handle(userCommand: UserCommand) {
        return when(userCommand) {
            is CreateUserCommand -> createUser.execute(userCommand)
            is DeleteUserCommand -> deleteUser.execute(userCommand)
            is UpdatedUserCommand -> updateUser.execute(userCommand)
            else -> Unit
        }
    }
}
