package ru.nti.dtps.equipmentmanager.scheme.aaa.jdbc

import arrow.core.getOrElse
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.MutualBranchId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.MutualBranch
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.PrimitiveEquipmentLibId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.MutualBranchExtractor
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.MutualBranchPersister
import java.sql.ResultSet
import java.util.*

@Component
class MutualBranchRepository(
    private val jdbcTemplate: NamedParameterJdbcTemplate,
) : MutualBranchExtractor, MutualBranchPersister {

    override fun extract(ids: List<MutualBranchId>): List<MutualBranch> {
        val params = MapSqlParameterSource("ids", ids.map { it.toUUID() })
        return jdbcTemplate.query(
            "SELECT * FROM public.mutual_branch WHERE id IN (:ids)",
            params,
            MutualBranchRowMapper()
        )
    }

    override fun extract(id: MutualBranchId): MutualBranch? {
        val params = mapOf(
            "id" to id.toUUID()
        )

        return jdbcTemplate.query(
            "SELECT * FROM public.mutual_branch WHERE id = :id",
            params,
            MutualBranchResultSetExtractor()
        )
    }

    override fun extract(id: EquipmentId): List<MutualBranch> {
        val params = mapOf(
            "equipment_id" to id.toUUID()
        )

        return jdbcTemplate.query(
            "SELECT * FROM public.mutual_branch WHERE equipment_id = :equipment_id",
            params,
            MutualBranchRowMapper()
        )
    }

    override fun insert(mutualBranch: MutualBranch) {
        val params = mapOf(
            "id" to mutualBranch.id.toUUID(),
            "equipment_id" to mutualBranch.equipmentId.toUUID(),
            "variable_name" to mutualBranch.variableName.toStringValue(),
            "is_resistive" to mutualBranch.isResistive,
            "resistance" to mutualBranch.resistance,
            "conductivity" to mutualBranch.conductivity,
            "element_type" to mutualBranch.elementType.toString()
        )
        jdbcTemplate.update(
            """
        INSERT INTO public.mutual_branch(id, equipment_id, variable_name,is_resistive,resistance,conductivity,element_type)
        VALUES(
            :id, 
            :equipment_id,
            :variable_name,
            :is_resistive,
            :resistance,
            :conductivity,
            :element_type
       )
        """.trimIndent(), params
        )
    }

    override fun update(mutualBranch: MutualBranch) {
        val params = mapOf(
            "id" to mutualBranch.id.toUUID(),
            "equipment_id" to mutualBranch.equipmentId.toUUID(),
            "variable_name" to mutualBranch.variableName.toStringValue(),
            "is_resistive" to mutualBranch.isResistive,
            "resistance" to mutualBranch.resistance,
            "conductivity" to mutualBranch.conductivity,
            "element_type" to mutualBranch.elementType.toString()
        )
        jdbcTemplate.update(
            """
            UPDATE public.mutual_branch SET
            equipment_id = :equipment_id,
            variable_name = :variable_name,
            is_resistive = :is_resistive,
            resistance = :resistance,
            conductivity = :conductivity,
            element_type = :element_type            
            WHERE id = :id
        """.trimIndent(), params
        )
    }

    override fun delete(mutualBranchId: MutualBranchId) {
        val params = mapOf(
            "id" to mutualBranchId.toUUID()
        )
        jdbcTemplate.update(
            "DELETE from public.mutual_branch where id = :id",
            params
        )
    }

}

class MutualBranchResultSetExtractor : ResultSetExtractor<MutualBranch> {
    override fun extractData(rs: ResultSet): MutualBranch? {
        return if (rs.next()) {
            MutualBranchRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class MutualBranchRowMapper : RowMapper<MutualBranch> {

    override fun mapRow(rs: ResultSet, rowNum: Int): MutualBranch {
        val id = rs.getObject("id", UUID::class.java)
        val equipmentId = rs.getObject("equipment_id", UUID::class.java)
        val name = rs.getString("variable_name")
        val isResistive = rs.getBoolean("is_resistive")
        val resistance = rs.getDouble("resistance")
        val conductivity = rs.getDouble("conductivity")
        val elementTypeSting = rs.getString("element_type")

        return MutualBranch(
            id = MutualBranchId(id),
            equipmentId = EquipmentId(equipmentId),
            variableName = VariableName.from(name).getOrElse { error("Invalid variable name for mutual branch #[[\$]]#{id}") },
            isResistive = isResistive,
            resistance = resistance,
            conductivity = conductivity,
            elementType = PrimitiveEquipmentLibId.valueOf(elementTypeSting)
        )
    }
}