package ru.nti.dtps.equipmentmanager.scheme.aaa.editor

import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId
import java.util.*

class NodeOptions(
    val id: UUID,
    val parentId: UUID,
    val nodeType: PrimitiveEquipmentLibId,
    val options: Map<OptionLibId, String?>,
)
