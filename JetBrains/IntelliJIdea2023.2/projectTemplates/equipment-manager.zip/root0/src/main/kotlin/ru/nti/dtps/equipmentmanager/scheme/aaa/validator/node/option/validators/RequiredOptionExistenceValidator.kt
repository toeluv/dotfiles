package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.validators

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionFieldsValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId

class RequiredOptionExistenceValidator(
    private val requiredFields: Set<OptionLibId>
) : OptionFieldsValidator {
    override fun order() = -9999

    override fun validate(options: Map<OptionLibId, String?>): Either<OptionValidationError, Unit> {

        return requiredFields.firstOrNull() {
            !options.containsKey(it) || options[it] == null
        }?.let {
            return RequiredFieldNotFoundError(it).left()
        } ?: Unit.right()
    }
}

class RequiredFieldNotFoundError(
    val optionLib: OptionLibId
) : OptionValidationError
