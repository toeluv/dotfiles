package ru.nti.dtps.equipmentmanager.cplus.docker.domain

fun interface RequiredImageProvider {
    operator fun invoke(): Image
}