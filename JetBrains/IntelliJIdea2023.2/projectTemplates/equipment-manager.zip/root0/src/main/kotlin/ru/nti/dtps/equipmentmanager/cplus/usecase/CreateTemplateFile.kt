package ru.nti.dtps.equipmentmanager.cplus.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId

interface CreateTemplateFile {
    fun execute(equipmentId: EquipmentId): Either<CreateTemplateFileError, Unit>
}

sealed class CreateTemplateFileError : UseCaseError {
    object EquipmentNotExistsError : CreateTemplateFileError()
    object SchemeNotExistsError : CreateTemplateFileError()
}
