package ru.nti.dtps.equipmentmanager.scheme.domain.validator

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme

interface ComplexSchemeValidator {
    fun validate(scheme: Scheme): Either<SchemeValidationError, Unit>
}
