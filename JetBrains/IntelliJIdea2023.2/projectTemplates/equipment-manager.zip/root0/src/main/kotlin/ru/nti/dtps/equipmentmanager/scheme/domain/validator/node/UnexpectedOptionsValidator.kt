package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.OptionLib

@Component
class UnexpectedOptionsValidator {
    companion object {
        fun validate(
            equipment: PrimitiveEquipment,
            optionLibs: List<OptionLib>
        ) {
            val unexpectedOptions = equipment.options.keys.filter { optionLibId ->
                !optionLibs.any { it.id == optionLibId }
            }
            if (unexpectedOptions.isNotEmpty()) {
                throw IllegalArgumentException(
                    "Equipment #[[\$]]#{equipment.name} (#[[\$]]#{equipment.type}) contains unexpected option(-s) #[[\$]]#unexpectedOptions"
                )
            }
        }
    }
}