package ru.nti.dtps.equipmentmanager.scheme.aaa.jdbc

import org.springframework.stereotype.Component
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.TransactionDefinition
import org.springframework.transaction.TransactionStatus
import org.springframework.transaction.support.TransactionCallbackWithoutResult
import org.springframework.transaction.support.TransactionTemplate
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.NodeOptionsPersiter
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeLinkPersister
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeNodePersister
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemePersister

@Component
class BatchCommandPersister(
    val schemePersister: SchemePersister,
    val schemeLinkPersister: SchemeLinkPersister,
    val schemeNodePersister: SchemeNodePersister,
    val nodeOptionsPersister: NodeOptionsPersiter,
    transactionManager: PlatformTransactionManager
) {

    private val transactionTemplate = TransactionTemplate(transactionManager).apply {
        isolationLevel = TransactionDefinition.ISOLATION_READ_COMMITTED
    }


    fun persist(executedBatch: CommandEditorBatch) {
        transactionTemplate.execute(object : TransactionCallbackWithoutResult() {
            override fun doInTransactionWithoutResult(status: TransactionStatus) {
                executedBatch.commands.forEach { execute(it) }
                schemePersister.update(executedBatch.scheme)
            }
        })
    }


    fun execute(command: EditorCommand) {
        when (command) {
            is CreateSchemeNodeEditorCommand -> schemeNodePersister.insert(command.schemeNode)
            is ChangeSchemeNodeEditorCommand -> schemeNodePersister.update(command.schemeNode)
            is DeleteSchemeNodeEditorCommand -> schemeNodePersister.delete(parentId = command.parentId, id = command.id)
            is CreateSchemeLinkEditorCommand -> schemeLinkPersister.insert(command.schemeLink)
            is ChangeLinkPointEditorCommand -> schemeLinkPersister.update(command.schemeLink)
            is DeleteSchemeLinkEditorCommand -> schemeLinkPersister.delete(parentId = command.parentId, id = command.id)
            is CreateNodeOptionsEditorCommand -> nodeOptionsPersister.insert(command.nodeOptions)
            is ChangeNodeOptionsEditorCommand -> nodeOptionsPersister.update(command.nodeOptions)
            is DeleteNodeOptionsEditorCommand -> nodeOptionsPersister.delete(
                parentId = command.parentId,
                id = command.id
            )
        }
    }
}

class CommandEditorBatch(
    val scheme: Scheme,
    val commands: List<EditorCommand>
)