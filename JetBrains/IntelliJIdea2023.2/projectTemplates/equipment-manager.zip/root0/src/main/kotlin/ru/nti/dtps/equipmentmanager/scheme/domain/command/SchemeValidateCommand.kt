package ru.nti.dtps.equipmentmanager.scheme.domain.command

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserId

class SchemeValidateCommand(
    val id: EquipmentId,
    val userId: UserId
)