package ru.nti.dtps.equipmentmanager.svg.usecase

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo

interface GetSignalsInfoByEquipment {
    fun execute(equipmentId: EquipmentId): List<SignalInfo>
}