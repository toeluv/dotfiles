package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.ChangeSchemeNodeEditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.EditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeNode
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeNodeExtractor

@Component
class ChangeNodeDimensionsExecutor(
    private val schemeNodeExtractor: SchemeNodeExtractor
) : CommandExecutor<ChangeNodeDimensionsUserCommand> {

    private val logger = LoggerFactory.getLogger(ChangeNodeDimensionsExecutor::class.java)

    override fun execute(command: ChangeNodeDimensionsUserCommand): Either<CommandExecutionError, ChangeNodeDimensionsUserCommandSuccessResult> {
        return schemeNodeExtractor.extract(command.equipmentId, command.nodeId)
            ?.let {
                ChangeNodeDimensionsUserCommandSuccessResult(it, command).right()
            } ?: NodeNotFoundError(command.nodeId.toString()).left()
    }
}

class ChangeNodeDimensionsUserCommandSuccessResult(
    val schemeNode: SchemeNode,
    val command: ChangeNodeDimensionsUserCommand
) : CommandSuccessResult {
    override fun undo() = ChangeNodeDimensionsUserCommand(
        nodeId = command.nodeId,
        equipmentId = command.equipmentId,
        body = ChangeNodeDimensions(
            id = command.nodeId,
            ports = schemeNode.ports,
            coords = schemeNode.coords,
            dimensions = schemeNode.dimensions
        )
    )

    override fun editorCommands(): List<EditorCommand> {
        return listOf(
            ChangeSchemeNodeEditorCommand.build(command, schemeNode),
        )
    }
}