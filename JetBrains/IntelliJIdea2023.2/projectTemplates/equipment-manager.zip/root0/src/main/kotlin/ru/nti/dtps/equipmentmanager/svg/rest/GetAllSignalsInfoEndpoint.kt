package ru.nti.dtps.equipmentmanager.svg.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo
import ru.nti.dtps.equipmentmanager.svg.usecase.GetSignalsInfoByEquipment

@RestController
class GetAllSignalsInfoEndpoint(
    private val messageSource: MessageSourceService,
    private val getSignalsInfoByEquipment: GetSignalsInfoByEquipment
) {

    @Operation(summary = "Get all signals by equipment")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Get all signals by equipment success", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = SignalInfoView::class)
                    ))]
            ),
            ApiResponse(responseCode = "500", description = "Something went wrong, go to admin",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                ))])]
    )
    @GetMapping("#[[\$]]#API_V1_EQUIPMENT_SIGNALS/{equipmentId}")
    fun getAllSignalsByEquipment(
        @PathVariable equipmentId: String
    ): ResponseEntity<*> {
        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    ok(
                        getSignalsInfoByEquipment
                            .execute(validEquipmentId)
                            .map { it.toResponseView() }
                    )
                }
            )
    }

    @Operation(summary = "Get all signals by equipment and group")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Get all signals by equipment and group success", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = SignalInfoView::class)
                    ))]
            ),
            ApiResponse(responseCode = "500", description = "Something went wrong, go to admin",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                ))])]
    )
    @GetMapping("#[[\$]]#API_V1_EQUIPMENT_SIGNALS/{equipmentId}/{groupId}")
    fun getAllSignalsByEquipmentAndGroup(
        @PathVariable equipmentId: String,
        @PathVariable groupId: String
    ): ResponseEntity<*> {
        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    ok(
                        getSignalsInfoByEquipment
                            .execute(validEquipmentId)
                            .filter { it.groupId == groupId }
                            .map { it.toResponseView() }
                    )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )
}

private fun SignalInfo.toResponseView() =
    SignalInfoView(
        this.id.toString(),
        this.name,
        this.dimension,
        this.dimensionForSimulation,
        this.conversionFactor,
        this.numberOfCharacters,
        this.showOnSimulation,
        this.groupId,
        this.sequence
    )

data class SignalInfoView(
    val id: String,
    val name: String,
    val dimension: String,
    val dimensionForSimulation: String?,
    val conversionFactor: Double?,
    val numberOfCharacters: Double,
    val showOnSimulation: Boolean,
    val groupId: String,
    val sequence: Int
)