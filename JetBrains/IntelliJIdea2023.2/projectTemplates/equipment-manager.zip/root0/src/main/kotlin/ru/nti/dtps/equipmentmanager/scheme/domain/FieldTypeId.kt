package ru.nti.dtps.equipmentmanager.scheme.domain

enum class FieldTypeId {
    NUMERIC,
    CURRENT,
    VOLTAGE,
    RESISTANCE,
    CONDUCTIVITY,
    INDUCTANCE,
    CAPACITANCE,
    TEXT,
    MUTUALITY_SELECT
}