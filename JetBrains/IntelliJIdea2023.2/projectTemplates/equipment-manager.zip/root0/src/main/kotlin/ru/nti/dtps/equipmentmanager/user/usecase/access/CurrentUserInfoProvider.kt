package ru.nti.dtps.equipmentmanager.user.usecase.access

import ru.nti.dtps.equipmentmanager.user.domain.User

interface CurrentUserInfoProvider {
    fun get(): User
}