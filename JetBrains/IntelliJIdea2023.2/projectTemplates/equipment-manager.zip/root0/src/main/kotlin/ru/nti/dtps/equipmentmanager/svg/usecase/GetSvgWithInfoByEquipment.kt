package ru.nti.dtps.equipmentmanager.svg.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.svg.usecase.scenarios.ComplexSvgInfo

interface GetSvgWithInfoByEquipment {
    fun execute(id: EquipmentId): Either<GetSvgWithInfoByEquipmentUseCaseError, ComplexSvgInfo>
}

sealed class GetSvgWithInfoByEquipmentUseCaseError : UseCaseError {
    object SvgInfoNotFound : GetSvgWithInfoByEquipmentUseCaseError()
    object SvgNotFound : GetSvgWithInfoByEquipmentUseCaseError()
}