package ru.nti.dtps.equipmentmanager.scheme.persist

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import java.sql.ResultSet

class SchemeResultSetExtractor : ResultSetExtractor<Scheme> {
    override fun extractData(rs: ResultSet): Scheme? {
        return if (rs.next()) {
            SchemeRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class SchemeRowMapper : RowMapper<Scheme> {
    private val objectMapper = jacksonObjectMapper()

    private val logger = LoggerFactory.getLogger(SchemeRowMapper::class.java)
    override fun mapRow(rs: ResultSet, rowNum: Int): Scheme? {
        return objectMapper.readValue<Scheme>(rs.getString("scheme"))
    }
}