package ru.nti.dtps.equipmentmanager.minio.adapter

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import io.minio.*
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import java.io.ByteArrayInputStream

private const val DEFAULT_CONTENT_TYPE = "application/octet-stream"

@Component
class MinioHttpApi(
    private val minioClient: MinioClient = MinioClient.builder().endpoint("mock").build(),
    private val sourceFolder: String = ""
) : MinioApi {

    private val logger = LoggerFactory.getLogger(javaClass)

    override fun createBucket(bucketName: String): Either<MinioAdapterError, Unit> {
        return Either.catch {
            minioClient.makeBucket(
                MakeBucketArgs.builder()
                    .bucket(bucketName)
                    .build()
            )
        }.fold(
            {
                logger.error("Create bucket error: {}", it.message)
                return MinioAdapterError.MinioAdapterCreateBucketError.left()
            }, {
                Unit.right()
            }
        )
    }

    override fun uploadFile(
        bucketName: String,
        uploadData: SchemeFile
    ): Either<MinioAdapterError, SchemeFileInfo> {
        return Either.catch {
            minioClient.putObject(
                PutObjectArgs.builder()
                    .bucket(bucketName)
                    .`object`(uploadData.name)
                    .stream(ByteArrayInputStream(uploadData.content), -1, 10485760)
                    .contentType(uploadData.contentType)
                    .build()
            )
        }.fold(
            {
                logger.error("Upload file with name: {} error: {}", uploadData.name, it.message)
                return MinioAdapterError.MinioAdapterUploadFileError.left()
            }, {
                it.toFileInfo().right()
            }
        )
    }

    override fun uploadFileFromSourceFolder(
        bucketName: String,
        fileName: String
    ): Either<MinioAdapterError, SchemeFileInfo> {
        return Either.catch {
            minioClient.uploadObject(
                UploadObjectArgs.builder()
                    .bucket(bucketName)
                    .`object`(fileName)
                    .filename(getAbsolutePath(fileName))
                    .build()
            )
        }.fold(
            {
                logger.error("Upload file with name: {} error: {}", fileName, it.message)
                return MinioAdapterError.MinioAdapterUploadFileError.left()
            }, {
                it.toFileInfo().right()
            }
        )
    }

    override fun deleteFile(bucketName: String, fileName: String): Either<MinioAdapterError, Unit> {
        return Either.catch {
            minioClient.removeObject(
                RemoveObjectArgs.builder()
                    .bucket(bucketName)
                    .`object`(fileName)
                    .build()
            )
        }.fold(
            {
                logger.error("Delete file with name: {} error: {}", fileName, it.message)
                return MinioAdapterError.MinioAdapterDeleteFileError.left()
            }, {
                Unit.right()
            }
        )
    }

    override fun downloadFile(bucketName: String, fileName: String): Either<MinioAdapterError, SchemeFile> {
        return Either.catch {
            minioClient.getObject(
                GetObjectArgs.builder()
                    .bucket(bucketName)
                    .`object`(fileName)
                    .build()
            )
        }.fold(
            {
                logger.error("Delete file with name: {} error: {}", fileName, it.message)
                return MinioAdapterError.MinioAdapterDownloadFileError.left()
            }, {
                it.toSchemeFile().right()
            }
        )
    }

    override fun downloadFileToSourceFolder(
        bucketName: String,
        fileName: String
    ): Either<MinioAdapterError, Unit> {
        return Either.catch {
            minioClient.downloadObject(
                DownloadObjectArgs.builder()
                    .bucket(bucketName)
                    .`object`(fileName)
                    .filename(getAbsolutePath(fileName))
                    .overwrite(true)
                    .build()
            )
        }.fold(
            {
                logger.error("Download file with name: {} error: {}", fileName, it.message)
                return MinioAdapterError.MinioAdapterDownloadFileError.left()
            },
            {
                Unit.right()
            }
        )
    }

    private fun getAbsolutePath(fileName: String) =
        "/#[[\$]]#{sourceFolder}/#[[\$]]#fileName"
}

private fun ObjectWriteResponse.toFileInfo() = SchemeFileInfo(
    name = `object`(),
    bucketName = bucket(),
    tag = etag(),
    versionId = versionId()
)

private fun GetObjectResponse.toSchemeFile() = SchemeFile(
    name = `object`(),
    contentType = headers()["Content-Type"] ?: DEFAULT_CONTENT_TYPE,
    content = readAllBytes(),
)