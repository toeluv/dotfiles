package ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter

import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup

interface EquipmentGroupPersister {
    fun save(equipmentGroup: EquipmentGroup)
    fun delete(equipmentGroup: EquipmentGroup)
}