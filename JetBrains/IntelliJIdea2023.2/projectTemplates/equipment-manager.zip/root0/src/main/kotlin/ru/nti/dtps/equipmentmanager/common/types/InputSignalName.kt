package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError

data class InputSignalName(
    val name: String
) {
    companion object {
        fun from(name: String): Either<CreateInputSignalNameError, InputSignalName> =
            if (name.isNotBlank()) {
                InputSignalName(name).right()
            } else {
                CreateInputSignalNameError.EmptyInputSignalName.left()
            }
    }

    fun toStringValue() = name

}
sealed class CreateInputSignalNameError : BusinessError {
    object EmptyInputSignalName : CreateInputSignalNameError()
}
