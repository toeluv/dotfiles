package ru.nti.dtps.equipmentmanager.user.kafka

import arrow.core.getOrElse
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.Deserializer
import org.slf4j.LoggerFactory
import org.springframework.kafka.annotation.KafkaListener
import org.springframework.kafka.support.Acknowledgment
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.configuration.kafka.Topics
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.UserId
import ru.nti.dtps.equipmentmanager.user.domain.command.CreateUserCommand
import ru.nti.dtps.equipmentmanager.user.domain.command.DeleteUserCommand
import ru.nti.dtps.equipmentmanager.user.domain.command.UpdatedUserCommand
import ru.nti.dtps.equipmentmanager.user.domain.command.UserCommand
import ru.nti.dtps.equipmentmanager.user.usecase.HandleUserCommand
import java.io.IOException
import java.nio.charset.StandardCharsets

const val USER_EVENT_KAFKA_LISTENER_CONTAINER_FACTORY = "userEventKafkaListenerContainerFactory"

@Component
class UserConsumer(
    private val handleUserCommand: HandleUserCommand
) {

    private val logger = LoggerFactory.getLogger(javaClass)

    @KafkaListener(
        topics = [Topics.USER_EVENT],
        containerFactory = USER_EVENT_KAFKA_LISTENER_CONTAINER_FACTORY
    )
    fun userEvent(consumerRecord: ConsumerRecord<String, UserEventDto>, ack: Acknowledgment) {
        logger.debug("Message received {}", consumerRecord)
        val userEvent = consumerRecord.value()
        if (userEvent == null) {
            logger.warn("Record {} was skipped cause value is null ", consumerRecord)
            ack.acknowledge()
            return
        }

        handleUserCommand.handle(userEvent.buildCommand())
    }

    private fun UserEventDto.buildCommand(): UserCommand {
        val validUserId = UserId.from(this.keycloakUserId).getOrElse {
            error("Invalid user id: #[[\$]]#{this.keycloakUserId}")
        }

        val validCompanyId = CompanyId.from(this.companyId).getOrElse {
            error("Invalid company id: #[[\$]]#{this.companyId}")
        }
        return when (this.eventType) {
            EventType.CREATE -> CreateUserCommand(validUserId, validCompanyId, firstName, lastName)
            EventType.UPDATE -> UpdatedUserCommand(validUserId, validCompanyId, firstName, lastName)
            EventType.DELETE -> DeleteUserCommand(validUserId)
        }
    }

}

class UserEventDtoDeserializer : Deserializer<UserEventDto> {
    private val objectMapper = jacksonObjectMapper()
    private val logger = LoggerFactory.getLogger(UserEventDtoDeserializer::class.java)
    override fun deserialize(topic: String, data: ByteArray): UserEventDto? {
        return if (data.isEmpty()) {
            null
        } else try {
            objectMapper.readValue(data, UserEventDto::class.java)

        } catch (exception: IOException) {
            val message = String(data, StandardCharsets.UTF_8)
            logger.error("Unable to deserialize user event: {}", message, exception)
            null
        }
    }
}

data class UserEventDto(
    val keycloakUserId: String,
    val companyId: String,
    val firstName: String,
    val lastName: String,
    val eventType: EventType,
    val timestamp: String
)

enum class EventType {
    CREATE, UPDATE, DELETE
}