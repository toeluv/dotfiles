package ru.nti.dtps.equipmentmanager.common.error

interface UseCaseError