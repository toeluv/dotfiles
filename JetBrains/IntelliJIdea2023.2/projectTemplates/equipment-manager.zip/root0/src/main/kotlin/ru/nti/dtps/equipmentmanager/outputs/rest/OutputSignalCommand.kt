package ru.nti.dtps.equipmentmanager.outputs.rest

import ru.nti.dtps.equipmentmanager.common.types.*


data class CreateOutputSignalCommand(
    val id: OutputSignalId,
    val equipmentId: EquipmentId,
    val name: OutputSignalName,
    val unitType: UnitType,
    val dataType: DataType,
    val variableName: VariableName
)

data class UpdateOutputSignalCommand(
    val id: OutputSignalId,
    val equipmentId: EquipmentId,
    val name: OutputSignalName,
    val unitType: UnitType,
    val dataType: DataType,
    val variableName: VariableName
)

data class DeleteOutputSignalCommand(
    val id: OutputSignalId
)
