package ru.nti.dtps.equipmentmanager.inputs.rest

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.util.ValidationError

data class CreateInputSignalRequest(
    val id: String,
    val equipmentId: String,
    val name: String,
    val unitType: UnitType,
    val dataType: DataType,
    val variableName: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, CreateInputSignalCommand> {
        val validId = InputSignalId.validated(id).getOrElse { return it.left() }
        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }
        val name = InputSignalName.validated(name).getOrElse { return it.left() }
        val variableName = VariableName.validated(variableName).getOrElse { return it.left() }
        return CreateInputSignalCommand(validId, validEquipmentId, name, unitType, dataType, variableName).right()
    }
}

data class UpdateInputSignalRequest(
    val id: String,
    val equipmentId: String,
    val name: String,
    val unitType: UnitType,
    val dataType: DataType,
    val variableName: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, UpdateInputSignalCommand> {
        val validId = InputSignalId.validated(id).getOrElse { return it.left() }
        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }
        val name = InputSignalName.validated(name).getOrElse { return it.left() }
        val variableName = VariableName.validated(variableName).getOrElse { return it.left() }
        return UpdateInputSignalCommand(validId, validEquipmentId, name, unitType, dataType, variableName).right()
    }
}

data class DeleteInputSignalRequest(
    val id: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, DeleteInputSignalCommand> {
        EquipmentId.validated(equipmentId).mapLeft { return it.left() }
        val validId = InputSignalId.validated(id).getOrElse { return it.left() }
        return DeleteInputSignalCommand(validId).right()
    }
}