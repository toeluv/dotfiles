package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError

data class EquipmentName(
    val name: String
) {
    companion object {
        fun from(name: String): Either<CreateEquipmentNameError, EquipmentName> =
            if (name.isNotBlank()) {
                EquipmentName(name).right()
            } else {
                CreateEquipmentNameError.EmptyEquipmentName.left()
            }
    }

    fun toStringValue() = name

}

sealed class CreateEquipmentNameError : BusinessError {
    object EmptyEquipmentName : CreateEquipmentNameError()
}