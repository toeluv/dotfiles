package ru.nti.dtps.equipmentmanager.userVariable.rest

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.util.ValidationError

data class CreateUserVariableRequest(
    val id: String,
    val name: String,
    val dataType: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, CreateUserVariableCommand> {
        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }
        val userVariableId = UserVariableId.validated(id).getOrElse { return it.left() }
        val name = VariableName.validated(name).getOrElse { return it.left() }
        return CreateUserVariableCommand(userVariableId, validEquipmentId, name, DataType.valueOf(dataType)).right()
    }
}

data class UpdateUserVariableRequest(
    val id: String,
    val name: String,
    val dataType: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, UpdateUserVariableCommand> {
        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }
        val userVariableId = UserVariableId.validated(id).getOrElse { return it.left() }
        val name = VariableName.validated(name).getOrElse { return it.left() }
        return UpdateUserVariableCommand(userVariableId, validEquipmentId, name, DataType.valueOf(dataType)).right()
    }
}

data class DeleteUserVariableRequest(
    val id: String,
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, DeleteUserVariableCommand> {
        EquipmentId.validated(equipmentId).mapLeft { return it.left() }
        val userVariableId = UserVariableId.validated(id).getOrElse { return it.left() }
        return DeleteUserVariableCommand(userVariableId).right()
    }
}