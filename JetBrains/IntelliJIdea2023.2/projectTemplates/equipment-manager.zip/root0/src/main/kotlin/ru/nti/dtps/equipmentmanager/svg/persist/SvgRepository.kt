package ru.nti.dtps.equipmentmanager.svg.persist

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgExtractor
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgPersister
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgDto
import java.util.*
import javax.sql.DataSource

@Component
class SvgRepository(
    dataSource: DataSource
) : SvgExtractor, SvgPersister {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    override fun getById(id: UUID): SvgDto? {
        return jdbcTemplate.query(
            "SELECT * FROM public.svg WHERE id = :id",
            mapOf("id" to id),
            SvgResultSetExtractor()
        )
    }

    @Transactional
    override fun save(svgDto: SvgDto) {
        val params = mapOf(
            "id" to svgDto.id,
            "svg_scheme" to svgDto.svgScheme,
            "svg_lib" to svgDto.svgLib
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.svg(id, svg_scheme, svg_lib)
            VALUES(
            :id, 
            :svg_scheme, 
            :svg_lib
            )
            """.trimMargin(), params
        )
    }

    @Transactional
    override fun update(svgDto: SvgDto) {
        val params = mapOf(
            "id" to svgDto.id,
            "svg_scheme" to svgDto.svgScheme,
            "svg_lib" to svgDto.svgLib
        )

        val update = jdbcTemplate.update(
            """
            UPDATE public.svg SET
            svg_scheme = :svg_scheme, 
            svg_lib = :svg_lib
            WHERE id = :id
        """.trimIndent(), params
        )
        if (update == 0) {
            save(svgDto)
        }
    }

    override fun delete(id: UUID) {
        jdbcTemplate.update(
            "DELETE from public.svg WHERE id = :id",
            mapOf("id" to id)
        )
    }
}

