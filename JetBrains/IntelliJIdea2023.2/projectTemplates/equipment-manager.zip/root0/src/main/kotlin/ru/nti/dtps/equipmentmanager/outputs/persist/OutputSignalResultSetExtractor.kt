package ru.nti.dtps.equipmentmanager.outputs.persist

import arrow.core.getOrElse
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import java.sql.ResultSet

class OutputSignalResultSetExtractor : ResultSetExtractor<OutputSignal> {
    override fun extractData(rs: ResultSet): OutputSignal? {
        return if (rs.next()) {
            OutputSignalRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class OutputSignalRowMapper : RowMapper<OutputSignal> {

    private val logger = LoggerFactory.getLogger(OutputSignalRowMapper::class.java)

    override fun mapRow(rs: ResultSet, rowNum: Int): OutputSignal? {
        val idString = rs.getString("id")
        val equipmentIdString = rs.getString("equipment_id")
        val nameString = rs.getString("name")
        val unitTypeString = rs.getString("unit_type")
        val dataTypeString = rs.getString("data_type")
        val variableNameString = rs.getString("variable_name")

        return OutputSignal.restore(
            id = OutputSignalId.from(idString).getOrElse {
                logger.error("Incorrect output signal id #[[\$]]#idString")
                return null
            },
            equipmentId = EquipmentId.from(idString).getOrElse {
                logger.error("Incorrect equipment id #[[\$]]#equipmentIdString")
                return null
            },
            name = OutputSignalName.from(nameString).getOrElse {
                logger.error("Incorrect output signal name #[[\$]]#nameString")
                return null
            },
            unitType = UnitType.valueOf(unitTypeString),
            dataType = DataType.valueOf(dataTypeString),
            variableName = VariableName.from(variableNameString).getOrElse {
                logger.error("Incorrect variable name #[[\$]]#variableNameString")
                return null
            }
        )
    }
}
