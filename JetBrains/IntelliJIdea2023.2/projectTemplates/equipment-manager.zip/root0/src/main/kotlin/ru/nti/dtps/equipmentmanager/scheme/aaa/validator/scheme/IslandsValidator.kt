package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.scheme

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment.PrimitiveEquipmentLibId.*
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.graphsearch.BreadthFirstSearch
import java.util.*

@Component
class IslandsValidator : AbstractSchemeValidator(Level.FOURTH) {

    private val requiredPrimitiveEquipmentLibIds = setOf(GROUNDING, PORT_3PH, PORT_1PH)

    override fun validate(scheme: Scheme): Either<SchemeValidationError, Unit> {
        val nodesToStart = LinkedList<PrimitiveEquipment>()
            .apply {
                addAll(scheme.primitiveNodes.values.filter { it.type in requiredPrimitiveEquipmentLibIds })
            }
            .ifEmpty { return SchemeContainsNotValidIslandsErrorScheme.left() }

        val bfs = BreadthFirstSearch(scheme)

        while (nodesToStart.isNotEmpty()) {
            bfs.walkThroughScheme(nodesToStart.poll())
                .let { island ->
                    if (!isIslandValid(island)) {
                        return SchemeContainsNotValidIslandsErrorScheme.left()
                    }
                    nodesToStart.removeAll { it in island }
                }
        }

        if (bfs.allVisitedNodesIds.size != scheme.primitiveNodes.values.size) {
            return SchemeContainsNotValidIslandsErrorScheme.left()
        }

        return Unit.right()
    }

    private fun isIslandValid(island: Set<PrimitiveEquipment>) =
        island.map { it.type }.let { islandTypes ->
            islandTypes.any { it == GROUNDING } && islandTypes.any { it == PORT_1PH || it == PORT_3PH }
        }
}

object SchemeContainsNotValidIslandsErrorScheme : SchemeValidationError