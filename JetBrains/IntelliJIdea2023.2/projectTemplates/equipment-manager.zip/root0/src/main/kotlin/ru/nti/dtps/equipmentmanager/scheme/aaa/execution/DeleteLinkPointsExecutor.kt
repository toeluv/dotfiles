package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.DeleteSchemeLinkEditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.EditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeLink
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeLinkExtractor

@Component
class DeleteLinkPointsExecutor(
    val schemeLinkExtractor: SchemeLinkExtractor
) : CommandExecutor<DeleteLinkUserCommand> {

    private val logger = LoggerFactory.getLogger(DeleteLinkUserCommand::class.java)

    override fun execute(command: DeleteLinkUserCommand): Either<CommandExecutionError, DeleteLinkUserCommandSuccessResult> {
        return schemeLinkExtractor.extract(command.equipmentId, command.nodeId)?.let {
            DeleteLinkUserCommandSuccessResult(it, command).right()
        } ?: LinkNotFoundError(command.nodeId.toString()).left()

    }
}

class DeleteLinkUserCommandSuccessResult(
    val schemeLink: SchemeLink,
    val command: DeleteLinkUserCommand
) : CommandSuccessResult {
    override fun undo() = CreateLinkUserCommand(
        nodeId = command.nodeId,
        equipmentId = command.equipmentId,
        body = CreateLink(
            id = command.nodeId,
            alignmentType = schemeLink.alignmentType,
            points = schemeLink.points,
            sourcePort = schemeLink.sourcePort,
            targetPort = schemeLink.targetPort,
            sourceNode = schemeLink.sourceNode,
            targetNode = schemeLink.targetNode
        )
    )

    override fun editorCommands(): List<EditorCommand> {
        return listOf(
            DeleteSchemeLinkEditorCommand.build(command),
        )
    }
}