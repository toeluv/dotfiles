package ru.nti.dtps.equipmentmanager.scheme.aaa.editor

import ru.nti.dtps.equipmentmanager.common.MutualBranchId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.VariableName

data class MutualBranch(
    val id: MutualBranchId,
    var equipmentId: EquipmentId,
    var variableName: VariableName,
    var isResistive: Boolean,
    var resistance: Double,
    var conductivity: Double,
    var elementType: PrimitiveEquipmentLibId
) {

   /* companion object {
        fun create(
            id: String,
            name: VariableName,
            isResistive: Boolean,
            resistance: Double,
            conductivity: Double,
            elementType: PrimitiveEquipment.PrimitiveEquipmentLibId
        ) = MutualBranch(
            id = id,
            variableName = name,
            isResistive = isResistive,
            resistance = resistance,
            conductivity = conductivity,
            elementType = elementType
        )
    }*/
}