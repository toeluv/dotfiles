package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.NodeOptions
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.FieldType
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.OptionLib
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.TextValidator

@Component
class EqualLengthTextValidator : TextValidator {
    override fun validate(
        optionValueString: String,
        optionLib: OptionLib,
        fieldType: FieldType,
        equipment: PrimitiveEquipment
    ): Either<SchemeValidationError, Unit> {
        return if (fieldType.length != null && fieldType.length != 0 && fieldType.length != optionValueString.length) {
            TextFieldLengthDoNotEqualValueError(
                equipment.id,
                equipment.name,
                optionLib,
                fieldType.length
            ).left()
        } else {
            Unit.right()
        }
    }

    override fun validate(
        optionValueString: String,
        optionLib: OptionLib,
        fieldType: FieldType,
        nodeOptions: NodeOptions
    ): Either<SchemeValidationError, Unit> {
        return if (fieldType.length != null && fieldType.length != 0 && fieldType.length != optionValueString.length) {
            TextFieldLengthDoNotEqualValueError(
                equipment.id,
                equipment.name,
                optionLib,
                fieldType.length
            ).left()
        } else {
            Unit.right()
        }
    }
}

class TextFieldLengthDoNotEqualValueError(
    val equipmentId: String,
    val equipmentName: String,
    val optionLib: OptionLib,
    val boundValue: Int
) : SchemeValidationError