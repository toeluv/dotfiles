package ru.nti.dtps.equipmentmanager.scheme.usecase

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.VariableName

fun interface VariableNameOnSchemeAlreadyExist {
    operator fun invoke(
        variableName: VariableName,
        equipmentId: EquipmentId
    ): Boolean
}