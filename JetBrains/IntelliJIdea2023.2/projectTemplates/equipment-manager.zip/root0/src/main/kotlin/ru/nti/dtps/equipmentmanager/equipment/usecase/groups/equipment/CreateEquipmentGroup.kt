package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.rest.groups.CreateEquipmentGroupCommand

interface CreateEquipmentGroup {
    fun execute(command: CreateEquipmentGroupCommand): Either<CreateEquipmentGroupUseCaseError, EquipmentGroup>
}

sealed class CreateEquipmentGroupUseCaseError : UseCaseError {
    class EquipmentGroupNameAlreadyExistUseCaseError(val name: String) : CreateEquipmentGroupUseCaseError()
}