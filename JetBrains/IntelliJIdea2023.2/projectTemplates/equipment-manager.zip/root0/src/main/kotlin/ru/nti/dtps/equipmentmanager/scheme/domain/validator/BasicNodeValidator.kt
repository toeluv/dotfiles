package ru.nti.dtps.equipmentmanager.scheme.domain.validator

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.OptionValueType
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoExtractor
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.*
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.MutualitySelect
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.NumberValidator
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.TextValidator

@Component
class BasicNodeValidator(
    private val libInfoExtractor: LibInfoExtractor
) : AbstractSchemeValidator(Level.SECOND) {

    override fun validate(scheme: Scheme): Either<SchemeValidationError, Unit> {
        scheme.primitiveNodes.values.forEach { node ->
            validateNode(node, libInfoExtractor)
        }

        return Unit.right()
    }

    companion object {
        private val textValidators: List<TextValidator> = listOf(
            EqualLengthTextValidator(),
            MaxLengthTextValidator(),
            MinLengthTextValidator(),
            RegexTextValidator()
        )
        private val numberValidators: List<NumberValidator> = listOf(
            MaxNumberValidator(),
            MinNumberValidator()
        )
        private val mutualitySelectValidators: List<MutualitySelect> = listOf(
            MutualitySelectValidator()
        )

        fun validateNode(
            node: PrimitiveEquipment,
            libInfoExtractor: LibInfoExtractor
        ): Either<SchemeValidationError, Unit> {

            NameOptionValidator.validate(node).mapLeft { return it.left() }

            libInfoExtractor.getEquipmentLibById(node.type).options.let { optionLibs ->
                UnexpectedOptionsValidator.validate(node, optionLibs)

                optionLibs.forEach { optionLib ->
                    val optionValueString = RequiredOptionExistAndItsValueValidator.validate(node, optionLib)
                        .getOrElse { return it.left() }

                    if (!optionLib.optional) {
                        val fieldType = libInfoExtractor.getFieldTypeLibById(optionLib.typeId)
                        when (fieldType.valueType) {
                            OptionValueType.TEXT -> textValidators.forEach { validator ->
                                validator
                                    .validate(optionValueString!!, optionLib, fieldType, node)
                                    .mapLeft { return it.left() }
                            }

                            OptionValueType.NUMBER -> numberValidators.forEach { validator ->
                                validator
                                    .validate(optionValueString!!, optionLib, fieldType, node)
                                    .mapLeft { return it.left() }
                            }

                            OptionValueType.MUTUALITY_SELECT -> mutualitySelectValidators.forEach { validator ->
                                validator
                                    .validate(optionValueString!!, optionLib, fieldType, node)
                            }
                        }
                    }
                }
            }

            return Unit.right()
        }
    }
}