package ru.nti.dtps.equipmentmanager.svg.persist.dto

import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo
import java.util.UUID

class SignalInfoDto private constructor(
    val id: UUID,
    val signalsFromMeas: List<SignalInfo>,
    val signalsFromScheme: List<SignalInfo>
) {
    companion object {
        fun create(id: UUID) = SignalInfoDto(id, listOf(), listOf())
        fun create(
            id: UUID,
            signalsFromMeas: List<SignalInfo>
        ) = SignalInfoDto(id, signalsFromMeas, listOf())
        fun restore(
            id: UUID,
            signalsFromMeas: List<SignalInfo>,
            signalsFromScheme: List<SignalInfo>
        ) = SignalInfoDto(
            id, signalsFromMeas, signalsFromScheme
        )
    }
}
