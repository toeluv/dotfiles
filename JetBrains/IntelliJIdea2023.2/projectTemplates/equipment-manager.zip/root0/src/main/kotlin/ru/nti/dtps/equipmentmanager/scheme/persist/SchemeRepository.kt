package ru.nti.dtps.equipmentmanager.scheme.persist

import com.fasterxml.jackson.databind.ObjectMapper
import org.postgresql.util.PGobject
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemePersister
import java.util.*
import javax.sql.DataSource

@Component
class SchemeRepository(
    dataSource: DataSource,
    private val objectMapper: ObjectMapper
) : SchemeExtractor, SchemePersister {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    override fun getById(id: UUID): Scheme? {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.scheme
            WHERE id = :id 
            """.trimMargin(),
            mapOf("id" to id),
            SchemeRowMapper()
        ).firstOrNull()
    }

    @Transactional
    override fun save(scheme: Scheme) {
        val params = mapOf(
            "id" to scheme.id.toUUID(),
            "scheme" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(scheme)
            }
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.scheme(id, scheme)
            VALUES(
            :id, 
            :scheme
            )
            """.trimMargin(), params
        )
    }

    @Transactional
    override fun update(scheme: Scheme) {
        val params = mapOf(
            "id" to scheme.id.toUUID(),
            "scheme" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(scheme)
            }
        )

        jdbcTemplate.update(
            """
            UPDATE public.scheme SET
            scheme = :scheme
            WHERE id = :id
        """.trimIndent(), params
        )
    }

    override fun delete(id: UUID) {
        jdbcTemplate.update(
            "DELETE from public.scheme WHERE id = :id",
            mapOf("id" to id)
        )
    }
}