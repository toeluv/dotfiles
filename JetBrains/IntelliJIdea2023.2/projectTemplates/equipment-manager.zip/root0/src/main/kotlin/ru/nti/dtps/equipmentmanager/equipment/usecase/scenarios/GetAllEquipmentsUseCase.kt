package ru.nti.dtps.equipmentmanager.equipment.usecase.scenarios

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.GetAllEquipments
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class GetAllEquipmentsUseCase(
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider,
    private val equipmentExtractor: EquipmentExtractor
) : GetAllEquipments {
    override fun execute(): Collection<Equipment> {
        return equipmentExtractor.getAllByCompanyId(
            currentUserCompanyIdProvider.get()
        )
    }
}