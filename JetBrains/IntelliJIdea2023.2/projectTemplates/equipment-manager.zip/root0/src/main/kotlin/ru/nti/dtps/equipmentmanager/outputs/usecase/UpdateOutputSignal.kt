package ru.nti.dtps.equipmentmanager.outputs.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import ru.nti.dtps.equipmentmanager.outputs.rest.UpdateOutputSignalCommand

interface UpdateOutputSignal {
    fun execute(command: UpdateOutputSignalCommand): Either<UpdateOutputSignalUseCaseError, OutputSignal>
}

sealed class UpdateOutputSignalUseCaseError {
    class VariableNameAlreadyExistsError(val name: String) : UpdateOutputSignalUseCaseError()
    class OutputSignalNameAlreadyExistError(val name: String) : UpdateOutputSignalUseCaseError()
    object OutputSignalNotFoundError : UpdateOutputSignalUseCaseError()
}
