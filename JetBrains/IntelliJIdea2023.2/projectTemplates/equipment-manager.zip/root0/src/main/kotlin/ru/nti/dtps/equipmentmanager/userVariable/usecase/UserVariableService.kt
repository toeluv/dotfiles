package ru.nti.dtps.equipmentmanager.userVariable.usecase

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExists
import ru.nti.dtps.equipmentmanager.userVariable.adapter.UserVariableExtractor
import ru.nti.dtps.equipmentmanager.userVariable.adapter.UserVariablePersister
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable
import ru.nti.dtps.equipmentmanager.userVariable.rest.CreateUserVariableCommand
import ru.nti.dtps.equipmentmanager.userVariable.rest.DeleteUserVariableCommand
import ru.nti.dtps.equipmentmanager.userVariable.rest.UpdateUserVariableCommand

@Component
class UserVariableService(
    private val userVariablePersister: UserVariablePersister,
    private val userVariableExtractor: UserVariableExtractor,
    private val variableNameAlreadyExists: VariableNameAlreadyExists
) : GetAllUserVariables, CreateUserVariable, UpdateUserVariable, DeleteUserVariable {

    override fun execute(equipmentId: EquipmentId) = userVariableExtractor.getAllByEquipmentId(equipmentId).toList()

    override fun execute(command: CreateUserVariableCommand): Either<CreateUserVariableUseCaseError, UserVariable> {
        if (variableNameAlreadyExists(command.name, command.equipmentId)) {
            return CreateUserVariableUseCaseError.VariableNameAlreadyExistsError(command.name.toStringValue()).left()
        }
        return UserVariable.create(
            command.id,
            command.equipmentId,
            command.name,
            command.dataType
        ).also { userVariablePersister.save(it) }.right()
    }

    override fun execute(command: UpdateUserVariableCommand): Either<UpdateUserVariableUseCaseError, UserVariable> {
        if (variableNameAlreadyExists(command.name, command.equipmentId, command.id.toUUID())) {
            return UpdateUserVariableUseCaseError.VariableNameAlreadyExistsError(command.name.toStringValue()).left()
        }
        val variableToUpdate = userVariableExtractor.getById(command.id)
            ?: return UpdateUserVariableUseCaseError.UserVariableNotFoundError.left()
        return variableToUpdate.update(command).also {
            userVariablePersister.update(it)
        }.right()
    }

    override fun execute(command: DeleteUserVariableCommand) =
        userVariableExtractor.getById(command.id)?.let {
            userVariablePersister.delete(it.id)
            Unit.right()
        } ?: DeleteUserVariableUseCaseError.UserVariableNotFoundError.left()
}
