package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.common.MutualBranchId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.MutualBranch

interface MutualBranchExtractor {
    fun extract(id: EquipmentId): List<MutualBranch>
    fun extract(ids: List<MutualBranchId>): List<MutualBranch>
    fun extract(id: MutualBranchId): MutualBranch?
}