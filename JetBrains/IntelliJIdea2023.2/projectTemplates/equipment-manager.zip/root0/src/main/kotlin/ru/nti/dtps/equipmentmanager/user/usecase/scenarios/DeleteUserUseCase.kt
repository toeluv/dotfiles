package ru.nti.dtps.equipmentmanager.user.usecase.scenarios

import arrow.core.Either
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import ru.nti.dtps.equipmentmanager.user.persist.adapter.UserPersister
import ru.nti.dtps.equipmentmanager.user.domain.command.DeleteUserCommand
import ru.nti.dtps.equipmentmanager.user.usecase.DeleteUser

@Service
class DeleteUserUseCase(
    private val userPersister: UserPersister
) : DeleteUser {

    private val logger = LoggerFactory.getLogger(javaClass)

    override fun execute(command: DeleteUserCommand) {
        return Either.catch {
            userPersister.markUserAsDeleted(command.userId)
        }.fold(
            { error -> logger.error("Error delete user cause: {}", error.message, error) },
            { logger.info("User {} was deleted", command.userId.toStringValue()) }
        )
    }
}