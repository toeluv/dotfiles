package ru.nti.dtps.equipmentmanager.scheme.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.domain.MutualBranch
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.scheme.usecase.GetAllBranchesUseCaseError
import ru.nti.dtps.equipmentmanager.scheme.usecase.GetMutualBranches

@Component
class GetMutualBranchesUseCase(
    private val schemeExtractor: SchemeExtractor
) : GetMutualBranches {
    override fun execute(equipmentId: EquipmentId): Either<GetAllBranchesUseCaseError, List<MutualBranch>> {
        return schemeExtractor.getById(equipmentId.toUUID())
            ?.mutualBranches?.right()
            ?: GetAllBranchesUseCaseError.SchemeNotFoundError.left()
    }
}