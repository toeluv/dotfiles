package ru.nti.dtps.equipmentmanager.parameter.domain

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.types.ParameterName
import ru.nti.dtps.equipmentmanager.equipment.domain.validator.InputValidatorHandler
import ru.nti.dtps.equipmentmanager.equipment.domain.validator.InputValueError
import ru.nti.dtps.equipmentmanager.parameter.rest.CreateParameterCommand
import ru.nti.dtps.equipmentmanager.parameter.rest.UpdateParameterCommand

class Parameter(
    val id: ParameterId,
    val equipmentId: EquipmentId,
    var name: ParameterName,
    var groupId: String,
    var unitType: UnitType,
    var dataType: DataType,
    var minValue: String,
    var maxValue: String,
    var defaultValue: String,
    var variableName: VariableName
) {

    fun update(
        command: UpdateParameterCommand,
        inputValidatorHandler: InputValidatorHandler
    ): Either<ParameterError, Parameter> {
        inputValidatorHandler.handle(dataType, minValue, maxValue, defaultValue).mapLeft {
            return when (it) {
                is InputValueError.InvalidInputValueRange -> ParameterError.ParameterHasInvalidValueRangeError.left()
                is InputValueError.InvalidInputValueFormat -> ParameterError.ParameterHasInvalidValueFormatError.left()
            }
        }
        return this.apply {
            this.name = command.name
            this.groupId = command.groupId
            this.unitType = command.unitType
            this.dataType = command.dataType
            this.minValue = command.minValue
            this.maxValue = command.maxValue
            this.defaultValue = command.defaultValue
            this.variableName = command.variableName
        }.right()
    }

    fun buildParameterName(): String {
        return "#[[\$]]#{name.toStringValue()}, #[[\$]]#{this.unitType.toUnit()}"
    }

    companion object {
        fun create(
            command: CreateParameterCommand,
            inputValidatorHandler: InputValidatorHandler
        ): Either<ParameterError, Parameter> {
            inputValidatorHandler.handle(command.dataType, command.minValue, command.maxValue, command.defaultValue)
                .mapLeft {
                    return when (it) {
                        is InputValueError.InvalidInputValueRange
                        -> ParameterError.ParameterHasInvalidValueRangeError.left()

                        is InputValueError.InvalidInputValueFormat
                        -> ParameterError.ParameterHasInvalidValueFormatError.left()
                    }
                }
            return Parameter(
                command.id,
                command.equipmentId,
                command.name,
                command.groupId,
                command.unitType,
                command.dataType,
                command.minValue,
                command.maxValue,
                command.defaultValue,
                command.variableName
            ).right()
        }

        fun restore(
            id: ParameterId,
            equipmentId: EquipmentId,
            name: ParameterName,
            groupId: String,
            unitType: UnitType,
            dataType: DataType,
            minValue: String,
            maxValue: String,
            defaultValue: String,
            variableName: VariableName
        ) = Parameter(
            id,
            equipmentId,
            name,
            groupId,
            unitType,
            dataType,
            minValue,
            maxValue,
            defaultValue,
            variableName
        )
    }
}

sealed class ParameterError {
    object ParameterHasInvalidValueRangeError : ParameterError()
    object ParameterHasInvalidValueFormatError : ParameterError()
}
