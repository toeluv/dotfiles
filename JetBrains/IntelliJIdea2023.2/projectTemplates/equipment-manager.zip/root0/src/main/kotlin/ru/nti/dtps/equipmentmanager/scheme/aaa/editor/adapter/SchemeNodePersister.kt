package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeNode
import java.util.*

interface SchemeNodePersister {
    fun insert(schemeNode: SchemeNode)
    fun update(schemeNode: SchemeNode)
    fun delete(parentId: UUID, id: UUID)

}