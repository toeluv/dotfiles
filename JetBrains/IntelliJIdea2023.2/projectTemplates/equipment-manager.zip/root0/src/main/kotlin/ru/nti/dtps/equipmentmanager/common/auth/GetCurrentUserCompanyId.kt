package ru.nti.dtps.equipmentmanager.common.auth

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.user.persist.adapter.UserExtractor
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider
import ru.nti.dtps.equipmentmanager.user.usecase.access.GetUserIdFromContext

@Component
class GetCurrentUserCompanyId(
    private val userExtractor: UserExtractor,
    private val getUserIdFromContext: GetUserIdFromContext
) : CurrentUserCompanyIdProvider {
    override fun get(): CompanyId {
        val currentUserId = getUserIdFromContext.get()
        return userExtractor.getById(currentUserId)?.companyId
            ?: throw UserNotFoundException("User with id: #[[\$]]#{currentUserId.toStringValue()} does not exist")
    }
}