package ru.nti.dtps.equipmentmanager.common.types

enum class DataType{
    FLOAT,
    BOOLEAN,
    INTEGER
}