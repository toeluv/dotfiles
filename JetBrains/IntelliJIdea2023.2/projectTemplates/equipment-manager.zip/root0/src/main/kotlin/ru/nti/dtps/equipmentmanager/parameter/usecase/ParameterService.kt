package ru.nti.dtps.equipmentmanager.parameter.usecase

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.equipment.domain.validator.InputValidatorHandler
import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExists
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterExtractor
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterNameAlreadyExists
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterPersister
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import ru.nti.dtps.equipmentmanager.parameter.domain.ParameterError
import ru.nti.dtps.equipmentmanager.parameter.rest.CreateParameterCommand
import ru.nti.dtps.equipmentmanager.parameter.rest.DeleteParameterCommand
import ru.nti.dtps.equipmentmanager.parameter.rest.UpdateParameterCommand

@Component
class ParameterService(
    private val parameterExtractor: ParameterExtractor,
    private val parameterPersister: ParameterPersister,
    private val inputValidatorHandler: InputValidatorHandler,
    private val parameterNameAlreadyExists: ParameterNameAlreadyExists,
    private val variableNameAlreadyExists: VariableNameAlreadyExists
) : GetAllParameters, CreateParameter, UpdateParameter, DeleteParameter {

    override fun execute(equipmentId: EquipmentId): List<Parameter> =
        parameterExtractor.getAllByEquipmentId(equipmentId).toList()

    override fun execute(command: CreateParameterCommand): Either<CreateParameterUseCaseError, Parameter> {
        if (parameterNameAlreadyExists(command.equipmentId, command.name)) {
            return CreateParameterUseCaseError.ParameterNameAlreadyExistsError(command.name.toStringValue()).left()
        }
        if (variableNameAlreadyExists(command.variableName, command.equipmentId)) {
            return CreateParameterUseCaseError.VariableNameAlreadyExistsError(command.variableName.toStringValue())
                .left()
        }
        return Parameter.create(command, inputValidatorHandler)
            .fold(
                { it.toCreateUseCaseError().left() },
                { it.also { parameterPersister.save(it) }.right() }
            )
    }

    override fun execute(command: UpdateParameterCommand): Either<UpdateParameterUseCaseError, Parameter> {
        if (parameterNameAlreadyExists(command.equipmentId, command.name, command.id)) {
            return UpdateParameterUseCaseError.ParameterNameAlreadyExistsError(command.name.toStringValue()).left()
        }
        if (variableNameAlreadyExists(command.variableName, command.equipmentId, command.id.toUUID())) {
            return UpdateParameterUseCaseError.VariableNameAlreadyExistsError(command.variableName.toStringValue())
                .left()
        }
        val parameterToUpdate = parameterExtractor.getById(command.id)
            ?: return UpdateParameterUseCaseError.ParameterNotFoundError.left()
        return parameterToUpdate.update(command, inputValidatorHandler)
            .fold(
                { it.toUpdateUseCaseError().left() },
                { it.also { parameterPersister.update(it) }.right() }
            )
    }

    override fun execute(command: DeleteParameterCommand): Either<DeleteParameterUseCaseError, Unit> =
        parameterExtractor.getById(command.id)?.let {
            parameterPersister.delete(it.id)
            Unit.right()
        } ?: DeleteParameterUseCaseError.ParameterNotFoundError.left()
}

private fun ParameterError.toCreateUseCaseError() = when (this) {
    is ParameterError.ParameterHasInvalidValueFormatError -> CreateParameterUseCaseError.ParameterHasInvalidValueFormatError
    is ParameterError.ParameterHasInvalidValueRangeError -> CreateParameterUseCaseError.ParameterHasInvalidValueRangeError
}

private fun ParameterError.toUpdateUseCaseError() = when (this) {
    is ParameterError.ParameterHasInvalidValueFormatError -> UpdateParameterUseCaseError.ParameterHasInvalidValueFormatError
    is ParameterError.ParameterHasInvalidValueRangeError -> UpdateParameterUseCaseError.ParameterHasInvalidValueRangeError
}
