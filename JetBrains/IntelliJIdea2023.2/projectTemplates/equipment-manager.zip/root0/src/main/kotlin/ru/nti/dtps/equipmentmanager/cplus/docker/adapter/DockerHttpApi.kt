package ru.nti.dtps.equipmentmanager.cplus.docker.adapter

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import com.github.dockerjava.api.DockerClient
import com.github.dockerjava.api.async.ResultCallback.Adapter
import com.github.dockerjava.api.model.Bind
import com.github.dockerjava.api.model.ExposedPort
import com.github.dockerjava.api.model.Frame
import com.github.dockerjava.api.model.InternetProtocol
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.cplus.docker.access.DockerVolumePathProvider
import ru.nti.dtps.equipmentmanager.cplus.docker.domain.*

@Component
class DockerHttpApi(
    private val dockerClient: DockerClient,
    private val dockerVolumePathProvider: DockerVolumePathProvider
) : DockerApi {

    private val logger = LoggerFactory.getLogger(DockerHttpApi::class.java)

    override fun createContainer(
        equipmentId: EquipmentId,
        image: Image
    ): Either<DockerAdapterExecuteCommandError, ContainerId> {
        val volumeFolder = dockerVolumePathProvider.getFolderToMount(equipmentId)
        return Either.catch {
            dockerClient.createContainerCmd(image.getImageTag())
                .withCmd(
                    listOf(
                        "sh",
                        "-c",
                        "mkdir build && cd build && cmake .. && make"
                    )
                )
                .withUser("root")
                .withNetworkMode("bridge")
                .withExposedPorts(ExposedPort(8888, InternetProtocol.TCP))
                .withName("build_cpp_by_equipment_#[[\$]]#{equipmentId.toStringValue()}")
                .withWorkingDir("/usr/src/equipment")
                .withBinds(Bind.parse("#[[\$]]#{volumeFolder}:/usr/src/equipment"))
                .withAttachStdout(true)
                .withAttachStderr(true)
                .exec()
                .apply {
                    logger.debug(
                        "Container created by equipment id: {}, container info: {}",
                        equipmentId.toStringValue(),
                        this
                    )
                }
        }.fold(
            { error ->
                logger.error("Error while creation container {}", error.message, error)
                DockerAdapterExecuteCommandError.left()
            },
            { ContainerId(it.id).right() }
        )
    }

    override fun startContainer(containerId: ContainerId): Either<DockerAdapterExecuteCommandError, Unit> {
        return Either.catch {
            dockerClient.startContainerCmd(containerId.id)
                .exec()
        }.fold(
            {
                logger.error("Error while start container {}, cause {}", containerId.id, it.message, it)
                DockerAdapterExecuteCommandError.left()
            },
            {
                logger.debug("Docker container {} successfully started", containerId.id)
                Unit.right()
            }
        )
    }

    override fun restartContainer(containerId: ContainerId): Either<DockerAdapterExecuteCommandError, Unit> {
        return Either.catch {
            dockerClient.restartContainerCmd(containerId.id).exec()
        }.fold(
            {
                logger.error("Error while restart container {}, cause {}", containerId.id, it.message, it)
                DockerAdapterExecuteCommandError.left()
            },
            {
                logger.debug("Docker container {} successfully restarted", containerId.id)
                Unit.right()
            }
        )
    }

    override fun stopContainer(containerId: ContainerId): Either<DockerAdapterExecuteCommandError, Unit> {
        return Either.catch {
            dockerClient.stopContainerCmd(containerId.id).exec()
        }.fold(
            {
                logger.error("Error while stop container {}, cause {}", containerId.id, it.message, it)
                DockerAdapterExecuteCommandError.left()
            },
            {
                logger.debug("Docker container {} successfully stopped", containerId.id)
                Unit.right()
            }
        )
    }

    override fun removeContainer(containerId: ContainerId) {
        dockerClient.removeContainerCmd(containerId.id).exec()
    }

    override fun getContainerLogs(containerId: ContainerId): Either<DockerAdapterExecuteCommandError, ContainerLog> {
        return Either.catch {
            val containerLogsBuilder = StringBuilder()
            val logsResultCallback = object : Adapter<Frame>() {
                override fun onNext(item: Frame) {
                    containerLogsBuilder.append(item.toString() + System.lineSeparator())
                }
            }
            dockerClient.logContainerCmd(containerId.id)
                .withStdOut(true)
                .withFollowStream(true)
                .withStdErr(true)
                .exec(logsResultCallback)
            logsResultCallback.awaitCompletion()
            ContainerLog(containerLogsBuilder.toString())
        }
            .fold(
                {
                    logger.error(
                        "Error while reading logs of container {}, cause {}",
                        containerId.id,
                        it.message,
                        it
                    )
                    DockerAdapterExecuteCommandError.left()
                },
                {
                    logger.debug(
                        "Logs from container {} was successfully read",
                        containerId.id,
                    )
                    it.right()
                }
            )
    }

    override fun getContainerInfo(containerId: ContainerId): ContainerInfo? {
        return dockerClient.listContainersCmd()
            .withShowAll(true)
            .withIdFilter(mutableListOf(containerId.id))
            .exec()
            .firstOrNull()
            ?.let { containerInfoResponse ->
                val state = ContainerState.from(containerInfoResponse.state)
                val image = containerInfoResponse.image.parseImage()
                ContainerInfo(
                    image, containerId, state
                )
            }
    }

    override fun createVolumeIfNotExist(equipmentId: EquipmentId): Either<DockerAdapterExecuteCommandError, Unit> {
        return Either.catch {
            val creationVolumeResponse =
                dockerClient.createVolumeCmd().withName(equipmentId.getVolumeName()).exec()
            logger.debug("Docker volume was created by equipment {}", equipmentId.toStringValue())
            logger.trace("Docker volume was created with response {}", creationVolumeResponse)
        }.fold(
            { error ->
                logger.error("Unable to create docker volume cause {}", error.message, error)
                DockerAdapterExecuteCommandError.left()
            },
            { _ -> Unit.right() }
        )
    }

    override fun removeVolume(equipmentId: EquipmentId) {
        Either.catch {
            dockerClient.removeVolumeCmd(equipmentId.getVolumeName())
        }.fold(
            { error ->
                logger.error(
                    "Unable to remove docker container by equipment {} cause: {}",
                    equipmentId.toStringValue(),
                    error.message,
                    error
                )
            },
            { logger.debug("Docker volume was removed by equipment {}", equipmentId.toStringValue()) })
    }

    override fun getCppCompilerImageId(imageTag: String): List<String> {
        val cppCompilerImage = dockerClient.listImagesCmd()
            .withReferenceFilter(imageTag)
            .exec()
        logger.trace(
            "Result of C++ compiler image request by tag {}: {}",
            imageTag,
            cppCompilerImage
        )
        return cppCompilerImage.map { it.id }
    }
}

fun String.parseImage() = this.split(":").let { Image(it[0], it[1]) }

fun EquipmentId.getVolumeName() = "equipment_#[[\$]]#{this.toStringValue()}"