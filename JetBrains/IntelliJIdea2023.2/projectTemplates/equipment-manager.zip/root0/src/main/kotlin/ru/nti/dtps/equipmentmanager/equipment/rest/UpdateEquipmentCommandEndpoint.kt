package ru.nti.dtps.equipmentmanager.equipment.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.equipment.rest.request.UpdateEquipmentRequest
import ru.nti.dtps.equipmentmanager.equipment.usecase.UpdateEquipment
import ru.nti.dtps.equipmentmanager.equipment.usecase.UpdateEquipmentUseCaseError

@RestController
class UpdateEquipmentCommandEndpoint(
    private val updateEquipment: UpdateEquipment,
    private val messageSource: MessageSourceService
) {

    @Operation(summary = "Update equipment")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Equipment updated", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = Unit::class)
                    ))]
            ),
            ApiResponse(responseCode = "400", description = "Unsupported request fields",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "409", description = "Equipment with current name is already exist",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "404", description = "Equipment not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(responseCode = "500", description = "Something went wrong, go to admin", content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                ))]
            )]
    )
    @PutMapping(API_V1_EQUIPMENT, consumes = ["multipart/form-data", "application/json"])
    fun update(
        @RequestBody updateEquipmentRequest: UpdateEquipmentRequest
    ): ResponseEntity<*> {
        return updateEquipmentRequest.buildCommand()
            .fold(
                { it.toRestError() },
                {
                    updateEquipment.execute(it)
                        .fold(
                            { useCaseError -> useCaseError.toRestError() },
                            { success -> ok(success.toShortView()) }
                        )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun UpdateEquipmentUseCaseError.toRestError() =
        when (this) {
            is UpdateEquipmentUseCaseError.EquipmentNameAlreadyExistUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.equipment.error.validation.twins")
                        .format(name),
                    HttpStatus.CONFLICT
                )

            is UpdateEquipmentUseCaseError.EquipmentNotExistError ->
                restBusinessError(
                    messageSource.getMessage("api.equipment.error.not-found"),
                    HttpStatus.NOT_FOUND
                )
        }
}