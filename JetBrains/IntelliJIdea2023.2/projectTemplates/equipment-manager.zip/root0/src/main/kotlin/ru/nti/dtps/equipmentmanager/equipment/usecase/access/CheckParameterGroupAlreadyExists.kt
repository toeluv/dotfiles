package ru.nti.dtps.equipmentmanager.equipment.usecase.access

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.ParameterGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.ParameterGroupAlreadyExists
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class CheckParameterGroupAlreadyExists(
    private val parameterGroupExtractor: ParameterGroupExtractor,
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider
) : ParameterGroupAlreadyExists {
    override fun invoke(parameterGroupName: String): Boolean {
        return parameterGroupExtractor.checkParameterGroupAlreadyExists(parameterGroupName, currentUserCompanyIdProvider.get())
    }
}
