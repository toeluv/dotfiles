package ru.nti.dtps.equipmentmanager.userVariable.persist

import arrow.core.getOrElse
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.common.types.DataType
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserVariableId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable
import java.sql.ResultSet

class UserVariableResultSetExtractor : ResultSetExtractor<UserVariable> {
    override fun extractData(rs: ResultSet): UserVariable? {
        return if (rs.next()) {
            UserVariableRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class UserVariableRowMapper : RowMapper<UserVariable> {

    private val logger = LoggerFactory.getLogger(UserVariableRowMapper::class.java)

    override fun mapRow(rs: ResultSet, rowNum: Int): UserVariable? {
        val idString = rs.getString("id")
        val equipmentIdString = rs.getString("equipment_id")
        val variableNameString = rs.getString("variable_name")
        val dataTypeString = rs.getString("data_type")
        return UserVariable.restore(
            id = UserVariableId.from(idString).getOrElse {
                logger.error("Incorrect user variable id #[[\$]]#idString")
                return null
            },
            equipmentId = EquipmentId.from(idString).getOrElse {
                logger.error("Incorrect equipment id #[[\$]]#equipmentIdString")
                return null
            },
            variableName = VariableName.from(variableNameString).getOrElse {
                logger.error("Incorrect variable name #[[\$]]#variableNameString")
                return null
            },
            dataType = DataType.valueOf(dataTypeString)
        )
    }
}
