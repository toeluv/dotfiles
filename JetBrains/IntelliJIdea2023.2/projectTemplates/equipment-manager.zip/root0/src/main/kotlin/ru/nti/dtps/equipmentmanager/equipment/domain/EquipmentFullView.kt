package ru.nti.dtps.equipmentmanager.equipment.domain

import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentName
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable
import java.time.Instant

class EquipmentFullView private constructor(
    val id: EquipmentId,
    val companyId: CompanyId,
    val name: EquipmentName,
    val groupId: String?,
    val description: String?,
    val author: String,
    val createdAt: Instant,
    var publicationInfo: PublicationInfo?,
    var published: Boolean,
    var version: Long,
    var editor: String?,
    var updatedAt: Instant?,
    val parameters: Set<Parameter>,
    val inputSignals: Set<InputSignal>,
    val outputSignals: Set<OutputSignal>,
    val userVariables: Set<UserVariable>
) {
        companion object {
        fun restore(
            id: EquipmentId, companyId: CompanyId, name: EquipmentName, groupId: String?,
            description: String?, author: String, createdAt: Instant, parameters: Set<Parameter>,
            inputSignals: Set<InputSignal>, outputSignals: Set<OutputSignal>, userVariables: Set<UserVariable>,
            published: Boolean, publicationInfo: PublicationInfo?, version: Long, editor: String?, updatedAt: Instant?
        ) = EquipmentFullView(
            id, companyId, name, groupId, description, author, createdAt, publicationInfo,
            published, version, editor, updatedAt, parameters, inputSignals, outputSignals, userVariables)
    }
}
