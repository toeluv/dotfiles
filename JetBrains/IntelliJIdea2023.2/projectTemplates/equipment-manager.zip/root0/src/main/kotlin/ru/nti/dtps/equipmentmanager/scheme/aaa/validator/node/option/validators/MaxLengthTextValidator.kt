package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.validators

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionFieldsValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId

class MaxLengthTextValidator(
    val field: OptionLibId,
    private val maxLength: Int
) : OptionFieldsValidator {

//    override fun field() = field
    override fun order() = 1000

    override fun validate(options: Map<OptionLibId, String?>): Either<OptionValidationError, Unit> {
        return options[field]?.let {
            if (it.length > maxLength) {
                TextFieldLengthMoreThenMaxValueError(
                    field, maxLength
                ).left()
            }
            Unit.right()
        } ?: Unit.right()
    }

}

class TextFieldLengthMoreThenMaxValueError(
    val optionLib: OptionLibId,
    val boundValue: Int
) : OptionValidationError
