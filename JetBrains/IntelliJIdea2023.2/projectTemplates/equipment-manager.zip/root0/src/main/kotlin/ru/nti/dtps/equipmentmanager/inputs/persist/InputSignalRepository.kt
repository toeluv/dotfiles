package ru.nti.dtps.equipmentmanager.inputs.persist

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Isolation
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.InputSignalId
import ru.nti.dtps.equipmentmanager.common.types.InputSignalName
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalExtractor
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalNameAlreadyExists
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalPersister
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import javax.sql.DataSource

@Component
class InputSignalRepository(
    dataSource: DataSource
) : InputSignalPersister, InputSignalExtractor, InputSignalNameAlreadyExists {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    @Transactional
    override fun save(inputSignal: InputSignal) {
        val params = mapOf(
            "id" to inputSignal.id.toUUID(),
            "equipment_id" to inputSignal.equipmentId.toUUID(),
            "name" to inputSignal.name.toStringValue(),
            "unit_type" to inputSignal.unitType.name,
            "data_type" to inputSignal.dataType.name,
            "variable_name" to inputSignal.variableName.toStringValue()
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.input_signal(id, equipment_id, name, unit_type, data_type, variable_name)
            VALUES(
            :id, 
            :equipment_id, 
            :name,
            :unit_type,
            :data_type,
            :variable_name
            )
            """.trimMargin(), params
        )
    }

    @Transactional
    override fun update(inputSignal: InputSignal) {
        val params = mapOf(
            "id" to inputSignal.id.toUUID(),
            "equipment_id" to inputSignal.equipmentId.toUUID(),
            "name" to inputSignal.name.toStringValue(),
            "unit_type" to inputSignal.unitType.name,
            "data_type" to inputSignal.dataType.name,
            "variable_name" to inputSignal.variableName.toStringValue()
        )

        jdbcTemplate.update(
            """
            UPDATE public.input_signal SET
            name = :name, 
            unit_type = :unit_type,
            data_type = :data_type,
            variable_name = :variable_name
            WHERE id = :id
            """.trimIndent(), params
        )
    }

    override fun delete(id: InputSignalId) {
        jdbcTemplate.update(
            "DELETE from public.input_signal WHERE id = :id",
            mapOf("id" to id.toUUID())
        )
    }

    override fun deleteAllByEquipmentId(equipmentId: EquipmentId) {
        jdbcTemplate.update(
            "DELETE from public.input_signal WHERE equipment_id = :equipment_id",
            mapOf("equipment_id" to equipmentId.toUUID())
        )
    }

    override fun getById(id: InputSignalId): InputSignal? {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.input_signal
            WHERE id = :id
            """.trimMargin(),
            mapOf("id" to id.toUUID()),
            InputSignalResultSetExtractor()
        )
    }

    override fun getAllByEquipmentId(equipmentId: EquipmentId): Collection<InputSignal> {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.input_signal
            WHERE equipment_id = :equipment_id 
            """.trimMargin(),
            mapOf("equipment_id" to equipmentId.toUUID()),
            InputSignalRowMapper()
        ).toSet()
    }

    @Transactional(isolation = Isolation.SERIALIZABLE)
    override operator fun invoke(name: InputSignalName, equipmentId: EquipmentId): Boolean {
        val params = mapOf(
            "name" to name.toStringValue(),
            "equipment_id" to equipmentId.toUUID()
        )
        val result = jdbcTemplate.query(
            "SELECT * FROM public.input_signal WHERE name = :name AND equipment_id = :equipment_id",
            params,
            InputSignalRowMapper()
        )
        return result.isNotEmpty()
    }

    @Transactional(isolation = Isolation.SERIALIZABLE)
    override operator fun invoke(id: InputSignalId, name: InputSignalName, equipmentId: EquipmentId): Boolean {
        val params = mapOf(
            "id" to id.toUUID(),
            "name" to name.toStringValue(),
            "equipment_id" to equipmentId.toUUID()
        )
        val result = jdbcTemplate.query(
            "SELECT * FROM public.input_signal WHERE name = :name AND equipment_id = :equipment_id AND id <> :id",
            params,
            InputSignalRowMapper()
        )
        return result.isNotEmpty()
    }
}
