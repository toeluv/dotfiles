package ru.nti.dtps.equipmentmanager.scheme.aaa.command

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId
import ru.nti.dtps.proto.scheme.link.EquipmentLink
import java.util.*


class BatchCommand(
    val changeId: UUID,
    val userId: UserId,
    val userCommands: List<UserCommand>,
)

abstract class UserCommand(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
)

class CreateNodeUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: CreateNode
) : UserCommand(nodeId, equipmentId)

class ChangeNodeCoordsUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: ChangeNodeCoords
) : UserCommand(nodeId, equipmentId)

class ChangeNodeDimensionsUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: ChangeNodeDimensions
) : UserCommand(nodeId, equipmentId)

class ChangeNodeRotationUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: ChangeNodeRotation
) : UserCommand(nodeId, equipmentId)

class ChangeNodeOptionsUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: ChangeNodeParams
) : UserCommand(nodeId, equipmentId)

class ChangeNodePortsUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: ChangeNodePorts
) : UserCommand(nodeId, equipmentId)


class CreateLinkUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: CreateLink
) : UserCommand(nodeId, equipmentId)

class ChangeLinkPointsUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: ChangeLinkPoints
) : UserCommand(nodeId, equipmentId)

class DeleteLinkUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: DeleteLink
) : UserCommand(nodeId, equipmentId)


data class CreateNode(
    val id: UUID,
    val type: PrimitiveEquipmentLibId,
    val hour: Int = 0,
    val coords: XyCoords,
    val dimensions: Dimensions,
    val ports: List<Port> = listOf(),
    val options: Map<OptionLibId, String?> = mapOf(),
    val payload: Map<String, String> = mapOf()
)

class DeleteNodeUserCommand(
    nodeId: UUID,
    equipmentId: EquipmentId,
    val body: DeleteNode
) : UserCommand(nodeId, equipmentId)

data class ChangeNodeCoords(
    val id: UUID,
    val coords: XyCoords,
    val ports: List<Port>
)

data class ChangeNodeDimensions(
    val id: UUID,
    val ports: List<Port>,
    val coords: XyCoords,
    val dimensions: Dimensions
)

data class DeleteNode(
    val id: UUID
)

data class ChangeNodeRotation(
    val id: UUID,
    val coords: XyCoords,
    val hour: Int
)

data class ChangeNodeParams(
    val id: UUID,
    val options: Map<OptionLibId, String?> = mapOf(),
    val payload: Map<String, String> = mapOf()
)

data class ChangeNodePorts(
    val id: UUID,
    val ports: List<Port>
)

data class CreateLink(
    val id: UUID,
    val alignmentType: EquipmentLink.AlignmentType = EquipmentLink.AlignmentType.RECTANGULAR,
    val sourceNode: UUID,
    val targetNode: UUID,
    val sourcePort: UUID,
    val targetPort: UUID,
    val points: List<Point>
)

data class ChangeLinkPoints(
    val id: UUID,
    val points: List<Point>
)

data class DeleteLink(
    val id: UUID
)