package ru.nti.dtps.equipmentmanager.scheme.aaa.editor

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import java.util.*

data class EquipmentScheme(
    val id: EquipmentId,
    val nodes: Map<UUID, SchemeNode>,
    val links: Map<UUID, SchemeLink>,
    var isValid: Boolean = false
)
