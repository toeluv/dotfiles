package ru.nti.dtps.equipmentmanager.outputs.persist

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Isolation
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.OutputSignalId
import ru.nti.dtps.equipmentmanager.common.types.OutputSignalName
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalExtractor
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalNameAlreadyExists
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalPersister
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import javax.sql.DataSource

@Component
class OutputSignalRepository(
    dataSource: DataSource
) : OutputSignalExtractor, OutputSignalPersister, OutputSignalNameAlreadyExists {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    @Transactional
    override fun save(outputSignal: OutputSignal) {
        val params = mapOf(
            "id" to outputSignal.id.toUUID(),
            "equipment_id" to outputSignal.equipmentId.toUUID(),
            "name" to outputSignal.name.toStringValue(),
            "unit_type" to outputSignal.unitType.name,
            "data_type" to outputSignal.dataType.name,
            "variable_name" to outputSignal.variableName.toStringValue()
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.output_signal(id, equipment_id, name, unit_type, data_type, variable_name)
            VALUES(
            :id, 
            :equipment_id, 
            :name,
            :unit_type,
            :data_type,
            :variable_name
            )
            """.trimMargin(), params
        )
    }

    @Transactional
    override fun update(outputSignal: OutputSignal) {
        val params = mapOf(
            "id" to outputSignal.id.toUUID(),
            "equipment_id" to outputSignal.equipmentId.toUUID(),
            "name" to outputSignal.name.toStringValue(),
            "unit_type" to outputSignal.unitType.name,
            "data_type" to outputSignal.dataType.name,
            "variable_name" to outputSignal.variableName.toStringValue()
        )

        jdbcTemplate.update(
            """
            UPDATE public.output_signal SET
            name = :name, 
            unit_type = :unit_type,
            data_type = :data_type,
            variable_name = :variable_name
            WHERE id = :id
            """.trimIndent(), params
        )
    }

    override fun delete(id: OutputSignalId) {
        jdbcTemplate.update(
            "DELETE from public.output_signal WHERE id = :id",
            mapOf("id" to id.toUUID())
        )
    }

    override fun deleteAllByEquipmentId(equipmentId: EquipmentId) {
        jdbcTemplate.update(
            "DELETE from public.output_signal WHERE equipment_id = :equipment_id",
            mapOf("equipment_id" to equipmentId.toUUID())
        )
    }

    override fun getById(id: OutputSignalId): OutputSignal? {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.output_signal
            WHERE id = :id
            """.trimMargin(),
            mapOf("id" to id.toUUID()),
            OutputSignalResultSetExtractor()
        )
    }

    override fun getAllByEquipmentId(equipmentId: EquipmentId): Collection<OutputSignal> {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.output_signal
            WHERE equipment_id = :equipment_id 
            """.trimMargin(),
            mapOf("equipment_id" to equipmentId.toUUID()),
            OutputSignalRowMapper()
        ).toSet()
    }

    @Transactional(isolation = Isolation.SERIALIZABLE)
    override operator fun invoke(name: OutputSignalName, equipmentId: EquipmentId): Boolean {
        val params = mapOf(
            "name" to name.toStringValue(),
            "equipment_id" to equipmentId.toUUID()
        )
        val result = jdbcTemplate.query(
            "SELECT * FROM public.output_signal WHERE name = :name AND equipment_id = :equipment_id",
            params,
            OutputSignalRowMapper()
        )
        return result.isNotEmpty()
    }

    @Transactional(isolation = Isolation.SERIALIZABLE)
    override operator fun invoke(id: OutputSignalId, name: OutputSignalName, equipmentId: EquipmentId): Boolean {
        val params = mapOf(
            "id" to id.toUUID(),
            "name" to name.toStringValue(),
            "equipment_id" to equipmentId.toUUID()
        )
        val result = jdbcTemplate.query(
            "SELECT * FROM public.output_signal WHERE name = :name AND equipment_id = :equipment_id AND id <> :id",
            params,
            OutputSignalRowMapper()
        )
        return result.isNotEmpty()
    }
}
