package ru.nti.dtps.equipmentmanager.parameter.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.parameter.rest.DeleteParameterCommand

interface DeleteParameter {
    fun execute(command: DeleteParameterCommand): Either<DeleteParameterUseCaseError, Unit>
}

sealed class DeleteParameterUseCaseError {
    object ParameterNotFoundError : DeleteParameterUseCaseError()
}
