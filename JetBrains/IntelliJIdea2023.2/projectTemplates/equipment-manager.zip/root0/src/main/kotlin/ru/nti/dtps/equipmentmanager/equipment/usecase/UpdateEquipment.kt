package ru.nti.dtps.equipmentmanager.equipment.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.domain.command.UpdateEquipmentCommand

interface UpdateEquipment {
    fun execute(command: UpdateEquipmentCommand): Either<UpdateEquipmentUseCaseError, Equipment>
}

sealed class UpdateEquipmentUseCaseError : UseCaseError {
    class EquipmentNameAlreadyExistUseCaseError(val name: String) : UpdateEquipmentUseCaseError()
    object EquipmentNotExistError : UpdateEquipmentUseCaseError()
}