package ru.nti.dtps.equipmentmanager.userVariable.domain

import ru.nti.dtps.equipmentmanager.common.types.DataType
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserVariableId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.userVariable.rest.UpdateUserVariableCommand

data class UserVariable(
    val id: UserVariableId,
    val equipmentId: EquipmentId,
    var variableName: VariableName,
    var dataType: DataType
) {

    fun update(command: UpdateUserVariableCommand) = this.apply {
        this.variableName = command.name
        this.dataType = command.dataType
    }
    companion object {
        fun create(
            id: UserVariableId,
            equipmentId: EquipmentId,
            variableName: VariableName, dataType: DataType
        ) = UserVariable(id, equipmentId, variableName, dataType)

        fun restore(
            id: UserVariableId,
            equipmentId: EquipmentId,
            variableName: VariableName, dataType: DataType
        ) = UserVariable(id, equipmentId, variableName, dataType)
    }
}