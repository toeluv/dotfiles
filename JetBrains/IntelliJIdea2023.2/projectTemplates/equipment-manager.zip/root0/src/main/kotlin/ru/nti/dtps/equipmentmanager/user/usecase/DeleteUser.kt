package ru.nti.dtps.equipmentmanager.user.usecase

import ru.nti.dtps.equipmentmanager.user.domain.command.DeleteUserCommand

interface DeleteUser {
    fun execute(command: DeleteUserCommand)
}