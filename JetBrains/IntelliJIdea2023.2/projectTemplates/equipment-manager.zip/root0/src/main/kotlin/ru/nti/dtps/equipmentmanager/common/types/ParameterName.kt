package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError

data class ParameterName(
    val name: String
) {
    companion object {
        fun from(name: String): Either<CreateParameterNameError, ParameterName> =
            if (name.isNotBlank()) {
                ParameterName(name).right()
            } else {
                CreateParameterNameError.EmptyParameterName.left()
            }
    }

    fun toStringValue() = name

}

sealed class CreateParameterNameError : BusinessError {
    object EmptyParameterName : CreateParameterNameError()
}