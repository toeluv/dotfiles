package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError
import java.util.*

data class ParameterId(
    val id: UUID
) {
    companion object {
        fun from(id: String): Either<InvalidParameterIdError, ParameterId> {
            return Either.catch { UUID.fromString(id) }
                .fold(
                    { InvalidParameterIdError.left() },
                    { ParameterId(it).right() }
                )
        }

        fun from(id: UUID): ParameterId = ParameterId(id)
    }

    fun toStringValue() = id.toString()

    fun toUUID() = id
}

object InvalidParameterIdError : BusinessError
