package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId

interface OptionFieldsValidator{
    fun order(): Int
    fun validate(options: Map<OptionLibId, String?>): Either<OptionValidationError, Unit>
}

interface OptionValidationError