package ru.nti.dtps.equipmentmanager.equipment.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.kafka.core.KafkaTemplate
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.domain.command.DeleteEquipmentCommand
import ru.nti.dtps.equipmentmanager.equipment.kafka.EquipmentEventMessage
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentPersister
import ru.nti.dtps.equipmentmanager.equipment.usecase.DeleteEquipment
import ru.nti.dtps.equipmentmanager.equipment.usecase.DeleteEquipmentUseCaseError
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalPersister
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalPersister
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterPersister
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemePersister
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SignalInfoPersister
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgInfoPersister
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgPersister
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider
import ru.nti.dtps.equipmentmanager.userVariable.adapter.UserVariablePersister

@Component
class DeleteEquipmentUseCase(
    private val equipmentExtractor: EquipmentExtractor,
    private val equipmentPersister: EquipmentPersister,
    private val schemePersister: SchemePersister,
    private val svgInfoPersister: SvgInfoPersister,
    private val svgPersister: SvgPersister,
    private val signalInfoPersister: SignalInfoPersister,
    private val inputSignalPersister: InputSignalPersister,
    private val outputSignalPersister: OutputSignalPersister,
    private val userVariablePersister: UserVariablePersister,
    private val equipmentParameterPersister: ParameterPersister,
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider,
    private val kafkaTemplate: KafkaTemplate<String, EquipmentEventMessage>
) : DeleteEquipment {
    override fun execute(command: DeleteEquipmentCommand): Either<DeleteEquipmentUseCaseError, Equipment> {
        return equipmentExtractor.getByIdAndCompanyId(command.id, currentUserCompanyIdProvider.get())
            ?.let { equipmentToDelete ->
                equipmentPersister.delete(equipmentToDelete.id.toUUID())
                inputSignalPersister.deleteAllByEquipmentId(command.id)
                outputSignalPersister.deleteAllByEquipmentId(command.id)
                userVariablePersister.deleteAllByEquipmentId(command.id)
                equipmentParameterPersister.deleteAllByEquipmentId(command.id)
                schemePersister.delete(equipmentToDelete.id.toUUID())
                svgInfoPersister.delete(equipmentToDelete.id.toUUID())
                svgPersister.delete(equipmentToDelete.id.toUUID())
                signalInfoPersister.delete(equipmentToDelete.id.toUUID())

                val sendDefault = kafkaTemplate.sendDefault(
                    equipmentToDelete.id.toStringValue(),
                    EquipmentEventMessage.buildDeleteMessage(
                        equipmentToDelete.id.toStringValue(),
                        equipmentToDelete.companyId.toStringValue(),
                        equipmentToDelete.version
                    )
                )
                sendDefault.get()
                equipmentToDelete.right()
            } ?: DeleteEquipmentUseCaseError.EquipmentNotFoundUseCaseError.left()
    }
}