package ru.nti.dtps.equipmentmanager.scheme.aaa.jdbc

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.NodeOptions
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.NodeOptionsExtractor
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.NodeOptionsPersiter
import ru.nti.dtps.equipmentmanager.scheme.aaa.invariant.NodeNameAlreadyExists
import ru.nti.dtps.equipmentmanager.scheme.domain.OptionLibId
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import java.sql.ResultSet
import java.util.*

@Component
class NodeOptionsRepositoryValidator(
    private val jdbcTemplate: NamedParameterJdbcTemplate,
) : NodeOptionsExtractor, NodeOptionsPersiter, NodeNameAlreadyExists {

    private val jackObjectMapper: ObjectMapper = jacksonObjectMapper()

    override fun extract(parentId: EquipmentId, nodeId: UUID): NodeOptions? {
        val params = mapOf(
            "id" to nodeId,
            "parent_id" to parentId.toUUID()
        )
        val result = jdbcTemplate.query(
            "SELECT * FROM public.node_options WHERE id = :id AND parent_id = :parent_id",
            params,
            NodeOptionsResultSetExtractor()
        )
        return result
    }

    override fun insert(nodeOptions: NodeOptions) {
        val params = mapOf(
            "node_id" to nodeOptions.id,
            "parent_id" to nodeOptions.parentId,
            "node_type" to nodeOptions.nodeType.toString(),
            "options" to jackObjectMapper.writeValueAsString(nodeOptions.options)
        )
        jdbcTemplate.update(
            """
        INSERT INTO public.node_options(node_id, parent_id, node_type, params)
        VALUES(
            :node_id, 
            :parent_id,
            :node_type,
            :params
        )
        """.trimIndent(), params
        )
    }

    override fun update(nodeOptions: NodeOptions) {
        val params = mapOf(
            "node_id" to nodeOptions.id,
            "parent_id" to nodeOptions.parentId,
            "params" to jackObjectMapper.writeValueAsString(nodeOptions.options)
        )
        jdbcTemplate.update(
            """
            UPDATE public.node_options SET
            params = :params,
            WHERE node_id = :node_id AND parent_id = :parent_id
        """.trimIndent(), params
        )
    }

    override fun delete(parentId: UUID, id: UUID) {
        val params = mapOf(
            "node_id" to id,
            "parent_id" to parentId,
        )
        jdbcTemplate.update(
            "DELETE from public.node_options where node_id = :node_id AND parent_id = :parent_id",
            params
        )
    }

    override operator fun invoke(nodeId: UUID, equipmentId: EquipmentId, nodeName: String): Boolean{
        TODO("Not yet implemented")
        return false
    }
}

class NodeOptionsResultSetExtractor : ResultSetExtractor<NodeOptions> {
    override fun extractData(rs: ResultSet): NodeOptions? {
        return if (rs.next()) {
            NodeOptionsRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class NodeOptionsRowMapper : RowMapper<NodeOptions> {
    private val objectMapper = jacksonObjectMapper()

    override fun mapRow(rs: ResultSet, rowNum: Int): NodeOptions {
        val id = rs.getObject("id", UUID::class.java)
        val parentId = rs.getObject("parent_id", UUID::class.java)
        val optionsString = rs.getString("options")
        val type = rs.getString("node_type")
        val options =
            objectMapper.readValue(optionsString, object : TypeReference<Map<OptionLibId, String?>>() {})
        return NodeOptions(
            id = id,
            parentId = parentId,
            options = options,
            nodeType = PrimitiveEquipment.PrimitiveEquipmentLibId.valueOf(type)
        )
    }
}