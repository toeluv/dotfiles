package ru.nti.dtps.equipmentmanager.scheme.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.OptionLibId
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.SchemeEditorError
import ru.nti.dtps.equipmentmanager.scheme.domain.command.Command
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoExtractor
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.CustomByNodeLibIdValidator
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemePersister
import ru.nti.dtps.equipmentmanager.scheme.usecase.ExecuteSchemeEditorCommand

@Component
class ExecuteSchemeEditorCommandUseCase(
    private val schemeExtractor: SchemeExtractor,
    private val schemePersister: SchemePersister,
    private val libInfoExtractor: LibInfoExtractor,
    private val customByNodeLibIdValidator: CustomByNodeLibIdValidator,
    @Value("\#[[\$]]#{app.allowed-primitive-port-number}")
    private val allowedPrimitivePortNumber: Int
) : ExecuteSchemeEditorCommand {

    override fun execute(command: Command): Either<CommandExecutionError, Scheme> {
        return schemeExtractor
            .getById(command.equipmentId.toUUID())
            ?.let { scheme ->
                scheme.execute(command, libInfoExtractor, allowedPrimitivePortNumber, customByNodeLibIdValidator)
                    .fold(
                        { it.toError().left() },
                        {
                            schemePersister.update(scheme)
                            scheme.right()
                        }
                    )
            } ?: CommandExecutionError.SchemeNotExistError(command.equipmentId.toStringValue()).left()
    }
}

private fun SchemeEditorError.toError() =
    when (this) {
        is SchemeEditorError.LinkWithIdAlreadyPresented -> CommandExecutionError.LinkWithIdAlreadyPresented(this.id)
        is SchemeEditorError.LinkDoesNotExistError -> CommandExecutionError.LinkDoesNotExistError(this.id)
        is SchemeEditorError.EquipmentDoesNotExistError -> CommandExecutionError.PrimitiveEquipmentDoesNotExistError(
            this.id
        )
        is SchemeEditorError.EquipmentOptionsValidationError ->
            CommandExecutionError.PrimitiveEquipmentOptionsValidationError(this.validationError)

        is SchemeEditorError.EquipmentWithPresentedNameAlreadyExist ->
            CommandExecutionError.PrimitiveEquipmentWithPresentedNameAlreadyExist(this.name)

        is SchemeEditorError.SchemeAlreadyContainsMaxCountPrimitivePortError ->
            CommandExecutionError.SchemeAlreadyContainsMaxCountPrimitivePortError(
                this.allowedPrimitivePortNumber,
                this.currentPrimitivePortNumber
            )

        is SchemeEditorError.VariableNameOptionIsNotValidOrUniqueError ->
            CommandExecutionError.VariableNameOptionIsNotValidError(
                this.value
            )

        is SchemeEditorError.RequiredFieldNotFoundError ->
            CommandExecutionError.RequiredFieldNotFoundError(
                this.equipmentId, this.equipmentName, this.optionLibId
            )

        is SchemeEditorError.MutualityOptionIsNotValidError ->
            CommandExecutionError.MutualityOptionIsNotValidError(
                this.equipmentId, this.equipmentName
            )
    }

sealed class CommandExecutionError {
    class LinkWithIdAlreadyPresented(val id: String) : CommandExecutionError()
    class LinkDoesNotExistError(val id: String) : CommandExecutionError()
    class PrimitiveEquipmentDoesNotExistError(val id: String) : CommandExecutionError()
    class PrimitiveEquipmentWithPresentedNameAlreadyExist(val name: String) : CommandExecutionError()
    class PrimitiveEquipmentOptionsValidationError(
        val validationError: SchemeValidationError
    ) : CommandExecutionError()
    class VariableNameOptionIsNotValidError(val value: String): CommandExecutionError()
    class SchemeAlreadyContainsMaxCountPrimitivePortError(
        val allowedPrimitivePortNumber: Int,
        val currentPrimitivePortNumber: Int
    ): CommandExecutionError()
    class SchemeNotExistError(val id: String) : CommandExecutionError()
    class RequiredFieldNotFoundError(
        val equipmentId: String,
        val equipmentName: String,
        val optionLibId: OptionLibId
    ) : CommandExecutionError()
    class MutualityOptionIsNotValidError(
        val equipmentId: String,
        val equipmentName: String
    ) : CommandExecutionError()
}
