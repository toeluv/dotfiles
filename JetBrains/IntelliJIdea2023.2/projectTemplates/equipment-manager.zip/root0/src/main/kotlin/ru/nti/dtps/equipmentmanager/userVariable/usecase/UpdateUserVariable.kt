package ru.nti.dtps.equipmentmanager.userVariable.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable
import ru.nti.dtps.equipmentmanager.userVariable.rest.UpdateUserVariableCommand

interface UpdateUserVariable {
    fun execute(command: UpdateUserVariableCommand): Either<UpdateUserVariableUseCaseError, UserVariable>
}

sealed class UpdateUserVariableUseCaseError {
    class VariableNameAlreadyExistsError(val value: String) : UpdateUserVariableUseCaseError()
    object UserVariableNotFoundError : UpdateUserVariableUseCaseError()
}