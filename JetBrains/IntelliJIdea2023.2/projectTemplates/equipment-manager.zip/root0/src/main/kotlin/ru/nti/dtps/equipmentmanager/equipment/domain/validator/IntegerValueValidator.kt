package ru.nti.dtps.equipmentmanager.equipment.domain.validator

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.DataType

@Component
class IntegerValueValidator : InputValueValidator {
    override fun validate(
        minValue: String,
        maxValue: String,
        defaultValue: String
    ): Either<InputValueError, Unit> {
        val minValueInt = minValue.toIntOrNull()
        val maxValueInt = maxValue.toIntOrNull()
        val defaultValueInt = defaultValue.toIntOrNull()
        return if (minValueInt == null || maxValueInt == null || defaultValueInt == null) {
            InputValueError.InvalidInputValueFormat.left()
        }
        else if (minValueInt >= maxValueInt || defaultValueInt !in minValueInt..maxValueInt) {
            InputValueError.InvalidInputValueRange.left()
        }
        else Unit.right()
    }

    override fun getDataType() = DataType.INTEGER
}
