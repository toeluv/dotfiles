package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.rest.groups.DeleteEquipmentGroupCommand

interface DeleteEquipmentGroup {
    fun execute(command: DeleteEquipmentGroupCommand): Either<DeleteEquipmentGroupUseCaseError, EquipmentGroup>
}

sealed class DeleteEquipmentGroupUseCaseError : UseCaseError {
    object EquipmentGroupNotExistUseCaseError : DeleteEquipmentGroupUseCaseError()
    object EquipmentGroupIsNotEmptyUseCaseError : DeleteEquipmentGroupUseCaseError()
}