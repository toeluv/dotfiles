package ru.nti.dtps.equipmentmanager.outputs.domain

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalNameAlreadyExists
import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo

class OutputSignal private constructor(
    val id: OutputSignalId,
    val equipmentId: EquipmentId,
    name: OutputSignalName,
    unitType: UnitType,
    dataType: DataType,
    variableName: VariableName
) {
    var name = name
        internal set
    var unitType = unitType
        internal set
    var dataType = dataType
        internal set
    var variableName = variableName
        internal set

    companion object {
        fun create(
            id: OutputSignalId,
            equipmentId: EquipmentId,
            name: OutputSignalName,
            unitType: UnitType,
            dataType: DataType,
            variableName: VariableName,
            outputSignalNameAlreadyExists: OutputSignalNameAlreadyExists
        ): Either<OutputSignalError, OutputSignal> {
            return if (outputSignalNameAlreadyExists(name, equipmentId)) {
                OutputSignalError.OutputSignalNameAlreadyExistError(name.toStringValue()).left()
            } else {
                OutputSignal(
                    id, equipmentId, name, unitType, dataType, variableName
                ).right()
            }
        }

        fun restore(
            id: OutputSignalId,
            equipmentId: EquipmentId,
            name: OutputSignalName,
            unitType: UnitType,
            dataType: DataType,
            variableName: VariableName
        ) = OutputSignal(
            id, equipmentId, name, unitType, dataType, variableName
        )
    }

    fun update(
        name: OutputSignalName,
        unitType: UnitType,
        dataType: DataType,
        variableName: VariableName,
        outputSignalNameAlreadyExists: OutputSignalNameAlreadyExists
    ): Either<OutputSignalError, OutputSignal> {
        return if (outputSignalNameAlreadyExists(this.id, name, equipmentId)) {
            OutputSignalError.OutputSignalNameAlreadyExistError(name.toStringValue()).left()
        } else {
            this.name = name
            this.unitType = unitType
            this.dataType = dataType
            this.variableName = variableName

            return this.right()
        }
    }

    fun toSignalView() =
        SignalInfo.create(
            id = this.id.toUUID(),
            name = this.name.toStringValue(),
            dimension = this.unitType.name,
            dimensionForSimulation = null,
            conversionFactor = null,
            numberOfCharacters = 0.0,
            showOnSimulation = false,
            groupId = "noId",
            sequence = 0
        )

    fun buildOutputSignalName(): String {
        return "#[[\$]]#{name.toStringValue()}, #[[\$]]#{this.unitType.toUnit()}"
    }
}

sealed class OutputSignalError {
    class OutputSignalNameAlreadyExistError(val name: String) : OutputSignalError()
}
