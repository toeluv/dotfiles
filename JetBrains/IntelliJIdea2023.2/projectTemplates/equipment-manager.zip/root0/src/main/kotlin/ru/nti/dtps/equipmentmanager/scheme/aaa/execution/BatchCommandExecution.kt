package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.BatchCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.CommandExecutionError
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.CommandExecutor
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.UserCommand
import kotlin.reflect.KClass

@Component
class BatchCommandExecution(
    private val executors: HashMap<KClass<*>, CommandExecutor<in UserCommand>>
) {

    fun execute(batchCommand: BatchCommand): Either<CommandExecutionError, Unit> {
        val executionResult = batchCommand.userCommands.map { command ->
            executors[command::class]?.execute(command)?.getOrElse { return it.left() }
        }.toList()

    }
}