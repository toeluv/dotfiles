package ru.nti.dtps.equipmentmanager.equipment.kafka

import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.apache.kafka.common.serialization.Serializer
import ru.nti.dtps.equipment.meta.info.dataclass.common.Language
import ru.nti.dtps.equipment.meta.info.dataclass.equipment.measurement.ShowMeasurement
import ru.nti.dtps.equipment.meta.info.dataclass.equipment.port.Port
import ru.nti.dtps.equipmentmanager.scheme.domain.Alignment

class EquipmentEventMessageSerializer : Serializer<EquipmentEventMessage> {
    private val mapper = jacksonObjectMapper().setSerializationInclusion(JsonInclude.Include.NON_NULL)
    override fun serialize(p0: String?, message: EquipmentEventMessage?): ByteArray {
        return message.let { mapper.writeValueAsBytes(it) } ?: byteArrayOf()
    }
}

/* EquipmentLib, fieldTypes, measurementTypes, parameterGroups may be null when command is DELETE */
data class EquipmentEventMessage internal constructor(
    val id: String,
    val companyId: String,
    val equipmentLib: EquipmentLib?,
    val fieldTypes: List<FieldType>?,
    val measurementTypes: List<MeasurementType>?,
    val parameterGroups: List<ParameterGroup>?,
    val version: Long,
    val eventType: EquipmentEventType
) {
    companion object {
        fun buildPublishMessage(
            id: String,
            companyId: String,
            equipmentLib: EquipmentLib,
            fieldTypes: List<FieldType>,
            measurementTypes: List<MeasurementType>,
            parameterGroups: List<ParameterGroup>,
            version: Long
        ): EquipmentEventMessage {

            return EquipmentEventMessage(
                id,
                companyId,
                equipmentLib,
                fieldTypes,
                measurementTypes,
                parameterGroups,
                version,
                EquipmentEventType.UPDATE
            )
        }

        fun buildDeleteMessage(
            id: String,
            companyId: String,
            version: Long
        ): EquipmentEventMessage {
            return EquipmentEventMessage(
                id,
                companyId,
                null,
                null,
                null,
                null,
                version,
                EquipmentEventType.DELETE
            )
        }
    }
}

enum class EquipmentEventType {
    UPDATE, DELETE
}

data class EquipmentLib(
    val id: String,
    val height: Map<Language, Double>,
    val width: Map<Language, Double>,
    val name: Map<Language, String>,
    val labelDirection: Map<Language, String>,
    val svg: Map<Language, String>,
    val ports: List<PortLib>,
    val fields: List<FieldLib>,
    val measurements: List<MeasurementLib>,
    val controls: List<ControlLib>
)

data class PortLib(
    val libId: String,
    val phases: Port.Phases,
    val alignment: Map<Language, Alignment>,
    val x: Map<Language, Double>,
    val y: Map<Language, Double>
)

data class FieldLib(
    val id: String,
    val typeId: String,
    val groupId: String,
    val name: Map<Language, String>,
    val min: String,
    val max: String,
    val step: String?,
    val defaultValue: String,
    val optional: Boolean = false
)

data class MeasurementLib(
    val subTypeId: String,
    val typeId: String,
    val name: Map<Language, String>,
    val relatedPortLibId: String,
    val show: ShowMeasurement
)

data class ControlLib(
    val id: String,
    val typeId: String,
    val name: Map<Language, String>,
    val step: Double? = null,
    val min: Double? = null,
    val max: Double? = null,
    val defaultValue: String? = null
)

data class FieldType(
    val id: String,
    val valueType: String,
    val min: Double? = null,
    val max: Double? = null,
    val step: Double? = null,
    val regex: String? = null,
    val length: Int? = null,
    val minLength: Int? = null,
    val maxLength: Int? = null
)

data class MeasurementType(
    val id: String,
    val unit: Map<Language, String>,
    val arrowPresence: Boolean,
    val valueType: String,
    val digitsAfterComma: Int = 0,
    val multiplier: Double
)

class ParameterGroup(
    val id: String,
    val name: Map<Language, String>
)
