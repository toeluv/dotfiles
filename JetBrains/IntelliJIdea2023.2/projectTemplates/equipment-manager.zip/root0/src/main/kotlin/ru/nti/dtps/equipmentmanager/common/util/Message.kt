package ru.nti.dtps.equipmentmanager.common.util

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import java.net.URI


data class BusinessError(val message: String)

typealias Message = String

data class ValidationError(val errorCode: String): ru.nti.dtps.equipmentmanager.common.error.BusinessError

fun restBusinessError(message: String, status: HttpStatus): ResponseEntity<BusinessError> =
    ResponseEntity
        .status(status)
        .body(BusinessError(message))

fun restError(body: Any? = null, status: HttpStatus) = ResponseEntity
    .status(status)
    .body(body)

fun ok(body: Any?) = ResponseEntity.ok().body(body)

fun created(location: URI) = ResponseEntity.created(location).build<Any>()

fun noContent() = ResponseEntity.noContent().build<Any>()

fun internalServerError() = ResponseEntity.internalServerError().build<Any>()