package ru.nti.dtps.equipmentmanager.svg.persist.adapter

import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgDto
import java.util.UUID

interface SvgExtractor {
    fun getById(id: UUID): SvgDto?
}