package ru.nti.dtps.equipmentmanager.equipment.persist.adapter

import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import java.util.*

interface EquipmentPersister {
    fun save(equipment: Equipment)
    fun update(equipment: Equipment)
    fun delete(id: UUID)
}