package ru.nti.dtps.equipmentmanager.common.configuration.kafka

import org.apache.kafka.clients.CommonClientConfigs
import org.apache.kafka.common.config.SaslConfigs
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.stereotype.Component

@Component
@ConfigurationProperties(prefix = "kafka.sasl")
data class KafkaSaslProperties(
    var username: String = "",
    var password: String = "",
    var mechanism: String = "",
    var securityProtocol: String = ""
) {

    private val saslJaasConfig = "org.apache.kafka.common.security.scram.ScramLoginModule required username=%s password=%s;"
    fun getSaslProperties(): Map<String, Any> {
        val propertiesMap: MutableMap<String, Any> = mutableMapOf()
        if (username.isNotBlank() && password.isNotBlank() && mechanism.isNotBlank() && securityProtocol.isNotBlank()) {
            propertiesMap[SaslConfigs.SASL_JAAS_CONFIG] = saslJaasConfig.format(username, password)
            propertiesMap[SaslConfigs.SASL_MECHANISM] = mechanism
            propertiesMap[CommonClientConfigs.SECURITY_PROTOCOL_CONFIG] = securityProtocol
        }
        return propertiesMap
    }
}
