package ru.nti.dtps.equipmentmanager.scheme.domain.validator

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme

@Component
class PrimitivePortNumberValidator(
    @Value("\#[[\$]]#{app.allowed-primitive-port-number}")
    private val allowedPrimitivePortNumber: Int
) : AbstractSchemeValidator(Level.ZERO) {
    override fun validate(scheme: Scheme): Either<SchemeValidationError, Unit> {
        val portsNumber = scheme.primitiveNodes.values
            .filter {
                it.type == PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH ||
                    it.type == PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH
            }
            .size
        return if (portsNumber > allowedPrimitivePortNumber) (
            PrimitivePortsCountIsMoreThenLimitErrorScheme(
                allowedPrimitivePortNumber,
                portsNumber
            ).left()
        ) else Unit.right()
    }
}

class PrimitivePortsCountIsMoreThenLimitErrorScheme(
    val allowedPrimitivePortNumber: Int,
    val currentPrimitivePortNumber: Int
) : SchemeValidationError