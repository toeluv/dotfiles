package ru.nti.dtps.equipmentmanager.parameter.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.ArraySchema
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import ru.nti.dtps.equipmentmanager.parameter.usecase.*

@RestController
class ParameterController(
    private val messageSource: MessageSourceService,
    private val getAllParameters: GetAllParameters,
    private val createParameter: CreateParameter,
    private val updateParameter: UpdateParameter,
    private val deleteParameter: DeleteParameter
) {

    @Operation(summary = "Execute get all parameters command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "All parameters are found", content = [
                    (Content(
                        mediaType = "application/json",
                        array = ArraySchema(schema = Schema(implementation = ParameterView::class))
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @GetMapping("#[[\$]]#API_V1_EQUIPMENT_PARAMETERS/{equipmentId}")
    fun getAll(@PathVariable equipmentId: String): ResponseEntity<*> {
        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    ok(getAllParameters.execute(validEquipmentId).map { it.toView() })
                }
            )
    }

    @Operation(summary = "Execute create parameter command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Parameter was created", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = ParameterView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Invalid variable format", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Invalid variable range", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409",
                description = "Parameter name has not unique value",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "409", description = "Parameter with current name is already exist", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PostMapping("#[[\$]]#API_V1_EQUIPMENT_PARAMETERS/{equipmentId}")
    fun create(
        @PathVariable equipmentId: String,
        @RequestBody request: CreateParameterRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    createParameter.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { parameter -> ok(parameter.toView()) }
                        )
                }
            )
    }

    @Operation(summary = "Execute update parameter command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Parameter was updated", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = ParameterView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Invalid variable format", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Invalid variable range", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Parameter not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409",
                description = "Parameter name has not unique value",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "409", description = "Parameter with current name is already exist", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PutMapping("#[[\$]]#API_V1_EQUIPMENT_PARAMETERS/{equipmentId}")
    fun update(
        @PathVariable equipmentId: String,
        @RequestBody request: UpdateParameterRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    updateParameter.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { parameter -> ok(parameter.toView()) }
                        )
                }
            )
    }

    @Operation(summary = "Execute delete parameter command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Parameter was deleted", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = Unit::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Equipment not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @DeleteMapping("#[[\$]]#API_V1_EQUIPMENT_PARAMETERS/{equipmentId}")
    fun delete(
        @PathVariable equipmentId: String,
        @RequestBody request: DeleteParameterRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    deleteParameter.execute(it).fold(
                        { error -> error.toRestError() },
                        { unit -> ok(unit) }
                    )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun CreateParameterUseCaseError.toRestError() = when (this) {
        is CreateParameterUseCaseError.ParameterNameAlreadyExistsError ->
            restBusinessError(
                messageSource.getMessage("api.parameter.error.validation.twins").format(name),
                HttpStatus.CONFLICT
            )

        is CreateParameterUseCaseError.ParameterHasInvalidValueFormatError ->
            restBusinessError(
                messageSource.getMessage("api.value.error.not-valid"),
                HttpStatus.BAD_REQUEST
            )

        is CreateParameterUseCaseError.ParameterHasInvalidValueRangeError ->
            restBusinessError(
                messageSource.getMessage("api.value.error.range.not-valid"),
                HttpStatus.BAD_REQUEST
            )

        is CreateParameterUseCaseError.VariableNameAlreadyExistsError ->
            restBusinessError(
                messageSource.getMessage("api.variable.error.validation.twins").format(name),
                HttpStatus.CONFLICT
            )

    }

    private fun UpdateParameterUseCaseError.toRestError() = when (this) {
        is UpdateParameterUseCaseError.ParameterNameAlreadyExistsError ->
            restBusinessError(
                messageSource.getMessage("api.scheme.error.equipment.parameter.name.twins").format(name),
                HttpStatus.CONFLICT
            )

        UpdateParameterUseCaseError.ParameterHasInvalidValueFormatError ->
            restBusinessError(
                messageSource.getMessage("api.value.error.not-valid"),
                HttpStatus.BAD_REQUEST
            )

        UpdateParameterUseCaseError.ParameterHasInvalidValueRangeError ->
            restBusinessError(
                messageSource.getMessage("api.value.error.range.not-valid"),
                HttpStatus.BAD_REQUEST
            )

        UpdateParameterUseCaseError.ParameterNotFoundError ->
            restBusinessError(
                messageSource.getMessage("api.parameter.error.not-found"),
                HttpStatus.NOT_FOUND
            )

        is UpdateParameterUseCaseError.VariableNameAlreadyExistsError ->
            restBusinessError(
                messageSource.getMessage("api.variable.error.validation.twins"),
                HttpStatus.CONFLICT
            )
    }

    private fun DeleteParameterUseCaseError.toRestError() = when (this) {
        is DeleteParameterUseCaseError.ParameterNotFoundError ->
            restBusinessError(
                messageSource.getMessage("api.parameter.error.not-found"),
                HttpStatus.NOT_FOUND
            )
    }
}

data class ParameterView(
    val id: String,
    val equipmentId: String,
    val name: String,
    val groupId: String,
    val unitType: String,
    val dataType: String,
    val minValue: String,
    val maxValue: String,
    val defaultValue: String,
    val variableName: String
)

private fun Parameter.toView() = ParameterView(
    id.toStringValue(),
    equipmentId.toStringValue(),
    name.toStringValue(),
    groupId,
    unitType.name,
    dataType.name,
    minValue,
    maxValue,
    defaultValue,
    variableName.toStringValue()
)
