package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError

data class OutputSignalName(
    val name: String
) {
    companion object {
        fun from(name: String): Either<CreateOutputSignalNameError, OutputSignalName> =
            if (name.isNotBlank()) {
                OutputSignalName(name).right()
            } else {
                CreateOutputSignalNameError.EmptyOutputSignalName.left()
            }
    }

    fun toStringValue() = name

}

sealed class CreateOutputSignalNameError : BusinessError {
    object EmptyOutputSignalName : CreateOutputSignalNameError()
}