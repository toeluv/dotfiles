package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.ChangeSchemeNodeEditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.EditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeNode
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeNodeExtractor

@Component
class ChangeNodeRotationExecutor(
    private val schemeNodeExtractor: SchemeNodeExtractor,
) : CommandExecutor<ChangeNodeRotationUserCommand> {

    private val logger = LoggerFactory.getLogger(ChangeNodeRotationExecutor::class.java)

    override fun execute(command: ChangeNodeRotationUserCommand): Either<CommandExecutionError, ChangeNodeRotationUserCommandSuccessResult> {
        val schemeNode = schemeNodeExtractor.extract(command.equipmentId, command.nodeId)

        if(schemeNode == null){
            logger.warn("Node with id #[[\$]]#{command.nodeId} not found, unredoable was canceled for batch command")
            return NodeNotFoundError(command.nodeId.toString()).left()
        }

        return ChangeNodeRotationUserCommandSuccessResult(schemeNode, command).right()
    }
}

class ChangeNodeRotationUserCommandSuccessResult(
    val schemeNode: SchemeNode,
    val command: ChangeNodeRotationUserCommand
) : CommandSuccessResult {
    override fun undo() = ChangeNodeRotationUserCommand(
        nodeId = command.nodeId,
        equipmentId = command.equipmentId,
        body = ChangeNodeRotation(
            id = command.nodeId,
            coords = schemeNode.coords,
            hour = schemeNode.hour
        )
    )

    override fun editorCommands(): List<EditorCommand> {
        return listOf(
            ChangeSchemeNodeEditorCommand.build(command, schemeNode),
        )
    }
}