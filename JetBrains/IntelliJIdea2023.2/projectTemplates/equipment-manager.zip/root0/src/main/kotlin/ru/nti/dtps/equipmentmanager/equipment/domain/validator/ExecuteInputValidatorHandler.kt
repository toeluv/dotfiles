package ru.nti.dtps.equipmentmanager.equipment.domain.validator

import arrow.core.Either
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.DataType

@Component
class ExecuteInputValidatorHandler(
    inputValueValidatorList: List<InputValueValidator>
) : InputValidatorHandler {

    private val inputValueValidatorMap: Map<DataType, InputValueValidator> =
        inputValueValidatorList.associateBy { it.getDataType() }

    override fun handle(
        dataType: DataType,
        minValue: String,
        maxValue: String,
        defaultValue: String
    ): Either<InputValueError, Unit> {
        return inputValueValidatorMap[dataType]!!
            .validate(minValue, maxValue, defaultValue)
    }
}