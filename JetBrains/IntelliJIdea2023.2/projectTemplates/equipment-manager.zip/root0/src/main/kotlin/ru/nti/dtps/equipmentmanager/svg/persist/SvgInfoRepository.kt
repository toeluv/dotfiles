package ru.nti.dtps.equipmentmanager.svg.persist

import com.fasterxml.jackson.databind.ObjectMapper
import org.postgresql.util.PGobject
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.*
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgInfoDto
import java.util.*
import javax.sql.DataSource

@Component
class SvgInfoRepository(
    dataSource: DataSource,
    private val objectMapper: ObjectMapper
) : SvgInfoExtractor, SvgInfoPersister {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    override fun getById(id: UUID): SvgInfoDto? {
        return jdbcTemplate.query(
            "SELECT * FROM public.svg_info WHERE id = :id",
            mapOf("id" to id),
            SvgInfoResultSetExtractor()
        )
    }

    @Transactional
    override fun save(svgInfoDto: SvgInfoDto) {
        val params = mapOf(
            "id" to svgInfoDto.id,
            "coords" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(svgInfoDto.coords)
            },
            "dimensions" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(svgInfoDto.dimensions)
            },
            "hour" to svgInfoDto.hour,
            "ports" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(svgInfoDto.ports)
            },
            "placeholders" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(svgInfoDto.placeholders)
            }
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.svg_info(id, coords, dimensions, hour, ports, placeholders)
            VALUES(
            :id, 
            :coords, 
            :dimensions,
            :hour,
            :ports,
            :placeholders
            )
            """.trimMargin(), params
        )
    }

    @Transactional
    override fun update(svgInfoDto: SvgInfoDto) {
        val params = mapOf(
            "id" to svgInfoDto.id,
            "coords" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(svgInfoDto.coords)
            },
            "dimensions" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(svgInfoDto.dimensions)
            },
            "hour" to svgInfoDto.hour,
            "ports" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(svgInfoDto.ports)
            },
            "placeholders" to PGobject().apply {
                this.type = "json"
                this.value = objectMapper.writeValueAsString(svgInfoDto.placeholders)
            }
        )

        val update = jdbcTemplate.update(
            """
            UPDATE public.svg_info SET
            coords = :coords, 
            dimensions = :dimensions,
            hour = :hour,
            ports = :ports,
            placeholders = :placeholders
            WHERE id = :id
            """.trimIndent(), params
        )
        if (update == 0) {
            save(svgInfoDto)
        }
    }

    override fun delete(id: UUID) {
        jdbcTemplate.update(
            "DELETE from public.svg_info WHERE id = :id",
            mapOf("id" to id)
        )
    }
}
