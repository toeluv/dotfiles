package ru.nti.dtps.equipmentmanager.equipment.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentError
import ru.nti.dtps.equipmentmanager.equipment.domain.command.CreateEquipmentCommand
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentPersister
import ru.nti.dtps.equipmentmanager.equipment.usecase.CreateEquipment
import ru.nti.dtps.equipmentmanager.equipment.usecase.CreateEquipmentUseCaseError
import ru.nti.dtps.equipmentmanager.equipment.usecase.EquipmentNameAlreadyExists
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemePersister
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SignalInfoPersister
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgInfoPersister
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgPersister
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SignalInfoDto
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgDto
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgInfoDto
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserInfoProvider

@Component
class CreateEquipmentUseCase(
    private val equipmentPersister: EquipmentPersister,
    private val equipmentNameAlreadyExists: EquipmentNameAlreadyExists,
    private val userInfoProvider: CurrentUserInfoProvider,
    private val schemePersister: SchemePersister,
    private val svgPersister: SvgPersister,
    private val svgInfoPersister: SvgInfoPersister,
    private val signalInfoPersister: SignalInfoPersister
) : CreateEquipment {

    override fun execute(command: CreateEquipmentCommand): Either<CreateEquipmentUseCaseError, Equipment> {
        return Equipment.create(command, equipmentNameAlreadyExists, userInfoProvider.get())
            .fold(
                { it.toError().left() },
                { createdEquipment ->
                    equipmentPersister.save(createdEquipment)
                    schemePersister.save(Scheme.create(createdEquipment.id))
                    svgPersister.save(SvgDto.create(createdEquipment.id.toUUID()))
                    svgInfoPersister.save(SvgInfoDto.create(createdEquipment.id.toUUID()))
                    signalInfoPersister.save(SignalInfoDto.create(createdEquipment.id.toUUID()))
                    createdEquipment.right()
                }
            )
    }

    private fun EquipmentError.toError(): CreateEquipmentUseCaseError {
        return when (this) {
            is EquipmentError.EquipmentExistWithSameNameError ->
                CreateEquipmentUseCaseError.EquipmentNameAlreadyExistUseCaseError(this.name)
        }
    }
}
