package ru.nti.dtps.equipmentmanager.scheme.domain.validator.branch

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExists
import ru.nti.dtps.equipmentmanager.scheme.domain.MutualBranchError
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme

@Component
class MutualBranchVariableNameValidator(
    private val variableNameAlreadyExists: VariableNameAlreadyExists
) : MutualBranchVariableValidator {
    override fun validate(mutualBranchName: VariableName, scheme: Scheme): Either<MutualBranchError, Unit> {
        return if (variableNameAlreadyExists(mutualBranchName, scheme.id)) {
            MutualBranchError.VariableNameIsNotValidOrUniqueError(mutualBranchName.toStringValue()).left()
        } else {
            Unit.right()
        }
    }
}
