package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.EquipmentGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.GetEquipmentGroupById
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.GetEquipmentGroupByIdUseCaseError
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class GetEquipmentGroupByIdUseCase(
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider,
    private val equipmentGroupExtractor: EquipmentGroupExtractor
) : GetEquipmentGroupById {
    override fun execute(groupId: String): Either<GetEquipmentGroupByIdUseCaseError, EquipmentGroup> {
        val equipmentGroup = equipmentGroupExtractor.getEquipmentGroupByIdAndCompanyId(
            groupId, currentUserCompanyIdProvider.get()
        ) ?: return GetEquipmentGroupByIdUseCaseError.EquipmentGroupNotExistsUseCaseError.left()
        return equipmentGroup.right()
    }
}