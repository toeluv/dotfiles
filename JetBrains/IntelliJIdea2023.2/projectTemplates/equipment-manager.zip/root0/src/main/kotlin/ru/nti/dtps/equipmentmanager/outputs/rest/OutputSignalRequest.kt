package ru.nti.dtps.equipmentmanager.outputs.rest

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.util.ValidationError

data class CreateOutputSignalRequest(
    val id: String,
    val equipmentId: String,
    val name: String,
    val unitType: UnitType,
    val dataType: DataType,
    val variableName: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, CreateOutputSignalCommand> {
        val validId = OutputSignalId.validated(id).getOrElse { return it.left() }
        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }
        val name = OutputSignalName.validated(name).getOrElse { return it.left() }
        val variableName = VariableName.validated(variableName).getOrElse { return it.left() }
        return CreateOutputSignalCommand(validId, validEquipmentId, name, unitType, dataType, variableName).right()
    }
}

data class UpdateOutputSignalRequest(
    val id: String,
    val equipmentId: String,
    val name: String,
    val unitType: UnitType,
    val dataType: DataType,
    val variableName: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, UpdateOutputSignalCommand> {
        val validId = OutputSignalId.validated(id).getOrElse { return it.left() }
        val validEquipmentId = EquipmentId.validated(equipmentId).getOrElse { return it.left() }
        val name = OutputSignalName.validated(name).getOrElse { return it.left() }
        val variableName = VariableName.validated(variableName).getOrElse { return it.left() }
        return UpdateOutputSignalCommand(validId, validEquipmentId, name, unitType, dataType, variableName).right()
    }
}

data class DeleteOutputSignalRequest(
    val id: String
) {
    fun buildCommand(equipmentId: String): Either<ValidationError, DeleteOutputSignalCommand> {
        EquipmentId.validated(equipmentId).mapLeft { return it.left() }
        val validId = OutputSignalId.validated(id).getOrElse { return it.left() }
        return DeleteOutputSignalCommand(validId).right()
    }
}
