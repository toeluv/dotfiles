package ru.nti.dtps.equipmentmanager.common.util

import org.springframework.context.MessageSource
import org.springframework.stereotype.Service
import ru.nti.dtps.equipmentmanager.common.configuration.AppProperties

@Service
class MessageSourceService(
    private val appProperties: AppProperties,
    private val messageSource: MessageSource
) {
    fun getMessage(code: String): String {
        return messageSource.getMessage(code, null, appProperties.getLocale())
    }

}