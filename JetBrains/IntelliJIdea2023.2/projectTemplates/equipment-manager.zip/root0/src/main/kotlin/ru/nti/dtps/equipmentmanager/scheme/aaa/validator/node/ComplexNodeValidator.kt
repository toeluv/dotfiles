package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node

import arrow.core.Either
import arrow.core.left
import arrow.core.mapOrAccumulate
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.BusinessNodeValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeToValidate
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeValidationError

@Component
class ComplexNodeValidator(
    nodeValidators: List<BusinessNodeValidator>
) {
    private val sortedNodeValidators = nodeValidators.sortedBy { it.order() }

    fun validate(node: NodeToValidate): Either<NodeValidationError, Unit> {
        return sortedNodeValidators
            .map { it.validate(node) }
            .mapOrAccumulate { it.bind() }
            .fold(
                { it.first().left() },
                { Unit.right() }
            )
    }
}