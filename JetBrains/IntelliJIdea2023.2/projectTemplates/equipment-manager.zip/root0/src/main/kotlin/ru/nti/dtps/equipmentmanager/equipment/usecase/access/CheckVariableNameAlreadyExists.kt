package ru.nti.dtps.equipmentmanager.equipment.usecase.access

import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExists
import java.util.*
import javax.sql.DataSource

@Component
class CheckVariableNameAlreadyExists(
    dataSource: DataSource
) : VariableNameAlreadyExists {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    override operator fun invoke(variableName: VariableName, equipmentId: EquipmentId): Boolean {
        return jdbcTemplate.query(
            """
            SELECT EXISTS
            ( SELECT 1 FROM public.variable_name_view
            WHERE variable_name = :variable_name
            AND equipment_id = :equipment_id);
            """.trimMargin(),
            mapOf(
                "variable_name" to variableName.toStringValue(),
                "equipment_id" to equipmentId.toUUID()
            ),
            ResultSetExtractor { rs ->
                rs.next()
                rs.getBoolean(1)
            }
        ) ?: false
    }

    override operator fun invoke(variableName: VariableName, equipmentId: EquipmentId, excludedId: UUID): Boolean {
        return jdbcTemplate.query(
            """
            SELECT EXISTS
            ( SELECT 1 FROM public.variable_name_view
            WHERE variable_name = :variable_name
            AND equipment_id = :equipment_id
            AND id <> :id);
            """.trimMargin(),
            mapOf(
                "variable_name" to variableName.toStringValue(),
                "equipment_id" to equipmentId.toUUID(),
                "id" to excludedId,
            ),
            ResultSetExtractor { rs ->
                rs.next()
                rs.getBoolean(1)
            }
        ) ?: false
    }
}