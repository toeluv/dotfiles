package ru.nti.dtps.equipmentmanager.outputs.usecase

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal

interface GetAllOutputSignalsByEquipment {
    fun execute(equipmentId: EquipmentId): List<OutputSignal>
}