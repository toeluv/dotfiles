package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.ParameterGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.GetParameterGroupById
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.GetParameterGroupByIdUseCaseError
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class GetParameterGroupByIdUseCase(
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider,
    private val parameterGroupExtractor: ParameterGroupExtractor
) : GetParameterGroupById {
    override fun execute(groupId: String): Either<GetParameterGroupByIdUseCaseError, ParameterGroup> {
        val parameterGroup = parameterGroupExtractor.getParameterGroupByIdAndCompanyId(
            groupId, currentUserCompanyIdProvider.get()
        ) ?: return GetParameterGroupByIdUseCaseError.ParameterGroupNotExistsUseCaseError.left()
        return parameterGroup.right()
    }
}