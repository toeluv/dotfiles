package ru.nti.dtps.equipmentmanager.equipment.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.domain.command.CreateEquipmentCommand

interface CreateEquipment {
    fun execute(command: CreateEquipmentCommand): Either<CreateEquipmentUseCaseError, Equipment>
}

sealed class CreateEquipmentUseCaseError : UseCaseError {
    class EquipmentNameAlreadyExistUseCaseError(val name: String) : CreateEquipmentUseCaseError()
}