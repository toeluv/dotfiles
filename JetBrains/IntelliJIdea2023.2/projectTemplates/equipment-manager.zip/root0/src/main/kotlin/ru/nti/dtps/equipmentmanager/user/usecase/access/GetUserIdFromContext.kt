package ru.nti.dtps.equipmentmanager.user.usecase.access

import ru.nti.dtps.equipmentmanager.common.types.UserId

interface GetUserIdFromContext {
    fun get(): UserId
}
