package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment

import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup

interface GetAllEquipmentGroups {
    fun execute(): Collection<EquipmentGroup>
}