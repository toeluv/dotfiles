package ru.nti.dtps.equipmentmanager.scheme.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PatchMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipment.meta.info.dataclass.common.Language
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.scheme.domain.command.SchemeValidateCommand
import ru.nti.dtps.equipmentmanager.common.util.API_V1_SCHEME_VALIDATE
import ru.nti.dtps.equipmentmanager.user.usecase.access.GetUserIdFromContext
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.*
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.*
import ru.nti.dtps.equipmentmanager.scheme.usecase.ValidateScheme
import ru.nti.dtps.equipmentmanager.scheme.usecase.scenarios.ValidateSchemeUseCaseError

@RestController
class ValidateSchemeEndpoint(
    private val validateScheme: ValidateScheme,
    private val messageSource: MessageSourceService,
    private val getUserIdFromContext: GetUserIdFromContext
) {

    @Operation(summary = "Validate scheme")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Scheme is valid", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = SchemeShortView::class)
                    ))]
            ),
            ApiResponse(responseCode = "400", description = "Unsupported request fields",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Primitive ports count is more then limit",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Scheme contains blank port connection",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Scheme does not contains required equipment",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Field value less then limit value",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Field value more then limit value",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Text field length don`t equal value",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Text field length more then max value",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Text field length less then min value",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Required field not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Primitive equipment does not have name",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Error during scheme validation",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Scheme not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "500", description = "Something went wrong, go to admin",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                ))])
        ]
    )
    @PatchMapping("#[[\$]]#API_V1_SCHEME_VALIDATE/{equipmentId}")
    fun validateScheme(
        @PathVariable equipmentId: String
    ): ResponseEntity<*> {
        val userId = getUserIdFromContext.get()

        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    validateScheme
                        .execute(SchemeValidateCommand(validEquipmentId, userId))
                        .fold(
                            {
                                restError(
                                    it.toRestError(messageSource),
                                    HttpStatus.BAD_REQUEST
                                )
                            },
                            { ok(it) }
                        )
                })
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )
}

data class ValidationRestError(
    val message: String,
    val equipmentId: String? = null
)

fun SchemeValidationError.toRestError(messageSource: MessageSourceService): ValidationRestError =
    when (this) {
        is PrimitivePortsCountIsMoreThenLimitErrorScheme -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.ports.number")
                .format(currentPrimitivePortNumber, allowedPrimitivePortNumber)
        )

        is SchemeConnectionValidationError.SchemeContainsBlankPortConnection -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.port.not-connected")
        )

        is SchemeDoesNotContainsRequiredEquipmentErrorScheme -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.required-equipments.not-found")
                .format(
                    requiredEquipmentLibIds
                        .joinToString(separator = "\", \"")
                )
        )

        is FieldValueLessThenLimitValueError -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.field-value.min-bound")
                .format(this.equipmentName, optionLib.name[Language.RU.name], this.boundValue),
            equipmentId
        )

        is FieldValueMoreThenLimitValueError -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.field-value.max-bound")
                .format(this.equipmentName, optionLib.name[Language.RU.name], this.boundValue),
            equipmentId
        )

        is TextFieldLengthDoNotEqualValueError -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.field-value.length")
                .format(this.equipmentName, optionLib.name[Language.RU.name], this.boundValue),
            equipmentId
        )

        is TextFieldLengthMoreThenMaxValueError -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.field-value.max-length")
                .format(this.equipmentName, optionLib.name[Language.RU.name], this.boundValue),
            equipmentId
        )

        is TextFieldLengthLessThenMinValueError -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.field-value.min-length")
                .format(this.equipmentName, optionLib.name[Language.RU.name], this.boundValue),
            equipmentId
        )

        is RequiredFieldNotFoundError -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.field-value.not-found")
                .format(equipmentName, optionLib.name[Language.RU.name]),
            equipmentId
        )

        is PrimitiveEquipmentDoesNotHaveName -> ValidationRestError(
            messageSource.getMessage("api.scheme.error.equipment-name.is-blank"),
            equipmentId
        )

        is ValidateSchemeUseCaseError.SchemeNotFoundError -> ValidationRestError(
            messageSource.getMessage("api.scheme.error.not-found"),
            id
        )

        else -> ValidationRestError(
            messageSource.getMessage("api.scheme.validation.error.base")
        )
    }