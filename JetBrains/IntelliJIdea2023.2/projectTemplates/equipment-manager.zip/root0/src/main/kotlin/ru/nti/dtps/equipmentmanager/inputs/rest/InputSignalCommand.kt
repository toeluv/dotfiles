package ru.nti.dtps.equipmentmanager.inputs.rest

import ru.nti.dtps.equipmentmanager.common.types.*


data class CreateInputSignalCommand(
    val id: InputSignalId,
    val equipmentId: EquipmentId,
    val name: InputSignalName,
    val unitType: UnitType,
    val dataType: DataType,
    val variableName: VariableName
)

data class UpdateInputSignalCommand(
    val id: InputSignalId,
    val equipmentId: EquipmentId,
    val name: InputSignalName,
    val unitType: UnitType,
    val dataType: DataType,
    val variableName: VariableName
)

data class DeleteInputSignalCommand(
    val id: InputSignalId
)
