package ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter

import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup

interface ParameterGroupExtractor {
    fun getAllParameterGroupsByCompanyId(companyId: CompanyId): Collection<ParameterGroup>
    fun getParameterGroupById(parameterGroupId: String): ParameterGroup?
    fun getParameterGroupByIdAndCompanyId(parameterGroupId: String, companyId: CompanyId): ParameterGroup?
    fun checkParameterGroupAlreadyExists(groupName: String, companyId: CompanyId): Boolean
}