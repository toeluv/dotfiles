package ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter

import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup

interface ParameterGroupPersister {
    fun save(parameterGroup: ParameterGroup)
    fun delete(parameterGroup: ParameterGroup)
}