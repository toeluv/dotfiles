package ru.nti.dtps.equipmentmanager.scheme.domain

data class XyCoords(
    val x: Double = 0.0,
    val y: Double = 0.0
)