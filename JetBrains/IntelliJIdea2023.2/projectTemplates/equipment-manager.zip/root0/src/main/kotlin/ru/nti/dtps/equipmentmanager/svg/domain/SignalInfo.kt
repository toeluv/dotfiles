package ru.nti.dtps.equipmentmanager.svg.domain

import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoExtractor
import java.util.UUID

class SignalInfo private constructor(
    val id: UUID,
    val name: String,
    val dimension: String,
    val dimensionForSimulation: String?,
    val conversionFactor: Double?,
    val numberOfCharacters: Double,
    val showOnSimulation: Boolean,
    val groupId: String,
    val sequence: Int
) {

    fun buildMeasurementName() = dimensionForSimulation?.let { "#[[\$]]#name, #[[\$]]#it" } ?: "#[[\$]]#name, #[[\$]]#dimension"

    companion object {
        fun create(
            id: UUID,
            name: String,
            dimension: String,
            dimensionForSimulation: String?,
            conversionFactor: Double?,
            numberOfCharacters: Double,
            showOnSimulation: Boolean,
            groupId: String,
            sequence: Int
        ) = SignalInfo(
            id,
            name,
            dimension,
            dimensionForSimulation,
            conversionFactor,
            numberOfCharacters,
            showOnSimulation,
            groupId,
            sequence
        )

        fun buildSignalsForPrimitivePort(
            primitiveEquipmentId: String,
            libInfoExtractor: LibInfoExtractor
        ): List<SignalInfo> {
            return libInfoExtractor.getPrimitivePortSignalInfo()
                .map {
                    SignalInfo(
                        UUID.randomUUID(),
                        name = it.name,
                        dimension = it.dimension,
                        dimensionForSimulation = null,
                        conversionFactor = null,
                        numberOfCharacters = 0.0,
                        showOnSimulation = false,
                        groupId = primitiveEquipmentId,
                        sequence = 0
                    )
                }
        }
    }
}
