package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.EquipmentGroupPersister
import ru.nti.dtps.equipmentmanager.equipment.rest.groups.CreateEquipmentGroupCommand
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.CreateEquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.CreateEquipmentGroupUseCaseError
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.EquipmentGroupAlreadyExists
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class CreateEquipmentGroupUseCase(
    private val equipmentGroupPersister: EquipmentGroupPersister,
    private val equipmentGroupAlreadyExists: EquipmentGroupAlreadyExists,
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider
) : CreateEquipmentGroup {
    override fun execute(command: CreateEquipmentGroupCommand): Either<CreateEquipmentGroupUseCaseError, EquipmentGroup> {
        if (equipmentGroupAlreadyExists(command.name)) {
            return CreateEquipmentGroupUseCaseError.EquipmentGroupNameAlreadyExistUseCaseError(command.name).left()
        }
        val createdGroup = EquipmentGroup.create(
            command.id,
            currentUserCompanyIdProvider.get().toStringValue(),
            command.name
        ).apply { equipmentGroupPersister.save(this) }
        return createdGroup.right()
    }
}
