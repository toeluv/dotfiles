package ru.nti.dtps.equipmentmanager.svg.domain

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import java.util.*

const val ALLOWED_MAX_COUNT_SIGNALS_IN_PLACEHOLDER = 6

class Placeholder private constructor(
    val id: UUID,
    val coords: XyCoords,
    val hour: Int,
    val signalIds: MutableList<String>
) {

    companion object {
        fun create(
            id: UUID,
            coords: XyCoords,
            hour: Int,
            signalIds: MutableList<String>
        ): Either<PlaceholderError, Placeholder> {
            checkSignalsInPlaceholderMaxCount(signalIds.size).mapLeft { return it.left() }

            return Placeholder(
                id, coords, hour, signalIds
            ).right()
        }

        private fun checkSignalsInPlaceholderMaxCount(signalsCount: Int): Either<PlaceholderError, Unit> {
            return if (signalsCount > ALLOWED_MAX_COUNT_SIGNALS_IN_PLACEHOLDER) {
                return PlaceholderError.MaxCountSignalsInPlaceholderError(
                    ALLOWED_MAX_COUNT_SIGNALS_IN_PLACEHOLDER,
                    signalsCount
                ).left()
            } else Unit.right()
        }
    }
}

sealed class PlaceholderError {
    class MaxCountSignalsInPlaceholderError(
        val allowedPlaceholdersCount: Int,
        val currentPlaceholdersCount: Int
    ) : PlaceholderError()
}
