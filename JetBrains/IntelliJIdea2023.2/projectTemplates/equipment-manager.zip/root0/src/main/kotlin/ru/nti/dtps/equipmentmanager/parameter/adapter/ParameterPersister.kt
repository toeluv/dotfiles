package ru.nti.dtps.equipmentmanager.parameter.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.ParameterId
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter

interface ParameterPersister {
    fun save(parameter: Parameter)
    fun update(parameter: Parameter)
    fun delete(id: ParameterId)
    fun deleteAllByEquipmentId(equipmentId: EquipmentId)
}