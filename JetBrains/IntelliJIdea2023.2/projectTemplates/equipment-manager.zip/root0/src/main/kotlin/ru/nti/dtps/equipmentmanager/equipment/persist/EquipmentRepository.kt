package ru.nti.dtps.equipmentmanager.equipment.persist

import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentName
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentPersister
import java.util.*
import javax.sql.DataSource

@Component
class EquipmentRepository(
    dataSource: DataSource
) : EquipmentExtractor, EquipmentPersister {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    override fun getAll(): Collection<Equipment> {
        return jdbcTemplate.query(
            "SELECT * FROM public.equipment",
            EquipmentRowMapper()
        ).toSet()
    }

    override fun getAllByCompanyId(companyId: CompanyId): Collection<Equipment> {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.equipment
            WHERE company_id = :company_id 
            """.trimMargin(),
            mapOf("company_id" to companyId.toUUID()),
            EquipmentRowMapper()
        ).toSet()
    }

    override fun getAllByGroupIdAndCompanyId(groupId: String?, companyId: CompanyId): Collection<Equipment> {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.equipment
            WHERE group_id = :group_id AND company_id = :company_id
            """.trimMargin(),
            mapOf("group_id" to groupId, "company_id" to companyId.toUUID()),
            EquipmentRowMapper()
        ).toSet()
    }

    override fun getByIdAndCompanyId(equipmentId: EquipmentId, companyId: CompanyId): Equipment? {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.equipment
            WHERE id = :id AND company_id = :company_id
            """.trimMargin(),
            mapOf("id" to equipmentId.toUUID(), "company_id" to companyId.toUUID()),
            EquipmentResultSetExtractor()
        )
    }

    override fun getById(equipmentId: EquipmentId): Equipment? {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.equipment
            WHERE id = :id
            """.trimMargin(),
            mapOf("id" to equipmentId.toUUID()),
            EquipmentResultSetExtractor()
        )
    }

    @Transactional
    override fun save(equipment: Equipment) {
        val params = mapOf(
            "id" to equipment.id.toUUID(),
            "company_id" to equipment.companyId.toUUID(),
            "name" to equipment.name.toStringValue(),
            "group_id" to equipment.groupId,
            "description" to equipment.description,
            "published" to equipment.published,
            "published_at" to equipment.publicationInfo?.publishedAt.toString(),
            "author_of_publish" to equipment.publicationInfo?.authorOfPublish.toString(),
            "version" to equipment.version,
            "author" to equipment.author,
            "created_at" to equipment.createdAt.toString(),
            "editor" to equipment.editor.toString(),
            "updated_at" to equipment.updatedAt.toString()
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.equipment(id, company_id, name, group_id, description, published,
             published_at, author_of_publish, version, author,
             created_at, editor, updated_at)
            VALUES(
            :id, 
            :company_id, 
            :name,
            :group_id,
            :description,
            :published,
            :published_at,
            :author_of_publish,
            :version,
            :author,
            :created_at,
            :editor,
            :updated_at
            )
            """.trimMargin(), params
        )
    }

    @Transactional
    override fun update(equipment: Equipment) {
        val params = mapOf(
            "id" to equipment.id.toUUID(),
            "company_id" to equipment.companyId.toUUID(),
            "name" to equipment.name.toStringValue(),
            "group_id" to equipment.groupId,
            "description" to equipment.description,
            "published" to equipment.published,
            "published_at" to equipment.publicationInfo?.publishedAt.toString(),
            "author_of_publish" to equipment.publicationInfo?.authorOfPublish.toString(),
            "version" to equipment.version,
            "author" to equipment.author,
            "created_at" to equipment.createdAt.toString(),
            "editor" to equipment.editor.toString(),
            "updated_at" to equipment.updatedAt.toString()
        )

        jdbcTemplate.update(
            """
            UPDATE public.equipment SET
            name = :name, 
            group_id = :group_id,
            description = :description,
            published = :published,
            published_at = :published_at,
            author_of_publish = :author_of_publish,
            version = :version,
            author = :author,
            created_at = :created_at,
            editor = :editor,
            updated_at = :updated_at
            WHERE id = :id
            """.trimIndent(), params
        )
    }

    override fun delete(id: UUID) {
        jdbcTemplate.update(
            "DELETE from public.equipment WHERE id = :id",
            mapOf("id" to id)
        )
    }


    override fun checkEquipmentNameExists(
        equipmentName: EquipmentName,
        companyId: CompanyId,
        equipmentGroupId: String?
    ): Boolean {
        return if (equipmentGroupId != null) {
            jdbcTemplate.query(
                """
                SELECT EXISTS
                ( SELECT 1 FROM public.equipment
                WHERE name = :name
                AND company_id = :company_id
                AND group_id = :group_id );
                """.trimMargin(),
                mapOf(
                    "name" to equipmentName.toStringValue(),
                    "company_id" to companyId.toUUID(),
                    "group_id" to equipmentGroupId
                ),
                ResultSetExtractor {
                    it.next()
                    return@ResultSetExtractor it.getBoolean(1)
                }
            ) ?: false
        } else {
            jdbcTemplate.query(
                """
                SELECT EXISTS
                ( SELECT 1 FROM public.equipment
                WHERE name = :name
                AND company_id = :company_id
                AND group_id isnull );
                """.trimMargin(),
                mapOf("name" to equipmentName.toStringValue(), "company_id" to companyId.toUUID()),
                ResultSetExtractor {
                    it.next()
                    return@ResultSetExtractor it.getBoolean(1)
                }
            ) ?: false
        }
    }
}
