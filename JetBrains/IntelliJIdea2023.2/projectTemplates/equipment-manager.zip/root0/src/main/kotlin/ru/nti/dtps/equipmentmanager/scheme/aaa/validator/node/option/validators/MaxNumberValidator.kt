package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.validators

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionFieldsValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId

class MaxNumberValidator(
    val field: OptionLibId,
    private val maxNumber: Double
) : OptionFieldsValidator {

//    override fun field() = field
    override fun order() = 1000

    override fun validate(options: Map<OptionLibId, String?>): Either<OptionValidationError, Unit> {
        return options[field]?.let {
            Either.catch {
                it.toDouble()
            }
                .mapLeft { return InvalidFiledType(field).left() }
                .map {
                    if (it > maxNumber) {
                        FieldValueMoreThenLimitValueError(
                            field, maxNumber
                        ).left()
                    }
                }
        } ?: Unit.right()
    }
    
}

class FieldValueMoreThenLimitValueError(
    val optionLib: OptionLibId,
    val boundValue: Double
) : OptionValidationError

class InvalidFiledType(val optionLib: OptionLibId) : OptionValidationError
