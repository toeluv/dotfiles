package ru.nti.dtps.equipmentmanager.common.util

import org.slf4j.LoggerFactory
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.http.converter.HttpMessageNotReadableException
import org.springframework.web.HttpMediaTypeNotSupportedException
import org.springframework.web.HttpRequestMethodNotSupportedException
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.servlet.NoHandlerFoundException
import ru.nti.dtps.equipmentmanager.common.auth.UserNotFoundException
import java.util.*

@ControllerAdvice
class GlobalErrorHandler {

    private val logger = LoggerFactory.getLogger(GlobalErrorHandler::class.java)

    @ExceptionHandler(value = [Throwable::class])
    fun handleThrowable(ex: Throwable) =
        logErrorAndBuildResponse(
            throwable = ex,
            status = HttpStatus.INTERNAL_SERVER_ERROR,
            title = "Internal error",
            code = "internal_error"
        )

    @ExceptionHandler(value = [NoHandlerFoundException::class])
    fun handleNotFound() =
        buildError(
            status = HttpStatus.NOT_FOUND,
            title = "Path not found",
            code = "path_not_found"
        )

    @ExceptionHandler(value = [AccessDeniedException::class])
    fun handleAccessDenied() =
        buildError(
            status = HttpStatus.FORBIDDEN,
            title = "Access denied",
            code = "access_denied"
        )

    @ExceptionHandler(value = [HttpRequestMethodNotSupportedException::class])
    fun handleMethodNotSupported(ex: HttpRequestMethodNotSupportedException): ResponseEntity<*> {

        val methods = ex.supportedHttpMethods

        val headers = HttpHeaders()
        if (methods != null) {
            headers.allow = methods
        }

        return buildError(
            status = HttpStatus.METHOD_NOT_ALLOWED,
            title = "Method not allowed",
            code = "method_not_allowed",
            additionalHeaders = headers
        )
    }

    @ExceptionHandler(value = [HttpMediaTypeNotSupportedException::class])
    fun handleMediaTypeUnsupported(ex: HttpMediaTypeNotSupportedException): ResponseEntity<*> {

        val headers = HttpHeaders()
        headers.accept = ex.supportedMediaTypes

        return buildError(
            status = HttpStatus.UNSUPPORTED_MEDIA_TYPE,
            title = "Media type is unsupported",
            code = "media_type_unsupported",
            additionalHeaders = headers
        )
    }

    @ExceptionHandler(value = [HttpMessageNotReadableException::class])
    fun handleNotReadable() =
        buildError(
            status = HttpStatus.BAD_REQUEST,
            title = "Message isn't readable",
            code = "message_not_readable"
        )

    protected fun logErrorAndBuildResponse(
        throwable: Throwable,
        status: HttpStatus,
        title: String,
        code: String,
    ): ResponseEntity<*> {
        val errorId = UUID.randomUUID()
        logger.error("Unexpected exception [#[[\$]]#errorId]", throwable)
        return buildError(
            status = status,
            title = title,
            code = code,
            errorId = errorId
        )
    }

    protected fun buildError(
        status: HttpStatus,
        title: String,
        code: String,
        errorId: UUID? = null,
        additionalHeaders: HttpHeaders? = null,
    ): ResponseEntity<*> {

        val problem = if (errorId != null) {
            Problem(
                status,
                "#[[\$]]#title. Please contact your system administrator with error ID",
                mapOf("errorId" to errorId)
            )

        } else {
            Problem(null, title, null)
        }

        return ResponseEntity
            .status(status)
            .headers(additionalHeaders)
            .contentType(MediaType.APPLICATION_PROBLEM_JSON)
            .body(problem)
    }

    @ExceptionHandler(value = [UserNotFoundException::class])
    fun handleStorageConflict(ex: UserNotFoundException) =
        logErrorAndBuildResponse(
            throwable = ex,
            status = HttpStatus.FORBIDDEN,
            title = "Current user is not presented in DTPS Platform",
            code = "forbidden"
        )

    data class Problem(val status: HttpStatus?, val title: String, val properties: Map<String, Any>?)
}
