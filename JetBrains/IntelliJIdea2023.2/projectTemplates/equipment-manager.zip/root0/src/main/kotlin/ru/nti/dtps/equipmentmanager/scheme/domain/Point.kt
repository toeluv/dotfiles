package ru.nti.dtps.equipmentmanager.scheme.domain

data class Point(
    val id: String,
    val locked: Boolean = false,
    val selected: Boolean = false,
    val coords: XyCoords
)