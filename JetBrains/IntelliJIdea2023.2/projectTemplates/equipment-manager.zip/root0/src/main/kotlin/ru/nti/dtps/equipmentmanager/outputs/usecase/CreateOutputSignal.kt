package ru.nti.dtps.equipmentmanager.outputs.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import ru.nti.dtps.equipmentmanager.outputs.rest.CreateOutputSignalCommand

interface CreateOutputSignal {
    fun execute(command: CreateOutputSignalCommand): Either<CreateOutputSignalUseCaseError, OutputSignal>
}

sealed class CreateOutputSignalUseCaseError {
    class OutputSignalNameAlreadyExistError(val name: String) : CreateOutputSignalUseCaseError()
    class VariableNameAlreadyExistsError(val name: String) : CreateOutputSignalUseCaseError()
}
