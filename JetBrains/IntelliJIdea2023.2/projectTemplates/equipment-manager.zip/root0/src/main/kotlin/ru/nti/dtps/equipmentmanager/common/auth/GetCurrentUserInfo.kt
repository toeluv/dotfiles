package ru.nti.dtps.equipmentmanager.common.auth

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.user.domain.User
import ru.nti.dtps.equipmentmanager.user.persist.adapter.UserExtractor
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserInfoProvider
import ru.nti.dtps.equipmentmanager.user.usecase.access.GetUserIdFromContext
import java.lang.RuntimeException

@Component
class GetCurrentUserInfo(
    private val userExtractor: UserExtractor,
    private val userInfoFromContext: GetUserIdFromContext
) : CurrentUserInfoProvider {
    override fun get(): User {
        val currentUserId = userInfoFromContext.get()
        return userExtractor.getById(currentUserId)
            ?: throw UserNotFoundException("User with id: #[[\$]]#{currentUserId.toStringValue()} is not exists")
    }
}

class UserNotFoundException(override val message: String) : RuntimeException(message)