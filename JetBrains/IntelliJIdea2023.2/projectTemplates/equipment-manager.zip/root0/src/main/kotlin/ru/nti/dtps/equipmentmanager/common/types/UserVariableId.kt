package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError
import java.util.*

data class UserVariableId(
    val id: UUID
) {
    companion object {
        fun from(id: String): Either<InvalidUserVariableIdError, UserVariableId> {
            return Either.catch { UUID.fromString(id) }
                .fold(
                    { InvalidUserVariableIdError.left() },
                    { UserVariableId(it).right() }
                )
        }

        fun from(id: UUID): UserVariableId = UserVariableId(id)
    }

    fun toStringValue() = id.toString()

    fun toUUID() = id
}

object InvalidUserVariableIdError : BusinessError