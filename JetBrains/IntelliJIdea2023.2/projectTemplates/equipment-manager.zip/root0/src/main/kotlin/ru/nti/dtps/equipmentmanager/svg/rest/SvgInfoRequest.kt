package ru.nti.dtps.equipmentmanager.svg.rest

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import org.springframework.web.multipart.MultipartFile
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.domain.Alignment
import ru.nti.dtps.equipmentmanager.svg.domain.*
import java.net.URLConnection
import java.util.*

const val ALLOWED_MAX_COUNT_PLACEHOLDERS = 4
const val ALLOWED_MAX_COUNT_SIGNALS_SHOW_ON_SIMULATION = 20
const val ALLOWED_MAX_SVG_DIMENSIONS_IN_BYTES = 5000

data class SvgInfoRequest(
    val coords: XyCoords,
    val dimensions: Dimensions,
    val hour: Int,
    val ports: List<SvgPortRequest>,
    val placeholders: List<PlaceholderRequest>,
    val commonSignalsInfo: List<SignalInfoRequest>,
    val portSignalsInfo: List<SignalInfoRequest>
) {

    data class SvgPortRequest(
        val id: UUID,
        val libId: String,
        val coords: XyCoords,
        val alignment: Alignment,
        val hour: Int = 0
    )

    data class PlaceholderRequest(
        val id: UUID,
        val coords: XyCoords,
        val hour: Int = 0,
        val signalIds: List<String>
    )

    data class SignalInfoRequest(
        val id: UUID,
        val name: String,
        val dimension: String,
        val dimensionForSimulation: String?,
        val conversionFactor: Double?,
        val numberOfCharacters: Double,
        val showOnSimulation: Boolean,
        val groupId: String,
        val sequence: Int
    )

    private fun SvgPortRequest.toDomain(): Either<SvgInfoRequestValidationError, SvgPort> {
        return SvgPort.create(
            this.id,
            this.libId,
            this.coords,
            this.alignment,
            this.hour
        ).right()
    }

    private fun PlaceholderRequest.toDomain(): Either<SvgInfoRequestValidationError, Placeholder> {
        return Placeholder.create(
            this.id,
            this.coords,
            this.hour,
            this.signalIds.toMutableList()
        ).mapLeft {
            when (it) {
                is PlaceholderError.MaxCountSignalsInPlaceholderError ->
                    SvgInfoRequestValidationError.MaxCountSignalsInPlaceholderError
            }
        }
    }

    private fun SignalInfoRequest.toDomain(): Either<SvgInfoRequestValidationError, SignalInfo> {
        return SignalInfo.create(
            this.id,
            this.name,
            this.dimension,
            this.dimensionForSimulation,
            this.conversionFactor,
            this.numberOfCharacters,
            this.showOnSimulation,
            this.groupId,
            this.sequence
        ).right()
    }

    fun buildCommand(
        id: EquipmentId,
        svg: MultipartFile,
        svgLib: MultipartFile
    ): Either<SvgInfoRequestValidationError, SvgInfo> {
        checkFileIsSvgAndHasRequiredDimensions(svg).mapLeft { error -> return error.left() }
        checkFileIsSvgAndHasRequiredDimensions(svgLib).mapLeft { error -> return error.left() }

        checkPlaceholdersMaxCount(placeholders.size).mapLeft { return it.left() }
        checkSignalsShowOnSimulationMaxCount(
            commonSignalsInfo.filter { it.showOnSimulation }.size
        ).mapLeft { return it.left() }
        checkSignalNotBelongToPlaceholder(placeholders).mapLeft { return it.left() }

        val validPorts = this.ports.map { portRequest ->
           portRequest.toDomain().getOrElse { return it.left() }
        }
        val validPlaceholders = this.placeholders.map { placeholderRequest ->
            placeholderRequest.toDomain().getOrElse { return it.left() }
        }
        val validCommonSignalsInfo = this.commonSignalsInfo.map { signalInfoRequest ->
            signalInfoRequest.toDomain().getOrElse { return it.left() }
        }
        val validPortSignalsInfo = this.portSignalsInfo.map { signalInfoRequest ->
            signalInfoRequest.toDomain().getOrElse { return it.left() }
        }

        return SvgInfo.create(
            id.toUUID(),
            svg.bytes,
            svgLib.bytes,
            this.coords,
            this.dimensions,
            this.hour,
            validPorts,
            validPlaceholders,
            validCommonSignalsInfo,
            validPortSignalsInfo
        ).right()
    }

    private fun checkPlaceholdersMaxCount(placeholdersCount: Int): Either<SvgInfoRequestValidationError, Unit> {
        return if (placeholdersCount > ALLOWED_MAX_COUNT_PLACEHOLDERS) {
           SvgInfoRequestValidationError.MaxCountPlaceholdersError.left()
        } else {
            Unit.right()
        }
    }

    private fun checkSignalsShowOnSimulationMaxCount(
        signalsShowOnSimulationCount: Int
    ): Either<SvgInfoRequestValidationError, Unit> {
        return if (signalsShowOnSimulationCount > ALLOWED_MAX_COUNT_SIGNALS_SHOW_ON_SIMULATION) {
            SvgInfoRequestValidationError.MaxCountSignalsShowOnSimulationError.left()
        } else {
            Unit.right()
        }
    }

    private fun checkSignalNotBelongToPlaceholder(
        placeholders: List<PlaceholderRequest>
    ): Either<SvgInfoRequestValidationError, Unit> {

        val signalsBelongToOtherPlaceholders = placeholders
            .flatMap { it.signalIds }
            .groupingBy { it }
            .eachCount()
            .filter { it.value > 1 }

        return if (signalsBelongToOtherPlaceholders.isNotEmpty()) {
            SvgInfoRequestValidationError.SignalBelongToOtherPlaceholderError.left()
        } else {
            Unit.right()
        }
    }

    private fun checkFileIsSvgAndHasRequiredDimensions(
        svg: MultipartFile
    ): Either<SvgInfoRequestValidationError, Unit>  {
        val fileType = URLConnection.guessContentTypeFromName(svg.originalFilename)
        if (fileType != "image/svg+xml") {
            return SvgInfoRequestValidationError.FileIsNotSvgTypeError.left()
        }
        if (svg.size > ALLOWED_MAX_SVG_DIMENSIONS_IN_BYTES) {
            return SvgInfoRequestValidationError.SvgHasMoreDimensionsThenAllowedError.left()
        }

        return Unit.right()
    }
}

sealed class SvgInfoRequestValidationError {
    object MaxCountPlaceholdersError : SvgInfoRequestValidationError()
    object MaxCountSignalsInPlaceholderError : SvgInfoRequestValidationError()
    object SignalBelongToOtherPlaceholderError : SvgInfoRequestValidationError()
    object MaxCountSignalsShowOnSimulationError : SvgInfoRequestValidationError()
    object FileIsNotSvgTypeError : SvgInfoRequestValidationError()
    object SvgHasMoreDimensionsThenAllowedError : SvgInfoRequestValidationError()
}
