package ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter

import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup

interface EquipmentGroupExtractor {
    fun getAllEquipmentGroupsByCompanyId(companyId: CompanyId): Collection<EquipmentGroup>
    fun getEquipmentGroupById(equipmentGroupId: String): EquipmentGroup?
    fun getEquipmentGroupByIdAndCompanyId(equipmentGroupId: String, companyId: CompanyId): EquipmentGroup?
    fun checkEquipmentGroupAlreadyExists(groupName: String, companyId: CompanyId): Boolean
}