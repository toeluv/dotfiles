package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.ParameterGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.ParameterGroupPersister
import ru.nti.dtps.equipmentmanager.equipment.rest.groups.DeleteParameterGroupCommand
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.DeleteParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.DeleteParameterGroupUseCaseError
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterExtractor
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class DeleteParameterGroupUseCase(
    private val parameterExtractor: ParameterExtractor,
    private val parameterGroupPersister: ParameterGroupPersister,
    private val parameterGroupExtractor: ParameterGroupExtractor,
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider
) : DeleteParameterGroup {
    override fun execute(command: DeleteParameterGroupCommand): Either<DeleteParameterGroupUseCaseError, ParameterGroup> {
        return parameterGroupExtractor.getParameterGroupById(command.id)?.let { groupToDelete ->
            val allParametersByCompany = parameterExtractor.getAllByCompanyId(currentUserCompanyIdProvider.get())

            if (allParametersByCompany.any { it.groupId == groupToDelete.id }) {
                return DeleteParameterGroupUseCaseError.ParameterGroupIsNotEmptyUseCaseError.left()
            }

            parameterGroupPersister.delete(groupToDelete)
            groupToDelete.right()
        } ?: DeleteParameterGroupUseCaseError.ParameterGroupNotExistUseCaseError.left()
    }
}
