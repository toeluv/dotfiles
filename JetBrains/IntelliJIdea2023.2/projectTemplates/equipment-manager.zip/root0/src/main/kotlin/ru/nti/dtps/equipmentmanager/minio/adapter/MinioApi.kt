package ru.nti.dtps.equipmentmanager.minio.adapter

import arrow.core.Either

interface MinioApi {
    fun createBucket(bucketName: String): Either<MinioAdapterError, Unit>
    fun uploadFile(bucketName: String, uploadData: SchemeFile): Either<MinioAdapterError, SchemeFileInfo>
    fun uploadFileFromSourceFolder(bucketName: String, fileName: String): Either<MinioAdapterError, SchemeFileInfo>
    fun deleteFile(bucketName: String, fileName: String): Either<MinioAdapterError, Unit>
    fun downloadFileToSourceFolder(bucketName: String, fileName: String): Either<MinioAdapterError, Unit>
    fun downloadFile(bucketName: String, fileName: String): Either<MinioAdapterError, SchemeFile>

}

sealed class MinioAdapterError {
    object MinioAdapterCreateBucketError : MinioAdapterError()
    object MinioAdapterUploadFileError : MinioAdapterError()
    object MinioAdapterDeleteFileError : MinioAdapterError()
    object MinioAdapterDownloadFileError : MinioAdapterError()
}

class SchemeFile(
    val name: String,
    val contentType: String,
    val content: ByteArray
)

class SchemeFileInfo(
    val name: String,
    val bucketName: String,
    val tag: String?,
    val versionId: String?
)
