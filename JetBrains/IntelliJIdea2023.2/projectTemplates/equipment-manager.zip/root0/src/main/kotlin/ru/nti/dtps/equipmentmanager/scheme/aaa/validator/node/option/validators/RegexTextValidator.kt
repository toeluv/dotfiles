package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.validators

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionFieldsValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId
import java.util.regex.Pattern

class RegexTextValidator(
    val field: OptionLibId,
    regex: String
) : OptionFieldsValidator {
    private val pattern = Pattern.compile(regex)

//    override fun field() = field
    override fun order() = 1000

    override fun validate(options: Map<OptionLibId, String?>): Either<OptionValidationError, Unit> {
        return options[field]?.let {
            Either.catch {
                pattern.matcher(it).matches()
            }
                .fold(
                    { return InvalidFieldFormat(field).left() },
                    { Unit.right() }
                )
        } ?: Unit.right()
    }
}


class InvalidFieldFormat(
    val optionLib: OptionLibId
) : OptionValidationError
