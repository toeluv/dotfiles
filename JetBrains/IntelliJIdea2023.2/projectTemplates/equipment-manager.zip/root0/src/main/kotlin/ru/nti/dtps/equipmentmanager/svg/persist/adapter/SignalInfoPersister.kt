package ru.nti.dtps.equipmentmanager.svg.persist.adapter

import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SignalInfoDto
import java.util.UUID

interface SignalInfoPersister {
    fun save(signalInfoDto: SignalInfoDto)
    fun update(signalInfoDto: SignalInfoDto)
    fun updateSignalsFromScheme(id: UUID, signalsFromScheme: List<SignalInfo>)
    fun updateSignalsFromMeasurements(id: UUID, signalsFromMeasurements: List<SignalInfo>)
    fun delete(id: UUID)
}