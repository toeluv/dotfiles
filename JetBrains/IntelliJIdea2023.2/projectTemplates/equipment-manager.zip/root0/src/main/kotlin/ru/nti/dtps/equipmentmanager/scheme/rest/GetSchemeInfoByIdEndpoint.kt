package ru.nti.dtps.equipmentmanager.scheme.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipmentLink
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.common.util.API_V1_SCHEME_INFO
import ru.nti.dtps.equipmentmanager.common.util.GlobalErrorHandler

@RestController
class GetSchemeInfoByIdEndpoint(
    private val schemeExtractor: SchemeExtractor,
    private val messageSource: MessageSourceService
) {

    @Operation(summary = "Get scheme info by equipment id")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Get scheme info success", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = SchemeShortView::class)
                    ))]
            ),
            ApiResponse(responseCode = "400", description = "Unsupported request fields",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "404", description = "Scheme info not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "500", description = "Something went wrong, go to admin",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                ))])
        ]
    )
    @GetMapping("#[[\$]]#API_V1_SCHEME_INFO/{equipmentId}")
    fun getSchemeInfo(
        @PathVariable equipmentId: String
    ): ResponseEntity<*> {

        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    schemeExtractor
                        .getById(validEquipmentId.toUUID())
                        ?.let { scheme ->
                            ok(scheme.toView())
                        }
                        ?: restBusinessError(
                            messageSource.getMessage("api.scheme.error.not-found"),
                            HttpStatus.NOT_FOUND
                        )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )
}

private fun Scheme.toView() =
    SchemeShortView(
        this.id.toStringValue(),
        this.primitiveNodes,
        this.links,
        this.isValid
    )

data class SchemeShortView(
    val id: String,
    val primitiveNodes: MutableMap<String, PrimitiveEquipment>,
    val links: MutableMap<String, PrimitiveEquipmentLink>,
    var isValid: Boolean
)