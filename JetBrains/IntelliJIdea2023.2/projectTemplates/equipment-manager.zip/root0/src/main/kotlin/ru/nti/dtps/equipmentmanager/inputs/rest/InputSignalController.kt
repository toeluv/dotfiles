package ru.nti.dtps.equipmentmanager.inputs.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.ArraySchema
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import ru.nti.dtps.equipmentmanager.inputs.usecase.*

@RestController
class InputSignalController(
    private val messageSource: MessageSourceService,
    private val createInputSignal: CreateInputSignal,
    private val updateInputSignal: UpdateInputSignal,
    private val deleteInputSignal: DeleteInputSignal,
    private val getAllInputSignalsByEquipment: GetAllInputSignalsByEquipment
) {

    @Operation(summary = "Execute get all input signals command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "All input signals are found", content = [
                    (Content(
                        mediaType = "application/json",
                        array = ArraySchema(schema = Schema(implementation = InputSignalView::class))
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @GetMapping("#[[\$]]#API_V1_EQUIPMENT_INPUTS/{equipmentId}")
    fun getAllByEquipment(
        @PathVariable equipmentId: String
    ): ResponseEntity<*> {
        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    ok(
                        getAllInputSignalsByEquipment.execute(validEquipmentId).map { it.toView() }
                    )
                }
            )
    }

    @Operation(summary = "Execute create input signal command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Input signal was created", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = InputSignalView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409",
                description = "Variable name has not unique value",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PostMapping("#[[\$]]#API_V1_EQUIPMENT_INPUTS/{equipmentId}")
    fun createInputSignal(
        @PathVariable equipmentId: String,
        @RequestBody request: CreateInputSignalRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    createInputSignal.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { inputSignal -> ok(inputSignal.toView()) }
                        )
                }
            )
    }

    @Operation(summary = "Execute update input signal variable command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Input signal was updated", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = InputSignalView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409", description = "Variable name has not unique value", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Input signal not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PutMapping("#[[\$]]#API_V1_EQUIPMENT_INPUTS/{equipmentId}")
    fun updateInputSignal(
        @PathVariable equipmentId: String,
        @RequestBody request: UpdateInputSignalRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    updateInputSignal.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { inputSignal -> ok(inputSignal.toView()) }
                        )
                }
            )
    }

    @Operation(summary = "Execute delete input signal command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Input signal was deleted", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = Unit::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Input signal not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @DeleteMapping("#[[\$]]#API_V1_EQUIPMENT_OUTPUTS/{equipmentId}")
    fun deleteInputSignal(
        @PathVariable equipmentId: String,
        @RequestBody request: DeleteInputSignalRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    deleteInputSignal.execute(it).fold(
                        { error -> error.toRestError() },
                        { unit -> ok(unit) }
                    )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun CreateInputSignalUseCaseError.toRestError() =
        when (this) {
            is CreateInputSignalUseCaseError.VariableNameAlreadyExistsError ->
                restBusinessError(
                    messageSource.getMessage("api.variable.error.validation.twins").format(name),
                    HttpStatus.CONFLICT
                )

            is CreateInputSignalUseCaseError.InputSignalNameAlreadyExistError ->
                restBusinessError(
                    messageSource.getMessage("api.input.signal.error.validation.twins").format(name),
                    HttpStatus.CONFLICT
                )
        }

    private fun UpdateInputSignalUseCaseError.toRestError() =
        when (this) {
            is UpdateInputSignalUseCaseError.VariableNameAlreadyExistsError ->
                restBusinessError(
                    messageSource.getMessage("api.variable.error.validation.twins").format(name),
                    HttpStatus.CONFLICT
                )

            is UpdateInputSignalUseCaseError.InputSignalNotFoundError ->
                restBusinessError(
                    messageSource.getMessage("api.input.signal.error.not-found"),
                    HttpStatus.NOT_FOUND
                )

            is UpdateInputSignalUseCaseError.InputSignalNameAlreadyExistError ->
                restBusinessError(
                    messageSource.getMessage("api.input.signal.error.validation.twins").format(name),
                    HttpStatus.CONFLICT
                )
        }

    private fun DeleteInputSignalUseCaseError.toRestError() =
        when (this) {
            is DeleteInputSignalUseCaseError.InputSignalNotFoundError ->
                restBusinessError(
                    messageSource.getMessage("api.input.signal.error.not-found"),
                    HttpStatus.NOT_FOUND
                )
        }
}

data class InputSignalView(
    val id: String,
    val equipmentId: String,
    val name: String,
    val unitType: String,
    val dataType: String,
    val variableName: String
)

private fun InputSignal.toView() = InputSignalView(
    this.id.toStringValue(),
    this.equipmentId.toStringValue(),
    this.name.toStringValue(),
    this.unitType.name,
    this.dataType.name,
    this.variableName.name
)
