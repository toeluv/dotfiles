package ru.nti.dtps.equipmentmanager.cplus.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.cplus.docker.domain.BuildResult

interface BuildEquipmentCpp {
    fun execute(equipmentId: EquipmentId): Either<BuildEquipmentCppUseCaseError, EquipmentBuildInfo>
}

data class EquipmentBuildInfo(
    val equipmentId: String,
    val logs: String,
    val result: BuildResult
)

sealed class BuildEquipmentCppUseCaseError : UseCaseError {
    object EquipmentNotExistUseCaseError : BuildEquipmentCppUseCaseError()
    object SchemeNotExistUseCaseError : BuildEquipmentCppUseCaseError()
    object CreateDockerContainerUseCaseError : BuildEquipmentCppUseCaseError()
    object StartDockerContainerUseCaseError : BuildEquipmentCppUseCaseError()
    object GetDockerContainerLogsUseCaseError : BuildEquipmentCppUseCaseError()
}