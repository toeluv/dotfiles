package ru.nti.dtps.equipmentmanager.scheme.domain

enum class OptionValueType { NUMBER, MUTUALITY_SELECT, TEXT }