package ru.nti.dtps.equipmentmanager.minio.configuration

import org.springframework.context.annotation.Configuration
import org.springframework.util.Assert

@Configuration
class MinioHttpClientConfiguration(
    private val minioClientProperties: MinioClientProperties
) {

    init {
        Assert.isTrue(
            minioClientProperties.host.isNotBlank(),
            "Minio client properties must not be blank"
        )
        Assert.isTrue(
            minioClientProperties.username.isNotBlank() &&
                    minioClientProperties.password.isNotBlank(),
            "Minio client properties connection to stand need username and password"
        )
    }

/*
*   currently disabled
*
    @Bean
    @Profile(value = [PROFILE_LOCAL, PROFILE_DEV, PROFILE_PROD])
    fun createMinioClient(): MinioClient {
        return MinioClient.builder()
            .endpoint(minioClientProperties.host)
            .credentials(minioClientProperties.username, minioClientProperties.password)
            .build()
    }
*/
}
