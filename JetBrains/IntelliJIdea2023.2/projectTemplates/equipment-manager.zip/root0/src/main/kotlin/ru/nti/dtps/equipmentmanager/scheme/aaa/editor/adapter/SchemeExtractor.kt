package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.Scheme

interface SchemeExtractor {
    fun extract(id: EquipmentId): Scheme?
}