package ru.nti.dtps.equipmentmanager.outputs.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.OutputSignalId
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal

interface OutputSignalPersister {
    fun save(outputSignal: OutputSignal)
    fun update(outputSignal: OutputSignal)
    fun delete(id: OutputSignalId)
    fun deleteAllByEquipmentId(equipmentId: EquipmentId)
}