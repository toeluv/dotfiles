package ru.nti.dtps.equipmentmanager.scheme.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.command.SchemeValidateCommand
import ru.nti.dtps.equipmentmanager.scheme.domain.isPrimitivePort
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoExtractor
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.ComplexSchemeValidator
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemePersister
import ru.nti.dtps.equipmentmanager.scheme.usecase.ValidateScheme
import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SignalInfoPersister

@Component
class ValidateSchemeUseCase(
    private val schemeExtractor: SchemeExtractor,
    private val schemePersister: SchemePersister,
    private val complexSchemeValidator: ComplexSchemeValidator,
    private val signalInfoPersister: SignalInfoPersister,
    private val libInfoExtractor: LibInfoExtractor
) : ValidateScheme {
    override fun execute(command: SchemeValidateCommand): Either<SchemeValidationError, Unit> {
        return schemeExtractor
            .getById(command.id.toUUID())
            ?.let { scheme ->
                scheme.validate(complexSchemeValidator)
                    .fold(
                        { it.left() },
                        {
                            val signalsInfoFromScheme = scheme.primitiveNodes.values
                                .filter {
                                    it.type.isPrimitivePort()
                                }.flatMap {
                                    SignalInfo.buildSignalsForPrimitivePort(it.id, libInfoExtractor)
                                }

                            schemePersister.update(scheme)
                            signalInfoPersister.updateSignalsFromScheme(
                                scheme.id.toUUID(),
                                signalsInfoFromScheme
                            ).right()
                        }
                    )
            } ?: ValidateSchemeUseCaseError.SchemeNotFoundError(command.id.toStringValue()).left()
    }
}

sealed class ValidateSchemeUseCaseError : SchemeValidationError {
    class SchemeNotFoundError(val id: String) : ValidateSchemeUseCaseError()
}