package ru.nti.dtps.equipmentmanager.userVariable.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable
import ru.nti.dtps.equipmentmanager.userVariable.rest.CreateUserVariableCommand

interface CreateUserVariable {
    fun execute(command: CreateUserVariableCommand): Either<CreateUserVariableUseCaseError, UserVariable>
}

sealed class CreateUserVariableUseCaseError {
    class VariableNameAlreadyExistsError(val value: String) : CreateUserVariableUseCaseError()
}