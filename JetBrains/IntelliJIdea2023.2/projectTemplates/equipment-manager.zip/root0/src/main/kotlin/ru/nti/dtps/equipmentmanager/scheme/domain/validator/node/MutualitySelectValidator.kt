package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node

import org.springframework.stereotype.Component
import ru.nti.dtps.equipment.meta.info.dataclass.common.Language
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.FieldType
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.OptionLib
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.MutualitySelect

@Component
class MutualitySelectValidator : MutualitySelect {
    override fun validate(
        optionValueString: String,
        optionLib: OptionLib,
        fieldType: FieldType,
        equipment: PrimitiveEquipment
    ) {
        if (fieldType.options.isNotEmpty() && !fieldType.options.any { option -> option.key == optionValueString }) {
            throw IllegalArgumentException(
                "Equipment #[[\$]]#{equipment.name} (#[[\$]]#{equipment.type}) has field #[[\$]]#{optionLib.name[Language.RU.name]} " +
                    "with value #[[\$]]#optionValueString, but expected #[[\$]]#{fieldType.options.map { it.key }}"
            )
        }
    }
}