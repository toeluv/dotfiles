package ru.nti.dtps.equipmentmanager.equipment.usecase

import ru.nti.dtps.equipmentmanager.common.types.EquipmentName

fun interface EquipmentNameAlreadyExists {
    operator fun invoke(
        equipmentName: EquipmentName,
        equipmentGroupId: String?
    ): Boolean
}