package ru.nti.dtps.equipmentmanager.outputs.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.OutputSignalId
import ru.nti.dtps.equipmentmanager.common.types.OutputSignalName

interface OutputSignalNameAlreadyExists {
    operator fun invoke(name: OutputSignalName, equipmentId: EquipmentId): Boolean
    operator fun invoke(id: OutputSignalId, name: OutputSignalName, equipmentId: EquipmentId): Boolean
}