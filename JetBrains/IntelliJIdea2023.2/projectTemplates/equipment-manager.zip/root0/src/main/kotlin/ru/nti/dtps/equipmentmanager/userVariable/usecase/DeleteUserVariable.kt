package ru.nti.dtps.equipmentmanager.userVariable.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.userVariable.rest.DeleteUserVariableCommand

interface DeleteUserVariable {
    fun execute(command: DeleteUserVariableCommand): Either<DeleteUserVariableUseCaseError, Unit>
}

sealed class DeleteUserVariableUseCaseError{
    object UserVariableNotFoundError: DeleteUserVariableUseCaseError()
}