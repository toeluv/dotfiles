package ru.nti.dtps.equipmentmanager.equipment.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.equipment.rest.request.DeleteEquipmentRequest
import ru.nti.dtps.equipmentmanager.equipment.usecase.DeleteEquipment
import ru.nti.dtps.equipmentmanager.equipment.usecase.DeleteEquipmentUseCaseError

@RestController
class DeleteEquipmentEndpoint(
    private val deleteEquipment: DeleteEquipment,
    private val messageSource: MessageSourceService
) {
    @Operation(summary = "Delete existing equipment")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Equipment deleted", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = EquipmentShortView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Invalid equipment id", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Equipment was not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )]
    )
    @DeleteMapping(API_V1_EQUIPMENT)
    fun delete(@RequestBody deleteEquipmentRequest: DeleteEquipmentRequest): ResponseEntity<*> {
        return deleteEquipmentRequest.buildCommand()
            .fold(
                { it.toRestError() },
                { 
                    deleteEquipment.execute(it)
                        .fold(
                            { useCaseError -> useCaseError.toRestError() },
                            { equipment -> ok(equipment.toShortView()) }
                        )
                })
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun DeleteEquipmentUseCaseError.toRestError() =
        when (this) {
            is DeleteEquipmentUseCaseError.EquipmentNotFoundUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.equipment.error.not-found"),
                    HttpStatus.NOT_FOUND
                )
        }
}
