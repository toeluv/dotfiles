package ru.nti.dtps.equipmentmanager.svg.persist

import arrow.core.getOrElse
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SignalInfoDto
import java.sql.ResultSet

class SignalInfoResultSetExtractor : ResultSetExtractor<SignalInfoDto> {
    override fun extractData(rs: ResultSet): SignalInfoDto? {
        return if (rs.next()) {
            SignalInfoRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class SignalInfoRowMapper : RowMapper<SignalInfoDto> {
    private val objectMapper = jacksonObjectMapper()

    private val logger = LoggerFactory.getLogger(SignalInfoRowMapper::class.java)
    override fun mapRow(rs: ResultSet, rowNum: Int): SignalInfoDto? {
        val id = rs.getString("id")
        val signalsFromMeas = objectMapper.readValue<List<SignalInfo>>(rs.getString("signals_from_meas"))
        val signalsFromScheme = objectMapper.readValue<List<SignalInfo>>(rs.getString("signals_from_scheme"))

        return SignalInfoDto.restore(
            id = EquipmentId.from(id).getOrElse {
                logger.error("Incorrect equipment id #[[\$]]#id")
                return null
            }.id,
            signalsFromMeas,
            signalsFromScheme
        )
    }
}