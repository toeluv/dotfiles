package ru.nti.dtps.equipmentmanager.user.domain.command

import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.UserId

interface UserCommand

class CreateUserCommand(
    val userId: UserId,
    val companyId: CompanyId,
    val firstName: String,
    val lastName: String
) : UserCommand

class UpdatedUserCommand(
    val userId: UserId,
    val companyId: CompanyId,
    val firstName: String,
    val lastName: String
) : UserCommand

class DeleteUserCommand(
    val userId: UserId
) : UserCommand
