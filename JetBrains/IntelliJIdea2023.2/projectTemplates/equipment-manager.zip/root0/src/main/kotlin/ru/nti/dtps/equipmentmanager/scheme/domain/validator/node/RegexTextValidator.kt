package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node

import arrow.core.Either
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipment.meta.info.dataclass.common.Language
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.FieldType
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.OptionLib
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.TextValidator
import java.util.regex.Pattern

@Component
class RegexTextValidator : TextValidator {
    override fun validate(
        optionValueString: String,
        optionLib: OptionLib,
        fieldType: FieldType,
        equipment: PrimitiveEquipment
    ): Either<SchemeValidationError, Unit> {
        if (fieldType.regex != null && !Pattern.compile(fieldType.regex).matcher(optionValueString).matches()) {
            throw IllegalArgumentException(
                "Equipment #[[\$]]#{equipment.name} (#[[\$]]#{equipment.type}) has field #[[\$]]#{optionLib.name[Language.RU.name]} " +
                    "with value #[[\$]]#optionValueString that doesn't match pattern: #[[\$]]#{fieldType.regex}}"
            )
        }

        return Unit.right()
    }
}