package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.Scheme

interface SchemePersister {
    fun persist(scheme: Scheme)
    fun remove(equipmentId: EquipmentId)
}