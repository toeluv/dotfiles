package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.util.ValidationError
import ru.nti.dtps.equipmentmanager.svg.rest.SvgInfoRequestValidationError

fun EquipmentId.Companion.validated(id: String): Either<ValidationError, EquipmentId> {
    return from(id).mapLeft {
        ValidationError(errorCode = "api.equipment.error.id.invalid")
    }
}

fun EquipmentName.Companion.validated(name: String): Either<ValidationError, EquipmentName> {
    return from(name).mapLeft {
        when (it) {
            is CreateEquipmentNameError.EmptyEquipmentName,
            -> ValidationError(errorCode = "api.equipment.error.name.is-blank")
        }
    }
}

fun InputSignalId.Companion.validated(id: String): Either<ValidationError, InputSignalId> {
    return from(id).mapLeft {
        ValidationError(errorCode = "api.input.signal.error.id.invalid")
    }
}

fun InputSignalName.Companion.validated(name: String): Either<ValidationError, InputSignalName> {
    return from(name).mapLeft {
        when (it) {
            is CreateInputSignalNameError.EmptyInputSignalName
            -> ValidationError(errorCode = "api.input.signal.error.name.is-blank")
        }
    }
}

fun ParameterId.Companion.validated(id: String): Either<ValidationError, ParameterId> {
    return from(id).mapLeft {
        ValidationError(errorCode = "api.parameter.error.id.invalid")
    }
}

fun ParameterName.Companion.validated(name: String): Either<ValidationError, ParameterName> {
    return from(name).mapLeft {
        when (it) {
            is CreateParameterNameError.EmptyParameterName
            -> ValidationError(errorCode = "api.parameter.error.name.is-blank")
        }
    }
}

fun OutputSignalId.Companion.validated(id: String): Either<ValidationError, OutputSignalId> {
    return from(id).mapLeft {
        ValidationError(errorCode = "api.output.signal.error.id.invalid")
    }
}

fun OutputSignalName.Companion.validated(name: String): Either<ValidationError, OutputSignalName> {
    return from(name).mapLeft {
        when (it) {
            is CreateOutputSignalNameError.EmptyOutputSignalName,
            -> ValidationError(errorCode = "api.output.signal.error.name.is-blank")
        }
    }
}

fun VariableName.Companion.validated(name: String): Either<ValidationError, VariableName> {
    return from(name).mapLeft {
        when (it) {
            is CreateVariableNameError.EmptyVariableName,
            -> ValidationError(errorCode = "api.variable.error.name.is-blank")
        }
    }
}

fun UserId.Companion.validated(id: String): Either<ValidationError, UserId> {
    return from(id).mapLeft {
        ValidationError(errorCode = "api.user.error.id.invalid")
    }
}

fun CompanyId.Companion.validated(id: String): Either<ValidationError, CompanyId> {
    return from(id).mapLeft {
        ValidationError(errorCode = "api.company.error.id.invalid")
    }
}

fun UserVariableId.Companion.validated(id: String): Either<ValidationError, UserVariableId> {
    return from(id).mapLeft {
        ValidationError(errorCode = "api.user-variable.error.id.invalid")
    }
}

fun SvgInfoRequestValidationError.toValidationError(): ValidationError {
    return when (this) {
        is SvgInfoRequestValidationError.MaxCountSignalsInPlaceholderError ->
            ValidationError(errorCode = "api.svg.error.signals.in.placeholder.max-count")

        is SvgInfoRequestValidationError.MaxCountPlaceholdersError ->
            ValidationError(errorCode = "api.svg.error.placeholder.max-count")

        is SvgInfoRequestValidationError.SignalBelongToOtherPlaceholderError ->
            ValidationError(errorCode = "api.svg.error.signal.belong.to.other.placeholder")

        is SvgInfoRequestValidationError.MaxCountSignalsShowOnSimulationError ->
            ValidationError(errorCode = "api.svg.error.signals.show.on.simulation.max-count")

        is SvgInfoRequestValidationError.FileIsNotSvgTypeError ->
            ValidationError(errorCode = "api.svg.error.format")

        is SvgInfoRequestValidationError.SvgHasMoreDimensionsThenAllowedError ->
            ValidationError(errorCode = "api.svg.error.dimensions")
    }
}
