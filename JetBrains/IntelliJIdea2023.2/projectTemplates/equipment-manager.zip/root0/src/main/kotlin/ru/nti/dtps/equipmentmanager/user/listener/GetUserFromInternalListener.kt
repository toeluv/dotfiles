package ru.nti.dtps.equipmentmanager.user.listener

import org.slf4j.LoggerFactory
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.boot.context.event.ApplicationStartedEvent
import org.springframework.context.event.EventListener
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.configuration.client.IntegrationPlatformClient
import ru.nti.dtps.equipmentmanager.common.configuration.client.UserDto
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.UserId
import ru.nti.dtps.equipmentmanager.user.persist.adapter.UserPersister
import ru.nti.dtps.equipmentmanager.user.domain.User

@ConditionalOnProperty(
    name = ["internal.client-enable"],
    havingValue = "true"
)
@Component
class GetUserFromInternalListener(
    private val client: IntegrationPlatformClient,
    private val userPersister: UserPersister
) {

    private val logger = LoggerFactory.getLogger(GetUserFromInternalListener::class.java)

    @EventListener(ApplicationStartedEvent::class)
    fun retrieve() {
        client
            .getAllUsers()
            .map { it.mapToDomain() }
            .also { userPersister.saveUsersIfNotExist(it) }
        logger.info("Successfully saved users from integration platform")
    }

    private fun UserDto.mapToDomain() =
        User.create(
            UserId.from(this.keycloakUserId),
            CompanyId.from(this.companyId),
            firstName,
            lastName
        )
}