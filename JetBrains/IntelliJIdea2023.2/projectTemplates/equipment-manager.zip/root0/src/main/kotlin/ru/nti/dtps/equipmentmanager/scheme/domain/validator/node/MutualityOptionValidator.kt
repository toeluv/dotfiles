package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.*
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.CustomValidator

@Component
class MutualityOptionValidator : CustomValidator {
    override fun validate(
        node: PrimitiveEquipment,
        scheme: Scheme
    ): Either<SchemeEditorError, Unit> {
        val siblings = scheme.primitiveNodes.values.filter {
            it.type == node.type && it.id != node.id
        }
        return node.options[OptionLibId.MUTUALITY]
            ?.split(",")
            ?.let { mutualityIds ->
                mutualityIds.forEach { mutualityId ->
                    val branch = scheme.mutualBranches.find { it.id == mutualityId }
                        ?: return SchemeEditorError.MutualityOptionIsNotValidError(node.id, node.name).left()
                    if (!siblings.map { it.id }.contains(mutualityId)
                        || !scheme.mutualBranches.map { it.id }.contains(mutualityId)
                        || node.type != branch.elementType
                    ) {
                        return SchemeEditorError.MutualityOptionIsNotValidError(node.id, node.name).left()
                    }
                }
                return Unit.right()
            } ?: Unit.right()
    }
}