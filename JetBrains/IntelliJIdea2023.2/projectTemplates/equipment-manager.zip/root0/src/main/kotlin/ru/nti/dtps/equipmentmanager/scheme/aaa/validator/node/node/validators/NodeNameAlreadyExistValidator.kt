package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.validators

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.invariant.NodeNameAlreadyExists
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.BusinessNodeValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeToValidate
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId
import java.util.*

@Component
class NodeNameAlreadyExistValidator(
    val nodeNameAlreadyExists: NodeNameAlreadyExists
) : BusinessNodeValidator {

    private val variableNameKeySelector = OptionLibId.VARIABLE_NAME

    override fun order() = 0

    override fun validate(node: NodeToValidate): Either<NodeValidationError, Unit> {
        node.options()[variableNameKeySelector]?.let { nodeName ->
            if (nodeNameAlreadyExists(node.id(), node.equipmentId(), nodeName )) {
                return NodeNameAlreadyExistValidationError(
                    node.id(), node.equipmentId(), nodeName
                ).left()
            }
        }
        return Unit.right()
    }

}

data class NodeNameAlreadyExistValidationError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val nodeName: String
) : NodeValidationError