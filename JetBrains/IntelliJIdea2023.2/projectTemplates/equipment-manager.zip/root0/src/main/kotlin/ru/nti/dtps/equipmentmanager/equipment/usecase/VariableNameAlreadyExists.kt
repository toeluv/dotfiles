package ru.nti.dtps.equipmentmanager.equipment.usecase

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import java.util.*

interface VariableNameAlreadyExists {
    operator fun invoke(variableName: VariableName, equipmentId: EquipmentId): Boolean
    operator fun invoke(variableName: VariableName, equipmentId: EquipmentId, excludedId: UUID): Boolean
}