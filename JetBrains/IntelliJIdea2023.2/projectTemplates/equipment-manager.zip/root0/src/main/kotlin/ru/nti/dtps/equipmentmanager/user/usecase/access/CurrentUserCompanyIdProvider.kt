package ru.nti.dtps.equipmentmanager.user.usecase.access

import ru.nti.dtps.equipmentmanager.common.types.CompanyId

interface CurrentUserCompanyIdProvider {
    fun get(): CompanyId
}