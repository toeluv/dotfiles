package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.scheme

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Service
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme

/**
 * Validators throw IllegalArgumentException if there is scheme error, that user can't fix.
 * So these types of errors relates to developers.
 */
@Service
class ValidatorService(
    schemeValidators: List<SchemeValidator>
) : ComplexSchemeValidator {
    private val schemeValidators: List<SchemeValidator> = schemeValidators.sortedBy {
        it.getLevelNumber()
    }

    override fun validate(scheme: Scheme): Either<SchemeValidationError, Unit> {
        schemeValidators.forEach { it.validate(scheme).mapLeft { error -> return error.left() } }
        return Unit.right()
    }
}
