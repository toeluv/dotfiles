package ru.nti.dtps.equipmentmanager.svg.persist

import arrow.core.getOrElse
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.svg.domain.Dimensions
import ru.nti.dtps.equipmentmanager.svg.domain.Placeholder
import ru.nti.dtps.equipmentmanager.svg.domain.SvgPort
import ru.nti.dtps.equipmentmanager.svg.domain.XyCoords
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgInfoDto
import java.sql.ResultSet

class SvgInfoResultSetExtractor : ResultSetExtractor<SvgInfoDto> {
    override fun extractData(rs: ResultSet): SvgInfoDto? {
        return if (rs.next()) {
            SvgInfoRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class SvgInfoRowMapper : RowMapper<SvgInfoDto> {
    private val objectMapper = jacksonObjectMapper()

    private val logger = LoggerFactory.getLogger(SvgInfoRowMapper::class.java)
    override fun mapRow(rs: ResultSet, rowNum: Int): SvgInfoDto? {
        val id = rs.getString("id")
        val coords = objectMapper.readValue<XyCoords>(rs.getString("coords"))
        val dimensions = objectMapper.readValue<Dimensions>(rs.getString("dimensions"))
        val hour = rs.getInt("hour")
        val ports = objectMapper.readValue<List<SvgPort>>(rs.getString("ports"))
        val placeholders = objectMapper.readValue<List<Placeholder>>(rs.getString("placeholders"))

        return SvgInfoDto.restore(
            id = EquipmentId.from(id).getOrElse {
                logger.error("Incorrect equipment id #[[\$]]#id")
                return null
            }.id,
            coords,
            dimensions,
            hour,
            ports,
            placeholders
        )
    }
}