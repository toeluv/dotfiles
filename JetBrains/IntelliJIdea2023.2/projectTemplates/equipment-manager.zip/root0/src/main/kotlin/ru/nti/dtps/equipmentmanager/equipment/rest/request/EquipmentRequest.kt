package ru.nti.dtps.equipmentmanager.equipment.rest.request

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.util.ValidationError
import ru.nti.dtps.equipmentmanager.equipment.domain.command.CreateEquipmentCommand
import ru.nti.dtps.equipmentmanager.equipment.domain.command.DeleteEquipmentCommand
import ru.nti.dtps.equipmentmanager.equipment.domain.command.UpdateEquipmentCommand

data class CreateEquipmentRequest(
    val id: String,
    val name: String,
    val groupId: String?,
    val description: String?
) {
    fun buildCommand(
    ): Either<ValidationError, CreateEquipmentCommand> {
        val equipmentId = EquipmentId.validated(this.id).getOrElse { return it.left() }
        val name = EquipmentName.validated(this.name).getOrElse { return it.left() }
        return CreateEquipmentCommand(
            equipmentId,
            name,
            groupId,
            description,
        ).right()
    }
}

data class UpdateEquipmentRequest(
    val id: String,
    val name: String,
    val groupId: String?,
    val description: String?,
) {
    fun buildCommand(
    ): Either<ValidationError, UpdateEquipmentCommand> {
        val equipmentId = EquipmentId.validated(this.id).getOrElse { return it.left() }
        val name = EquipmentName.validated(this.name).getOrElse { return it.left() }
        return UpdateEquipmentCommand(
            equipmentId,
            name,
            groupId,
            description,
        ).right()
    }
}

data class DeleteEquipmentRequest(
    val id: String
) {
    fun buildCommand(
    ): Either<ValidationError, DeleteEquipmentCommand> {
        val equipmentId = EquipmentId.validated(this.id).getOrElse { return it.left() }
        return DeleteEquipmentCommand(
            equipmentId
        ).right()
    }
}
