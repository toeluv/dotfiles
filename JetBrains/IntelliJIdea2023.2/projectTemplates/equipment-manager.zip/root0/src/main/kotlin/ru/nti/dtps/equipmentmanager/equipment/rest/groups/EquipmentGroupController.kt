package ru.nti.dtps.equipmentmanager.equipment.rest.groups

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.ArraySchema
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import ru.nti.dtps.equipmentmanager.common.util.BusinessError
import ru.nti.dtps.equipmentmanager.common.util.MessageSourceService
import ru.nti.dtps.equipmentmanager.common.util.ok
import ru.nti.dtps.equipmentmanager.common.util.restBusinessError
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup
import ru.nti.dtps.equipmentmanager.common.util.API_V1_EQUIPMENT_GROUP
import ru.nti.dtps.equipmentmanager.common.util.GlobalErrorHandler
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.*

@RestController
class EquipmentGroupController(
    private val getAllGroups: GetAllEquipmentGroups,
    private val createGroup: CreateEquipmentGroup,
    private val getGroupById: GetEquipmentGroupById,
    private val deleteGroup: DeleteEquipmentGroup,
    private val messageSource: MessageSourceService
) {
    @Operation(summary = "Get all equipment groups")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Get all equipment groups request success", content = [
                    (Content(
                        mediaType = "application/json",
                        array = ArraySchema(schema = Schema(implementation = EquipmentGroupShortView::class))
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )]
    )
    @GetMapping(API_V1_EQUIPMENT_GROUP)
    fun getAll(): ResponseEntity<*> {
        return getAllGroups.execute()
            .map { it.toShortView() }
            .let { ok(it) }
    }

    @Operation(summary = "Create new equipment group")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Equipment group created", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = EquipmentGroupShortView::class)
                    ))]
            ),
            ApiResponse(responseCode = "400", description = "Unsupported request fields"),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(responseCode = "409", description = "Equipment group with current name is already exist"),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )]
    )
    @PostMapping(API_V1_EQUIPMENT_GROUP)
    fun create(@RequestBody command: CreateEquipmentGroupCommand): ResponseEntity<*> {
        return createGroup.execute(command)
            .fold(
                { it.toRestError() },
                { createdGroup ->
                    ok(createdGroup)
                }
            )
    }

    @Operation(summary = "Get equipment group by id")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Equipment group by id request success", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = EquipmentGroupShortView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Equipment group was not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            )]
    )
    @GetMapping("#[[\$]]#API_V1_EQUIPMENT_GROUP/{groupId}")
    fun getById(@PathVariable groupId: String): ResponseEntity<*> {
        return getGroupById.execute(groupId)
            .fold(
                { it.toRestError() },
                { equipmentGroup -> ok(equipmentGroup) }
            )
    }

    @Operation(summary = "Delete existing equipment group")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Equipment group deleted", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = EquipmentGroupShortView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Equipment group was not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "Equipment group is not empty", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )]
    )
    @DeleteMapping("#[[\$]]#API_V1_EQUIPMENT_GROUP/{groupId}")
    fun deleteIfEmpty(@PathVariable groupId: String): ResponseEntity<*> {
        return deleteGroup.execute(DeleteEquipmentGroupCommand(groupId))
            .fold({ it.toRestError() },
                { deletedGroup ->
                    ok(deletedGroup)
                })
    }

    private fun CreateEquipmentGroupUseCaseError.toRestError() =
        when (this) {
            is CreateEquipmentGroupUseCaseError.EquipmentGroupNameAlreadyExistUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.equipment.group.error.validation.twins")
                        .format(name),
                    HttpStatus.CONFLICT
                )
        }

    private fun GetEquipmentGroupByIdUseCaseError.toRestError() =
        when (this) {
            is GetEquipmentGroupByIdUseCaseError.EquipmentGroupNotExistsUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.equipment.group.error.not-exist"),
                    HttpStatus.NOT_FOUND
                )
        }

    private fun DeleteEquipmentGroupUseCaseError.toRestError() =
        when (this) {
            is DeleteEquipmentGroupUseCaseError.EquipmentGroupNotExistUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.equipment.group.error.not-exist"),
                    HttpStatus.NOT_FOUND
                )

            is DeleteEquipmentGroupUseCaseError.EquipmentGroupIsNotEmptyUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.equipment.group.error.not-empty"),
                    HttpStatus.BAD_REQUEST
                )
        }
}

private fun EquipmentGroup.toShortView() = EquipmentGroupShortView(
    this.id,
    this.name
)

data class EquipmentGroupShortView(
    val id: String,
    val name: String
)

data class CreateEquipmentGroupCommand(
    val id: String,
    val name: String
)

data class DeleteEquipmentGroupCommand(
    val id: String
)
