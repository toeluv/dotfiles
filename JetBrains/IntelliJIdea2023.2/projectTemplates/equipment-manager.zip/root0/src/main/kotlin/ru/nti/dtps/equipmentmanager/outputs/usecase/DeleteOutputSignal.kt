package ru.nti.dtps.equipmentmanager.outputs.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.outputs.rest.DeleteOutputSignalCommand

interface DeleteOutputSignal {
    fun execute(command: DeleteOutputSignalCommand): Either<DeleteOutputSignalUseCaseError, Unit>
}

sealed class DeleteOutputSignalUseCaseError {
    object OutputSignalNotFoundError : DeleteOutputSignalUseCaseError()
}
