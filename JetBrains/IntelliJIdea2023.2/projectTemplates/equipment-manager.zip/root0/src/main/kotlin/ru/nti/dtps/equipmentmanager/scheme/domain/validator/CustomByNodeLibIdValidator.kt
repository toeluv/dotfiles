package ru.nti.dtps.equipmentmanager.scheme.domain.validator

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.SchemeEditorError
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.MutualityOptionValidator
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.VariableNameOptionValidator
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.CustomValidatorExecutor
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.CustomValidator

@Component
class CustomByNodeLibIdValidator(
    private val variableNameOptionValidator: VariableNameOptionValidator,
    private val mutualityOptionValidator: MutualityOptionValidator
) : CustomValidatorExecutor {

    override fun validateIfNeed(node: PrimitiveEquipment, scheme: Scheme): Either<SchemeEditorError, Unit> {
        node.type.getRequiredValidators().forEach { validator ->
            validator.validate(node, scheme).mapLeft { return it.left() }
        }
        return Unit.right()
    }

    private fun PrimitiveEquipment.PrimitiveEquipmentLibId.getRequiredValidators(): List<CustomValidator> {
        return when (this) {
            PrimitiveEquipment.PrimitiveEquipmentLibId.GROUNDING -> listOf()
            PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH -> listOf()
            PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH -> listOf()
            PrimitiveEquipment.PrimitiveEquipmentLibId.CONNECTIVITY -> listOf()
            PrimitiveEquipment.PrimitiveEquipmentLibId.CURRENT_SOURCE,
            PrimitiveEquipment.PrimitiveEquipmentLibId.EMF_SOURCE,
            PrimitiveEquipment.PrimitiveEquipmentLibId.IDEAL_TRANSFORMER,
            PrimitiveEquipment.PrimitiveEquipmentLibId.INDUCTANCE_COIL,
            PrimitiveEquipment.PrimitiveEquipmentLibId.CAPACITOR,
            PrimitiveEquipment.PrimitiveEquipmentLibId.RESISTOR ->
                listOf(
                    variableNameOptionValidator,
                    mutualityOptionValidator
                )
        }
    }
}
