package ru.nti.dtps.equipmentmanager.svg.persist.adapter

import ru.nti.dtps.equipmentmanager.svg.persist.dto.SignalInfoDto
import java.util.*

interface SignalInfoExtractor {
    fun getById(id: UUID): SignalInfoDto?
}