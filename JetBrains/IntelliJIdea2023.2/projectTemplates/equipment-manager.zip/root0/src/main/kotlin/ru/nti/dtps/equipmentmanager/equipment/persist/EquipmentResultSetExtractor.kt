package ru.nti.dtps.equipmentmanager.equipment.persist

import arrow.core.Either
import arrow.core.getOrElse
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentName
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.domain.PublicationInfo
import java.sql.ResultSet
import java.time.Instant

class EquipmentResultSetExtractor : ResultSetExtractor<Equipment> {
    override fun extractData(rs: ResultSet): Equipment? {
        return if (rs.next()) {
            EquipmentRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class EquipmentRowMapper : RowMapper<Equipment> {

    private val logger = LoggerFactory.getLogger(EquipmentRowMapper::class.java)

    override fun mapRow(rs: ResultSet, rowNum: Int): Equipment? {
        val idString = rs.getString("id")
        val companyIdString = rs.getString("company_id")
        val nameString = rs.getString("name")
        val groupIdString = rs.getString("group_id")
        val description = rs.getString("description")
        val published = rs.getBoolean("published")
        val publishedAt = Either.catch { Instant.parse(rs.getString("published_at")) }
            .getOrElse { null }
        val authorOfPublish = rs.getString("author_of_publish")
        val version = rs.getLong("version")
        val author = rs.getString("author")
        val createdAtString = rs.getString("created_at")
        val editor = rs.getString("editor")
        val updatedAt = Either.catch { Instant.parse(rs.getString("updated_at")) }
            .getOrElse { null }
        val publicationInfo = restorePublicationInfo(publishedAt, authorOfPublish)

        return Equipment.restore(
            id = EquipmentId.from(idString).getOrElse {
                logger.error("Incorrect equipment id #[[\$]]#idString")
                return null
            },
            companyId = CompanyId.from(idString).getOrElse {
                logger.error("Incorrect company id #[[\$]]#companyIdString")
                return null
            },
            name = EquipmentName.from(nameString).getOrElse {
                logger.error("Incorrect equipment name #[[\$]]#nameString")
                return null
            },
            groupId = groupIdString,
            description = description,
            published = published,
            publicationInfo = publicationInfo,
            version = version,
            author = author,
            createdAt = Either.catch { Instant.parse(createdAtString) }
                .getOrElse {
                    logger.error("Equipment #[[\$]]#idString has incorrect created timestamp: #[[\$]]#createdAtString")
                    return null
                },
            editor = editor,
            updatedAt = updatedAt
        )
    }
}

private fun restorePublicationInfo(
    publishedAt: Instant?,
    authorOfPublish: String
) = publishedAt?.let {
    PublicationInfo(publishedAt, authorOfPublish)
}
