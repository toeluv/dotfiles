package ru.nti.dtps.equipmentmanager.inputs.domain

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalNameAlreadyExists

class InputSignal private constructor(
    val id: InputSignalId,
    val equipmentId: EquipmentId,
    name: InputSignalName,
    unitType: UnitType,
    dataType: DataType,
    variableName: VariableName
) {
    var name = name
        internal set
    var unitType = unitType
        internal set
    var dataType = dataType
        internal set
    var variableName = variableName
        internal set

    companion object {
        fun create(
            id: InputSignalId,
            equipmentId: EquipmentId,
            name: InputSignalName,
            unitType: UnitType,
            dataType: DataType,
            variableName: VariableName,
            inputSignalNameAlreadyExists: InputSignalNameAlreadyExists
        ): Either<InputSignalError, InputSignal> {
            return if (inputSignalNameAlreadyExists(name, equipmentId)) {
                InputSignalError.InputSignalNameAlreadyExistError(name.toStringValue()).left()
            } else {
                InputSignal(
                    id, equipmentId, name, unitType, dataType, variableName
                ).right()
            }
        }

        fun restore(
            id: InputSignalId,
            equipmentId: EquipmentId,
            name: InputSignalName,
            unitType: UnitType,
            dataType: DataType,
            variableName: VariableName
        ) = InputSignal(
            id, equipmentId, name, unitType, dataType, variableName
        )
    }

    fun update(
        name: InputSignalName,
        unitType: UnitType,
        dataType: DataType,
        variableName: VariableName,
        inputSignalNameAlreadyExists: InputSignalNameAlreadyExists
    ): Either<InputSignalError, InputSignal> {
        return if (inputSignalNameAlreadyExists(this.id, name, this.equipmentId)) {
            InputSignalError.InputSignalNameAlreadyExistError(name.toStringValue()).left()
        } else {
            this.name = name
            this.unitType = unitType
            this.dataType = dataType
            this.variableName = variableName
            this.right()
        }
    }
}

sealed class InputSignalError {
    class InputSignalNameAlreadyExistError(val name: String) : InputSignalError()
}
