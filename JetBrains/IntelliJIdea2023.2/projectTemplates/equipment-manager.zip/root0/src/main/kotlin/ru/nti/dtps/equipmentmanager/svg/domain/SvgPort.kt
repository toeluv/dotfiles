package ru.nti.dtps.equipmentmanager.svg.domain

import ru.nti.dtps.equipmentmanager.scheme.domain.Alignment
import java.util.*

class SvgPort private constructor(
    val id: UUID,
    val libId: String,
    val coords: XyCoords,
    val alignment: Alignment,
    val hour: Int
) {
    companion object {
        fun create(
            id: UUID,
            libId: String,
            coords: XyCoords,
            alignment: Alignment,
            hour: Int
        ) = SvgPort(
            id,
            libId,
            coords,
            alignment,
            hour
        )
    }
}
