package ru.nti.dtps.equipmentmanager.user.persist.adapter

import ru.nti.dtps.equipmentmanager.common.types.UserId
import ru.nti.dtps.equipmentmanager.user.domain.User

interface UserPersister {
    fun save(user: User)
    fun saveUsersIfNotExist(users: List<User>)
    fun update(user: User)
    fun markUserAsDeleted(userId: UserId)
}