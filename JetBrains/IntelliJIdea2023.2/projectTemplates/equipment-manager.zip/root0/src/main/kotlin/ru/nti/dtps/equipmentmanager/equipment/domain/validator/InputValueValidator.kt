package ru.nti.dtps.equipmentmanager.equipment.domain.validator

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.types.DataType

interface InputValueValidator {
    fun validate(
        minValue: String,
        maxValue: String,
        defaultValue: String
    ): Either<InputValueError, Unit>

    fun getDataType(): DataType
}

interface InputValidatorHandler {
    fun handle(
        dataType: DataType,
        minValue: String,
        maxValue: String,
        defaultValue: String
    ): Either<InputValueError, Unit>
}

sealed class InputValueError {
    object InvalidInputValueFormat: InputValueError()
    object InvalidInputValueRange: InputValueError()
}