package ru.nti.dtps.equipmentmanager.scheme.domain

import ru.nti.dtps.equipment.meta.info.dataclass.equipment.port.Port
import kotlin.math.sqrt

data class PrimitiveEquipment(
    val id: String,
    val type: PrimitiveEquipmentLibId,
    val name: String,
    val ports: List<Port> = listOf(),
    val hour: Int = 0,
    val coords: XyCoords,
    val dimensions: Dimensions,
    val payload: String,
    val options: MutableMap<OptionLibId, String?> = mutableMapOf(),
) {
    data class Port(
        val id: String,
        val coords: XyCoords,
        val payload: String,
        val parentNode: String,
        val alignment: Alignment,
        val links: List<String>,


        val libId: PortLibId,
        val points: MutableList<Point> = mutableListOf()
    )

    data class Dimensions(
        val height: Double = 0.0,
        val width: Double = 0.0
    )

    enum class PrimitiveEquipmentLibId {
        CURRENT_SOURCE,
        EMF_SOURCE,
        GROUNDING,
        IDEAL_TRANSFORMER,
        INDUCTANCE_COIL,
        CAPACITOR,
        RESISTOR,
        CONNECTIVITY,
        PORT_1PH,
        PORT_3PH
    }

    fun getOptionValueOrNull(optionLib: OptionLibId): String? {
        return options[optionLib]
    }
}

fun PrimitiveEquipment.PrimitiveEquipmentLibId.isPrimitivePort() =
    this == PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH ||
        this == PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH

fun PrimitiveEquipment.getPhases() =
    when (this.type) {
        PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH -> Port.Phases.ONE
        PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH -> Port.Phases.THREE
        else -> Port.Phases.THREE
    }

fun PrimitiveEquipment.countAndSetMutualInductanceIfNeed() {
    if (this.type == PrimitiveEquipment.PrimitiveEquipmentLibId.IDEAL_TRANSFORMER) {
        val k = this.options[OptionLibId.COUPLING_COEFFICIENT]!!.toDouble()
        val l1 = this.options[OptionLibId.INDUCTANCE_L1]!!.toDouble()
        val l2 = this.options[OptionLibId.INDUCTANCE_L2]!!.toDouble()

        this.options[OptionLibId.MUTUAL_INDUCTANCE] = (k * sqrt(l1 * l2)).toString()
    }
}
