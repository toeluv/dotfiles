package ru.nti.dtps.equipmentmanager.cplus.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.cplus.docker.domain.DockerApi
import ru.nti.dtps.equipmentmanager.cplus.docker.domain.RequiredImageProvider
import ru.nti.dtps.equipmentmanager.cplus.usecase.*

@Component
class BuildEquipmentCppUseCase(
    private val dockerApi: DockerApi,
    private val requiredImageProvider: RequiredImageProvider,
    private val createTemplateFile: CreateTemplateFile,
    private val deleteTemplateFile: DeleteTemplateFile
) : BuildEquipmentCpp {
    override fun execute(equipmentId: EquipmentId): Either<BuildEquipmentCppUseCaseError, EquipmentBuildInfo> {
        return createTemplateFile.execute(equipmentId)
            .fold({ it.toUseCaseError().left() }, {
                dockerApi.createContainer(equipmentId, requiredImageProvider()).fold(
                    { BuildEquipmentCppUseCaseError.CreateDockerContainerUseCaseError.left() },
                    { containerId ->
                        dockerApi.startContainer(containerId)
                        dockerApi.getContainerLogs(containerId).fold(
                            { BuildEquipmentCppUseCaseError.GetDockerContainerLogsUseCaseError.left() },
                            { EquipmentBuildInfo(equipmentId.toStringValue(), it.logs, it.buildResult).right() }
                        ).also { dockerApi.removeContainer(containerId) }
                    }
                ).also { deleteTemplateFile.execute(equipmentId) }
            })
    }

    private fun CreateTemplateFileError.toUseCaseError() =
        when (this) {
            is CreateTemplateFileError.EquipmentNotExistsError -> BuildEquipmentCppUseCaseError.EquipmentNotExistUseCaseError
            is CreateTemplateFileError.SchemeNotExistsError -> BuildEquipmentCppUseCaseError.SchemeNotExistUseCaseError
        }
}

