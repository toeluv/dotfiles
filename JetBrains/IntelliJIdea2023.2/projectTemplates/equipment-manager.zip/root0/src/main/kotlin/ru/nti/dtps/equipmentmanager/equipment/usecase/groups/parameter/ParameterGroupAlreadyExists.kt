package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter

fun interface ParameterGroupAlreadyExists {
    operator fun invoke(
        parameterGroupName: String
    ): Boolean
}
