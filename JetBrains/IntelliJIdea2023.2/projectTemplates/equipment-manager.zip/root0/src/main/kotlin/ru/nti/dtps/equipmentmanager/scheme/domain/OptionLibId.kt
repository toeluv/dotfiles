package ru.nti.dtps.equipmentmanager.scheme.domain

enum class OptionLibId {
    VARIABLE_NAME,
    NAME,
    CONDUCTIVITY,
    CURRENT_VALUE,
    RESISTANCE,
    EMF_VALUE,
    INDUCTANCE_L1,
    INDUCTANCE_L2,
    COUPLING_COEFFICIENT,
    MUTUAL_INDUCTANCE,
    INDUCTANCE,
    CAPACITANCE,
    MUTUALITY
}