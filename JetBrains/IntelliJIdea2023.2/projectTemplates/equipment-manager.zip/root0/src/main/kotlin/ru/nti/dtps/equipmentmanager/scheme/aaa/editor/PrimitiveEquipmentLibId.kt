package ru.nti.dtps.equipmentmanager.scheme.aaa.editor

enum class PrimitiveEquipmentLibId {
        CURRENT_SOURCE,
        EMF_SOURCE,
        GROUNDING,
        IDEAL_TRANSFORMER,
        INDUCTANCE_COIL,
        CAPACITOR,
        RESISTOR,
        CONNECTIVITY,
        PORT_1PH,
        PORT_3PH
    }