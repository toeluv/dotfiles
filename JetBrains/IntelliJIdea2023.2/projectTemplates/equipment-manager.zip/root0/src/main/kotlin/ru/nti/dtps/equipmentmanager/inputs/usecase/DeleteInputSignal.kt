package ru.nti.dtps.equipmentmanager.inputs.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.inputs.rest.DeleteInputSignalCommand

interface DeleteInputSignal {
    fun execute(command: DeleteInputSignalCommand): Either<DeleteInputSignalUseCaseError, Unit>
}

sealed class DeleteInputSignalUseCaseError {
    object InputSignalNotFoundError : DeleteInputSignalUseCaseError()
}
