package ru.nti.dtps.equipmentmanager.scheme.domain

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.domain.command.*
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.LibInfoExtractor
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.BasicNodeValidator
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.ComplexSchemeValidator
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.CustomByNodeLibIdValidator
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.branch.MutualBranchVariableValidator
import ru.nti.dtps.equipmentmanager.scheme.rest.CreateBranchCommand
import ru.nti.dtps.equipmentmanager.scheme.rest.UpdateBranchCommand

data class Scheme(
    val id: EquipmentId,
    val primitiveNodes: MutableMap<String, PrimitiveEquipment> = mutableMapOf(),
    val links: MutableMap<String, PrimitiveEquipmentLink> = mutableMapOf(),
    val version: Long,
    val mutualBranches: MutableList<MutualBranch> = mutableListOf(),
    var isValid: Boolean = false
) {
    companion object {
        fun create(id: EquipmentId) = Scheme(id = id, version = 0)

        fun restore(
            id: EquipmentId,
            primitiveNodes: MutableMap<String, PrimitiveEquipment>,
            links: MutableMap<String, PrimitiveEquipmentLink>,
            version: Long,
            mutualBranches: MutableList<MutualBranch>,
            isValid: Boolean
        ) = Scheme(
            id, primitiveNodes, links, version, mutualBranches, isValid
        )
    }

    fun validate(
        complexSchemeValidator: ComplexSchemeValidator
    ): Either<SchemeValidationError, Unit> {
        return complexSchemeValidator.validate(this)
            .fold(
                { it.left() },
                {
                    this.isValid = true
                    Unit.right()
                }
            )
    }

    fun execute(
        command: Command,
        libInfoExtractor: LibInfoExtractor,
        allowedPrimitivePortNumber: Int,
        customByNodeLibIdValidator: CustomByNodeLibIdValidator
    ): Either<SchemeEditorError, Unit> {
        if (isValid) {
            isValid = false
        }
        return when (command) {
            is BatchCommand -> handle(command, libInfoExtractor, allowedPrimitivePortNumber, customByNodeLibIdValidator)
            is CreateNodeCommand -> handle(command, allowedPrimitivePortNumber, customByNodeLibIdValidator)
            is ChangeNodeCoordsCommand -> handle(command)
            is ChangeNodeDimensionsCommand -> handle(command)
            is ChangeNodeRotationCommand -> handle(command)
            is ChangeNodeParamsCommand -> handle(command, libInfoExtractor, customByNodeLibIdValidator)
            is ChangeNodePortsCommand -> handle(command)
            is DeleteNodeCommand -> handle(command)

            is DeleteLinkCommand -> handle(command)
            is CreateLinkCommand -> handle(command)
            is UpdateLinkCommand -> handle(command)
            else -> error("Unimplemented command type")
        }
    }

    private fun handle(
        command: BatchCommand,
        libInfoExtractor: LibInfoExtractor,
        allowedPrimitivePortNumber: Int,
        customByNodeLibIdValidator: CustomByNodeLibIdValidator
    ): Either<SchemeEditorError, Unit> {
        command.commands.forEach { innerCommand ->
            this.execute(innerCommand, libInfoExtractor, allowedPrimitivePortNumber, customByNodeLibIdValidator)
                .fold(
                    { return it.left() },
                    { Unit.right() }
                )
        }
        return Unit.right()
    }

    private fun handle(
        command: CreateNodeCommand,
        allowedPrimitivePortNumber: Int,
        customByNodeLibIdValidator: CustomByNodeLibIdValidator
    ): Either<SchemeEditorError, Unit> {
        val change = command.body
        if (!isNodeNameUnique(change.name)) {
            return SchemeEditorError.EquipmentWithPresentedNameAlreadyExist(change.name).left()
        }

        if (change.libEquipmentId.isPrimitivePort() &&
            primitiveNodes.values.filter { it.type.isPrimitivePort() }.size >= allowedPrimitivePortNumber
        ) {
            return SchemeEditorError.SchemeAlreadyContainsMaxCountPrimitivePortError(
                allowedPrimitivePortNumber,
                primitiveNodes.values.filter { it.type.isPrimitivePort() }.size
            ).left()
        }

        val createdNode = change.execute()
        createdNode.countAndSetMutualInductanceIfNeed()

        customByNodeLibIdValidator.validateIfNeed(createdNode, this).mapLeft { return it.left() }

        primitiveNodes[createdNode.id] = createdNode
        return Unit.right()
    }

    private fun handle(command: ChangeNodeCoordsCommand): Either<SchemeEditorError, Unit> {
        val change = command.body
        return primitiveNodes[change.id]?.let { node ->
            primitiveNodes[change.id] = change.execute(node)
            Unit.right()
        } ?: SchemeEditorError.EquipmentDoesNotExistError(change.id).left()
    }

    private fun handle(command: ChangeNodeDimensionsCommand): Either<SchemeEditorError, Unit> {
        val change = command.body
        return primitiveNodes[change.id]?.let { node ->
            primitiveNodes[change.id] = change.execute(node)
            Unit.right()
        } ?: SchemeEditorError.EquipmentDoesNotExistError(change.id).left()
    }

    private fun handle(command: ChangeNodeRotationCommand): Either<SchemeEditorError, Unit> {
        val change = command.body
        return primitiveNodes[change.id]?.let { node ->
            primitiveNodes[change.id] = change.execute(node)
            Unit.right()
        } ?: SchemeEditorError.EquipmentDoesNotExistError(change.id).left()
    }

    private fun handle(
        command: ChangeNodeParamsCommand,
        libInfoExtractor: LibInfoExtractor,
        customByNodeLibIdValidator: CustomByNodeLibIdValidator
    ): Either<SchemeEditorError, Unit> {
        val change = command.body
        val node = primitiveNodes[change.id]
            ?: return SchemeEditorError.EquipmentDoesNotExistError(change.id).left()
        return if (isNodeNameUniqueExcludedNode(change.name, change.id)) {
            executeNodeChangeAndUpdate(node, change, libInfoExtractor, customByNodeLibIdValidator)
        } else {
            SchemeEditorError.EquipmentWithPresentedNameAlreadyExist(change.name).left()
        }
    }

    private fun handle(command: ChangeNodePortsCommand): Either<SchemeEditorError, Unit> {
        val change = command.body
        return primitiveNodes[change.id]?.let { node ->
            primitiveNodes[change.id] = change.execute(node)
            Unit.right()
        } ?: SchemeEditorError.EquipmentDoesNotExistError(change.id).left()
    }

    private fun handle(command: DeleteNodeCommand): Either<SchemeEditorError, Unit> {
        val change = command.body
        return primitiveNodes.remove(change.id)?.let {
            Unit.right()
        } ?: SchemeEditorError.EquipmentDoesNotExistError(change.id).left()
    }

    private fun handle(command: DeleteLinkCommand): Either<SchemeEditorError, Unit> {
        val change = command.body
        return links.remove(change.id)?.let {
            Unit.right()
        } ?: SchemeEditorError.LinkDoesNotExistError(change.id).left()
    }

    private fun handle(command: CreateLinkCommand): Either<SchemeEditorError, Unit> {
        val change = command.body
        return links[change.id]?.let {
            SchemeEditorError.LinkWithIdAlreadyPresented(change.id).left()
        } ?: change.execute()
            .apply { links[this.id] = this }
            .let { Unit.right() }
    }

    private fun handle(command: UpdateLinkCommand): Either<SchemeEditorError, Unit> {
        val change = command.body
        return links[change.id]?.let { link ->
            links[change.id] = change.execute(link)
            Unit.right()
        } ?: SchemeEditorError.LinkDoesNotExistError(change.id).left()
    }

    private fun isNodeNameUnique(nodeName: String): Boolean {
        return primitiveNodes.values.firstOrNull { it.name == nodeName } == null
    }

    private fun isNodeNameUniqueExcludedNode(nodeName: String, excludedId: String): Boolean {
        return primitiveNodes.values
            .filter { it.id != excludedId }
            .firstOrNull { it.name == nodeName } == null
    }

    private fun executeNodeChangeAndUpdate(
        node: PrimitiveEquipment,
        change: ChangeNodeParams,
        libInfoExtractor: LibInfoExtractor,
        businessValidator: CustomByNodeLibIdValidator
    ): Either<SchemeEditorError, Unit> {
        val updatedNode = change.execute(node)
        updatedNode.countAndSetMutualInductanceIfNeed()

        businessValidator.validateIfNeed(updatedNode, this).mapLeft { return it.left() }

        return BasicNodeValidator.validateNode(updatedNode, libInfoExtractor)
            .fold(
                { SchemeEditorError.EquipmentOptionsValidationError(it).left() },
                {
                    primitiveNodes[change.id] = updatedNode
                    Unit.right()
                }
            )
    }

    fun createMutualBranch(
        command: CreateBranchCommand,
        mutualBranchVariableValidator: MutualBranchVariableValidator
    ): Either<MutualBranchError, MutualBranch> {
        mutualBranchVariableValidator.validate(command.name, this).mapLeft {
            return it.left()
        }
        val mutualBranch = MutualBranch.create(
            command.id,
            command.name,
            command.isResistive,
            command.resistance,
            command.conductivity,
            command.elementType
        )
        return mutualBranch.also { mutualBranches.add(it) }.right()
    }

    fun updateMutualBranch(
        command: UpdateBranchCommand,
        mutualBranchVariableValidator: MutualBranchVariableValidator
    ): Either<MutualBranchError, MutualBranch> {

        mutualBranchVariableValidator.validate(command.name, this).mapLeft {
            return it.left()
        }

        val mutualBranch = this.mutualBranches.find { it.id == command.id }
            ?: return MutualBranchError.MutualBranchNotFound(command.id).left()

        val isBranchEmpty = !this.primitiveNodes.values
            .flatMap { it.options.values }
            .contains(command.id)

        return mutualBranch.apply {
            this.variableName = command.name
            this.isResistive = command.isResistive
            this.resistance = command.resistance
            this.conductivity = command.conductivity
            if (isBranchEmpty) {
                this.elementType = command.elementType
            }
        }.right()
    }

    fun deleteMutualBranch(branchId: String): Either<MutualBranchError, Unit> {
        mutualBranches.removeIf { it.id == branchId }.let { removed ->
            if (!removed) {
                return MutualBranchError.MutualBranchNotFound(branchId).left()
            }
        }
        this.primitiveNodes.values.forEach { node ->
            node.options.remove(OptionLibId.MUTUALITY)
        }
        return Unit.right()
    }

}

sealed class SchemeEditorError {
    class LinkWithIdAlreadyPresented(val id: String) : SchemeEditorError()
    class LinkDoesNotExistError(val id: String) : SchemeEditorError()
    class EquipmentDoesNotExistError(val id: String) : SchemeEditorError()
    class EquipmentWithPresentedNameAlreadyExist(val name: String) : SchemeEditorError()
    class EquipmentOptionsValidationError(
        val validationError: SchemeValidationError
    ) : SchemeEditorError()

    class SchemeAlreadyContainsMaxCountPrimitivePortError(
        val allowedPrimitivePortNumber: Int,
        val currentPrimitivePortNumber: Int
    ) : SchemeEditorError()

    class VariableNameOptionIsNotValidOrUniqueError(
        val value: String
    ) : SchemeEditorError()

    class RequiredFieldNotFoundError(
        val equipmentId: String,
        val equipmentName: String,
        val optionLibId: OptionLibId
    ) : SchemeEditorError()

    class MutualityOptionIsNotValidError(
        val equipmentId: String,
        val equipmentName: String
    ) : SchemeEditorError()
}

sealed class MutualBranchError(val message: String) {
    class VariableNameIsNotValidOrUniqueError(message: String) : MutualBranchError(message)
    class MutualBranchNotFound(message: String) : MutualBranchError(message)
}
