package ru.nti.dtps.equipmentmanager.scheme.domain

enum class Alignment {
    TOP,
    BOTTOM,
    RIGHT,
    LEFT
}