package ru.nti.dtps.equipmentmanager.svg.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.svg.domain.*
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgExtractor
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgInfoExtractor
import ru.nti.dtps.equipmentmanager.svg.usecase.GetSvgWithInfoByEquipment
import ru.nti.dtps.equipmentmanager.svg.usecase.GetSvgWithInfoByEquipmentUseCaseError
import java.util.UUID

@Component
class GetSvgWithInfoByEquipmentUseCase(
    private val svgExtractor: SvgExtractor,
    private val svgInfoExtractor: SvgInfoExtractor
) : GetSvgWithInfoByEquipment {
    override fun execute(id: EquipmentId): Either<GetSvgWithInfoByEquipmentUseCaseError, ComplexSvgInfo> {
        val svg = svgExtractor.getById(id.toUUID())
            ?: return GetSvgWithInfoByEquipmentUseCaseError.SvgNotFound.left()
        val svgInfo = svgInfoExtractor.getById(id.toUUID())
            ?: return GetSvgWithInfoByEquipmentUseCaseError.SvgInfoNotFound.left()

        return ComplexSvgInfo(
            id.toUUID(),
            svg.svgScheme,
            svg.svgLib,
            svgInfo.coords,
            svgInfo.dimensions,
            svgInfo.hour,
            svgInfo.ports,
            svgInfo.placeholders
        ).right()
    }
}

data class ComplexSvgInfo(
    val id: UUID,
    val svgForScheme: ByteArray?,
    val svgForLibrary: ByteArray?,
    val coords: XyCoords?,
    val dimensions: Dimensions?,
    val hour: Int?,
    val ports: List<SvgPort>,
    val placeholders: List<Placeholder>
)