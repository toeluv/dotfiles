package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment

fun interface EquipmentGroupAlreadyExists {
    operator fun invoke(
        equipmentGroupName: String
    ): Boolean
}
