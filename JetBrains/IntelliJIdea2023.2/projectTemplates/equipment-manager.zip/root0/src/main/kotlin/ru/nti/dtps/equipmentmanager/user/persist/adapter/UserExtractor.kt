package ru.nti.dtps.equipmentmanager.user.persist.adapter

import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.UserId
import ru.nti.dtps.equipmentmanager.user.domain.User

interface UserExtractor {
    fun getById(userId: UserId): User?
    fun getAll(): Collection<User>
    fun getAllByCompanyId(companyId: CompanyId): List<User>
}