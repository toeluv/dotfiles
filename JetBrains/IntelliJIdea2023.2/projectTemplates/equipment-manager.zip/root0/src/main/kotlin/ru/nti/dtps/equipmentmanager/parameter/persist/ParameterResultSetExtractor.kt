package ru.nti.dtps.equipmentmanager.parameter.persist

import arrow.core.getOrElse
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.types.ParameterName
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import java.sql.ResultSet

class ParameterResultSetExtractor : ResultSetExtractor<Parameter> {
    override fun extractData(rs: ResultSet): Parameter? {
        return if (rs.next()) {
            ParameterRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class ParameterRowMapper : RowMapper<Parameter> {

    private val logger = LoggerFactory.getLogger(ParameterRowMapper::class.java)

    override fun mapRow(rs: ResultSet, rowNum: Int): Parameter? {
        val idString = rs.getString("id")
        val equipmentIdString = rs.getString("equipment_id")
        val nameString = rs.getString("name")
        val groupIdString = rs.getString("group_id")
        val unitTypeString = rs.getString("unit_type")
        val dataTypeString = rs.getString("data_type")
        val minValueString = rs.getString("min_value")
        val maxValueString = rs.getString("max_value")
        val defaultValueString = rs.getString("default_value")
        val variableNameString = rs.getString("variable_name")

        return Parameter(
            id = ParameterId.from(idString).getOrElse {
                logger.error("Incorrect parameter id #[[\$]]#idString")
                return null
            },
            equipmentId = EquipmentId.from(equipmentIdString).getOrElse {
                logger.error("Incorrect equipment id #[[\$]]#equipmentIdString")
                return null
            },
            name = ParameterName.from(nameString).getOrElse {
                logger.error("Incorrect name #[[\$]]#nameString")
                return null
            },
            groupId = groupIdString,
            unitType = UnitType.valueOf(unitTypeString),
            dataType = DataType.valueOf(dataTypeString),
            minValue = minValueString,
            maxValue = maxValueString,
            defaultValue = defaultValueString,
            variableName = VariableName.from(variableNameString).getOrElse {
                logger.error("Incorrect variable name #[[\$]]#variableNameString")
                return null
            }
        )
    }
}