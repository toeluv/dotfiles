package ru.nti.dtps.equipmentmanager.equipment.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.equipment.usecase.PublishEquipment
import ru.nti.dtps.equipmentmanager.equipment.usecase.PublishEquipmentUseCaseError

@RestController
class PublishEquipmentEndpoint(
    private val messageSource: MessageSourceService,
    private val publishEquipment: PublishEquipment
) {

    @Operation(summary = "Publish equipment")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Equipment published", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = EquipmentShortView::class)
                    ))]
            ),
            ApiResponse(responseCode = "400", description = "Unsupported request fields",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "400", description = "Scheme not valid",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "404", description = "Equipment not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "404", description = "Scheme not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "404", description = "Algorithm not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "404", description = "Svg not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]),
            ApiResponse(responseCode = "500", description = "Something went wrong, go to admin",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                ))])]
    )
    @PostMapping("#[[\$]]#API_V1_EQUIPMENT/{equipmentId}")
    fun publishEquipment(
        @PathVariable equipmentId: String
    ): ResponseEntity<*> {

        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    publishEquipment.execute(validEquipmentId)
                        .fold(
                            { it.toRestError() },
                            { ok(it) }
                        )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun PublishEquipmentUseCaseError.toRestError() =
        when (this) {
            PublishEquipmentUseCaseError.AlgorithmCodeNotFoundError -> restBusinessError(
                messageSource.getMessage("api.algorithm.error.not-compiled"),
                HttpStatus.NOT_FOUND
            )
            PublishEquipmentUseCaseError.EquipmentNotFoundError -> restBusinessError(
                messageSource.getMessage("api.equipment.error.not-found"),
                HttpStatus.NOT_FOUND
            )
            PublishEquipmentUseCaseError.SchemeNotFoundError -> restBusinessError(
                messageSource.getMessage("api.scheme.error.not-found"),
                HttpStatus.NOT_FOUND
            )
            PublishEquipmentUseCaseError.SvgNotFoundError -> restBusinessError(
                messageSource.getMessage("api.svg.error.info.not-found"),
                HttpStatus.NOT_FOUND
            )

            PublishEquipmentUseCaseError.SchemeNotValidError -> restBusinessError(
                messageSource.getMessage("api.scheme.error.not-valid"),
                HttpStatus.BAD_REQUEST
            )

            PublishEquipmentUseCaseError.PublishEquipmentError -> restBusinessError(
                messageSource.getMessage("api.equipment.error.publish"),
                HttpStatus.INTERNAL_SERVER_ERROR
            )
        }
}