package ru.nti.dtps.equipmentmanager.equipment.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.domain.command.DeleteEquipmentCommand

interface DeleteEquipment {
    fun execute(command: DeleteEquipmentCommand): Either<DeleteEquipmentUseCaseError, Equipment>
}

sealed class DeleteEquipmentUseCaseError {
    object EquipmentNotFoundUseCaseError : DeleteEquipmentUseCaseError()
}