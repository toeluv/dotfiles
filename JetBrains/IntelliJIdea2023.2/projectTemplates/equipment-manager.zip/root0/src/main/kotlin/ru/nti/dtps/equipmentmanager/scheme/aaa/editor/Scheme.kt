package ru.nti.dtps.equipmentmanager.scheme.aaa.editor

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId

class Scheme(
    val id: EquipmentId,
    val version: Long,
    val isValid: Boolean
)