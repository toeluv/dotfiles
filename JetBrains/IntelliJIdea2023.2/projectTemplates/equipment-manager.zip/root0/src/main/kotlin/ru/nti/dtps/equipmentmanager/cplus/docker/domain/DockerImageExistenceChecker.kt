package ru.nti.dtps.equipmentmanager.cplus.docker.domain

import org.slf4j.LoggerFactory
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.stereotype.Component
import org.springframework.util.Assert
import ru.nti.dtps.equipmentmanager.cplus.docker.configuration.CppCompilerImageProperties

@Component
@ConditionalOnProperty(
    name = ["app.check-pre-requirements"],
    havingValue = "true"
)
class DockerImageExistenceChecker(
    private val dockerApi: DockerApi,
    private val cppCompilerImageProperties: CppCompilerImageProperties
) {

    private val logger = LoggerFactory.getLogger(DockerImageExistenceChecker::class.java)

    init {
        checkCompilerImageExistence()
    }

    private fun checkCompilerImageExistence() {
        logger.debug("Check C++ compiler image existence with properties {}", cppCompilerImageProperties)
        val cppCompilerImageIdList =
            dockerApi.getCppCompilerImageId(cppCompilerImageProperties.getImageTag())
        Assert.isTrue(
            cppCompilerImageIdList.isNotEmpty(),
            "C++ compiler image #[[\$]]#{cppCompilerImageProperties.getImageTag()} does not presented in docker registry "
        )
        logger.info("C++ compiler image {} is exist", cppCompilerImageProperties.getImageTag())
        logger.info("Docker client pre requirements successfully checked")
    }
}
