package ru.nti.dtps.equipmentmanager.common.configuration.client

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.stereotype.Component

@Component
@ConfigurationProperties(prefix = "internal.address")
data class InternalClientProperties(
    var integrationPlatform: String = "",
)