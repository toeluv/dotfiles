package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.validators

import arrow.core.Either
import arrow.core.left
import arrow.core.mapOrAccumulate
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.BusinessNodeValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeToValidate
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.UnknownNodeValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionsValidatorProvider
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.validators.*
import java.util.*

@Component
class NodeOptionsBaseValidator(
    private val optionsValidatorProvider: OptionsValidatorProvider
) : BusinessNodeValidator  {

    override fun order() = -9999

    override fun validate(node: NodeToValidate): Either<NodeValidationError, Unit> {
        val errors =
            optionsValidatorProvider.get(node.type()).map { it.validate(node.options()) }.mapOrAccumulate { it.bind() }

        return errors.fold(
            { optionValidationErrors -> optionValidationErrors.toList().map { cast(it, node) }.first().left() },
            { Unit.right() }
        )
    }

    private fun cast(error: OptionValidationError, node: NodeToValidate): NodeValidationError {
        return when (error) {
            is FieldValueLessThenLimitValueError -> FieldLessThenLimitNodeValidationError(
                node.id(),
                node.equipmentId(),
                error.optionLib,
                error.boundValue
            )

            is FieldValueMoreThenLimitValueError -> FieldMoreThenLimitNodeValidationError(
                node.id(),
                node.equipmentId(),
                error.optionLib,
                error.boundValue
            )

            is TextFieldLengthDoNotEqualValueError -> FieldLengthDoNotEqualNodeValidationError(
                node.id(),
                node.equipmentId(),
                error.optionLib,
                error.boundValue
            )

            is TextFieldLengthMoreThenMaxValueError -> FieldLengthMoreThenMaxValidationError(
                node.id(),
                node.equipmentId(),
                error.optionLib,
                error.boundValue
            )

            is TextFieldLengthLessThenMinValueError -> FieldLengthLessThenMaxValidationError(
                node.id(),
                node.equipmentId(),
                error.optionLib,
                error.boundValue
            )

            is InvalidFiledType -> InvalidFiledTypeValidationError(node.id(), node.equipmentId(), error.optionLib)
            is InvalidFieldFormat -> InvalidFiledTypeFormatError(node.id(), node.equipmentId(), error.optionLib)
            is RequiredFieldNotFoundError -> RequiredFieldValidationError(
                node.id(),
                node.equipmentId(),
                error.optionLib
            )

            else -> UnknownNodeValidationError(node.id(), node.equipmentId())
        }
    }
}

data class FieldLessThenLimitNodeValidationError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val optionLib: OptionLibId,
    val boundValue: Double
) : NodeValidationError

data class FieldMoreThenLimitNodeValidationError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val optionLibId: OptionLibId,
    val boundValue: Double
) : NodeValidationError

data class FieldLengthDoNotEqualNodeValidationError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val optionLib: OptionLibId,
    val boundValue: Int
) : NodeValidationError

data class FieldLengthMoreThenMaxValidationError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val optionLib: OptionLibId,
    val boundValue: Int
) : NodeValidationError

data class FieldLengthLessThenMaxValidationError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val optionLib: OptionLibId,
    val boundValue: Int
) : NodeValidationError

data class InvalidFiledTypeValidationError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val optionLibId: OptionLibId
) : NodeValidationError

data class InvalidFiledTypeFormatError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val optionLibId: OptionLibId
) : NodeValidationError

data class RequiredFieldValidationError(
    val nodeId: UUID,
    val equipmentId: EquipmentId,
    val optionLib: OptionLibId
) : NodeValidationError



