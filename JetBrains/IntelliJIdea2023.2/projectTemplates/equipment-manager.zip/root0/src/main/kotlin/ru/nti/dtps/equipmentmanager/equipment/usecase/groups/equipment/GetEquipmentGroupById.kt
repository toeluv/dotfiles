package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup

interface GetEquipmentGroupById {
    fun execute(groupId: String): Either<GetEquipmentGroupByIdUseCaseError, EquipmentGroup>
}

sealed class GetEquipmentGroupByIdUseCaseError : UseCaseError {
    object EquipmentGroupNotExistsUseCaseError : GetEquipmentGroupByIdUseCaseError()
}

