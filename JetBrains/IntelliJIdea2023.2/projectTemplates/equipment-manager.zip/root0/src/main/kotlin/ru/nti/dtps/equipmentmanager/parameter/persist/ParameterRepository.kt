package ru.nti.dtps.equipmentmanager.parameter.persist

import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.ParameterId
import ru.nti.dtps.equipmentmanager.common.types.ParameterName
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterExtractor
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterNameAlreadyExists
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterPersister
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import javax.sql.DataSource

@Component
class ParameterRepository(
    dataSource: DataSource
) : ParameterExtractor, ParameterPersister, ParameterNameAlreadyExists {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    override fun getAllByEquipmentId(equipmentId: EquipmentId): Collection<Parameter> {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.parameter
            WHERE equipment_id = :equipment_id 
            """.trimMargin(),
            mapOf("equipment_id" to equipmentId.toUUID()),
            ParameterRowMapper()
        ).toSet()
    }

    override fun getAllByCompanyId(companyId: CompanyId): Collection<Parameter> {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.parameter
            WHERE company_id = :company_id 
            """.trimMargin(),
            mapOf("company_id" to companyId.toUUID()),
            ParameterRowMapper()
        ).toSet()
    }

    override fun getById(id: ParameterId): Parameter? {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.parameter
            WHERE id = :id
            """.trimMargin(),
            mapOf("id" to id.toUUID()),
            ParameterResultSetExtractor()
        )
    }

    @Transactional
    override fun save(parameter: Parameter) {
        val params = mapOf(
            "id" to parameter.id.toUUID(),
            "equipment_id" to parameter.equipmentId.toUUID(),
            "name" to parameter.name.toStringValue(),
            "group_id" to parameter.groupId,
            "unit_type" to parameter.unitType.name,
            "data_type" to parameter.dataType.name,
            "min_value" to parameter.minValue,
            "max_value" to parameter.maxValue,
            "default_value" to parameter.defaultValue,
            "variable_name" to parameter.variableName.toStringValue()
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.parameter(
                id, 
                equipment_id, 
                name, 
                group_id, 
                unit_type, 
                data_type, 
                min_value, 
                max_value, 
                default_value, 
                variable_name
            )
            VALUES(
                :id, 
                :equipment_id, 
                :name, 
                :group_id, 
                :unit_type, 
                :data_type, 
                :min_value, 
                :max_value, 
                :default_value, 
                :variable_name
            )
            """.trimMargin(), params
        )
    }

    @Transactional
    override fun update(parameter: Parameter) {
        val params = mapOf(
            "id" to parameter.id.toUUID(),
            "name" to parameter.name.toStringValue(),
            "group_id" to parameter.groupId,
            "unit_type" to parameter.unitType.name,
            "data_type" to parameter.dataType.name,
            "min_value" to parameter.minValue,
            "max_value" to parameter.maxValue,
            "default_value" to parameter.defaultValue,
            "variable_name" to parameter.variableName.toStringValue()
        )
        jdbcTemplate.update(
            """
            UPDATE public.parameter SET
            name = :name,
            group_id = :group_id,
            unit_type = :unit_type,
            data_type = :data_type,
            min_value = :min_value,
            max_value = :max_value,
            default_value = :default_value,
            variable_name = :variable_name
            WHERE id = :id
            """.trimIndent(), params
        )
    }

    override fun delete(id: ParameterId) {
        jdbcTemplate.update(
            "DELETE from public.parameter WHERE id = :id",
            mapOf("id" to id.toUUID())
        )
    }

    override fun deleteAllByEquipmentId(equipmentId: EquipmentId) {
        jdbcTemplate.update(
            "DELETE from public.parameter WHERE equipment_id = :equipment_id",
            mapOf("equipment_id" to equipmentId.toUUID())
        )
    }

    override operator fun invoke(equipmentId: EquipmentId, parameterName: ParameterName): Boolean {
        return jdbcTemplate.query(
            """
            SELECT EXISTS
            ( SELECT 1 FROM public.parameter
            WHERE name = :name
            AND equipment_id = :equipment_id);
            """.trimMargin(),
            mapOf(
                "name" to parameterName.toStringValue(),
                "equipment_id" to equipmentId.toUUID()
            ),
            ResultSetExtractor { rs ->
                rs.next()
                rs.getBoolean(1)
            }
        ) ?: false
    }

    override operator fun invoke(
        equipmentId: EquipmentId,
        parameterName: ParameterName,
        excludedParameterId: ParameterId
    ): Boolean {
        return jdbcTemplate.query(
            """
            SELECT EXISTS
            ( SELECT 1 FROM public.parameter
            WHERE name = :name
            AND equipment_id = :equipment_id
            AND id <> :id);
            """.trimMargin(),
            mapOf(
                "name" to parameterName.toStringValue(),
                "equipment_id" to equipmentId.toUUID(),
                "id" to excludedParameterId.toUUID(),
            ),
            ResultSetExtractor { rs ->
                rs.next()
                rs.getBoolean(1)
            }
        ) ?: false
    }
}