package ru.nti.dtps.equipmentmanager.equipment.rest

import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import java.time.Instant

data class EquipmentShortView(
    val id: String,
    var name: String,
    var groupId: String?,
    var description: String?,
    var published: Boolean,
    var publishedAt: Instant?,
    var authorOfPublish: String?,
    var version: Long,
    val author: String,
    val createdAt: Instant,
    val editor: String?,
    var updatedAt: Instant?
)

fun Equipment.toShortView() = EquipmentShortView(
    id = id.toStringValue(),
    name = name.toStringValue(),
    groupId = groupId,
    description = description,
    published = published,
    publishedAt = publicationInfo?.publishedAt,
    authorOfPublish = publicationInfo?.authorOfPublish,
    version = version,
    author = author,
    createdAt = createdAt,
    editor = editor,
    updatedAt = updatedAt
)
