package ru.nti.dtps.equipmentmanager.scheme.aaa.command

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.scheme.aaa.execution.CommandSuccessResult

interface CommandExecutor<T : UserCommand> {
    fun execute(command: T): Either<CommandExecutionError, CommandSuccessResult>
}

open class CommandExecutionError

class NodeNotFoundError(
    val nodeId: String
) : CommandExecutionError()

class LinkNotFoundError(
    val link: String
) : CommandExecutionError()