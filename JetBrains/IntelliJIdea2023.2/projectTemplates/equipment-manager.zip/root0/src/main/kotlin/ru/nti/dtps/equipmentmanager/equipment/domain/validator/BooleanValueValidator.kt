package ru.nti.dtps.equipmentmanager.equipment.domain.validator

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.DataType

@Component
class BooleanValueValidator : InputValueValidator {
    override fun validate(
        minValue: String,
        maxValue: String,
        defaultValue: String
    ): Either<InputValueError, Unit> {
        return when (defaultValue) {
            "0" -> Unit.right()
            "1" -> Unit.right()
            else -> InputValueError.InvalidInputValueFormat.left()
        }
    }

    override fun getDataType() = DataType.BOOLEAN
}