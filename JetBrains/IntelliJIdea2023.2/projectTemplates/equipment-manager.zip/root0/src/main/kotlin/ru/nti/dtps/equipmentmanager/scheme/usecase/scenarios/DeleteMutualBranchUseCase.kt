package ru.nti.dtps.equipmentmanager.scheme.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemePersister
import ru.nti.dtps.equipmentmanager.scheme.rest.DeleteBranchCommand
import ru.nti.dtps.equipmentmanager.scheme.usecase.DeleteBranchUseCaseError
import ru.nti.dtps.equipmentmanager.scheme.usecase.DeleteMutualBranch

@Component
class DeleteMutualBranchUseCase(
    private val schemeExtractor: SchemeExtractor,
    private val schemePersister: SchemePersister
) : DeleteMutualBranch {
    override fun execute(
        equipmentId: EquipmentId,
        deleteBranchCommand: DeleteBranchCommand
    ): Either<DeleteBranchUseCaseError, Unit> {
        val scheme = schemeExtractor.getById(equipmentId.toUUID())
            ?: return DeleteBranchUseCaseError.SchemeNotFoundError.left()
        scheme.deleteMutualBranch(deleteBranchCommand.id).mapLeft {
            return DeleteBranchUseCaseError.MutualBranchNotFoundError(it.message).left()
        }
        schemePersister.update(scheme)
        return Unit.right()
    }
}