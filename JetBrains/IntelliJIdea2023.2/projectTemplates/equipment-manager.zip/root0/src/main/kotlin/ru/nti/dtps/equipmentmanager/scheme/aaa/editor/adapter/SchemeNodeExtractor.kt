package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeNode
import java.util.*

interface SchemeNodeExtractor {
    fun extract(equipmentId: EquipmentId, nodeId: UUID): SchemeNode?
}