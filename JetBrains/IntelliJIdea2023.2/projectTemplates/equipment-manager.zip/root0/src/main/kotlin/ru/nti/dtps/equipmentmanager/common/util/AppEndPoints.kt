package ru.nti.dtps.equipmentmanager.common.util

const val API_V1 = "/api/equipment/v1"
const val API_V1_EQUIPMENTS_INFO = "#[[\$]]#API_V1/info"
const val API_V1_EQUIPMENT = "#[[\$]]#API_V1/equipment"
const val API_V1_EQUIPMENT_PARAMETERS = "#[[\$]]#API_V1/equipment/parameters"
const val API_V1_EQUIPMENT_VARIABLES = "#[[\$]]#API_V1/equipment/variables"
const val API_V1_EQUIPMENT_INPUTS = "#[[\$]]#API_V1/equipment/inputs"
const val API_V1_EQUIPMENT_OUTPUTS = "#[[\$]]#API_V1/equipment/outputs"
const val API_V1_EQUIPMENT_SVG = "#[[\$]]#API_V1/equipment/svg"
const val API_V1_EQUIPMENT_SIGNALS = "#[[\$]]#API_V1/equipment/signals"

const val API_V1_EQUIPMENT_GROUP = "#[[\$]]#API_V1/equipment/group"
const val API_V1_PARAMETER_GROUP = "#[[\$]]#API_V1/parameter/group"

const val API_V1_SCHEME_COMMAND = "#[[\$]]#API_V1/scheme/command"
const val API_V1_SCHEME_MUTUALITY = "#[[\$]]#API_V1/scheme/mutuality"
const val API_V1_SCHEME_VALIDATE = "#[[\$]]#API_V1/scheme/validate"
const val API_V1_SCHEME_INFO = "#[[\$]]#API_V1/scheme/info"