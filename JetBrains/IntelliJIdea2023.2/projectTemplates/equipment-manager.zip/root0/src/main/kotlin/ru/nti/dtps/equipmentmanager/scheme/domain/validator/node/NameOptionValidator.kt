package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError

@Component
class NameOptionValidator {
    companion object {
        fun validate(
            node: PrimitiveEquipment
        ): Either<SchemeValidationError, Unit> {
            return if (node.name.isBlank()) {
                PrimitiveEquipmentDoesNotHaveName(node.id).left()
            } else {
                Unit.right()
            }
        }
    }
}

class PrimitiveEquipmentDoesNotHaveName(
    val equipmentId: String
) : SchemeValidationError
