package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.ChangeSchemeNodeEditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.EditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeNode
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeNodeExtractor

@Component
class ChangeNodeCoordsExecutor(
    private val schemeNodeExtractor: SchemeNodeExtractor
) : CommandExecutor<ChangeNodeCoordsUserCommand> {

    private val logger = LoggerFactory.getLogger(ChangeNodeCoordsExecutor::class.java)

    override fun execute(command: ChangeNodeCoordsUserCommand): Either<CommandExecutionError, ChangeNodeCoordsUserCommandSuccessResult> {
        return schemeNodeExtractor.extract(command.equipmentId, command.nodeId)
            ?.let {
                ChangeNodeCoordsUserCommandSuccessResult(it, command).right()
            } ?: NodeNotFoundError(command.nodeId.toString()).left()
    }
}

class ChangeNodeCoordsUserCommandSuccessResult(
    val schemeNode: SchemeNode,
    val command: ChangeNodeCoordsUserCommand
) : CommandSuccessResult {
    override fun undo() = ChangeNodeCoordsUserCommand(
        nodeId = command.nodeId,
        equipmentId = command.equipmentId,
        body = ChangeNodeCoords(
            id = command.nodeId,
            ports = schemeNode.ports,
            coords = schemeNode.coords,
        )
    )

    override fun editorCommands(): List<EditorCommand> {
        return listOf(
            ChangeSchemeNodeEditorCommand.build(command, schemeNode),
        )
    }
}