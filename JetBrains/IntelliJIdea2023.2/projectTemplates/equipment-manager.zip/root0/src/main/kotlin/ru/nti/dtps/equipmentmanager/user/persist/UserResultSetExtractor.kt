package ru.nti.dtps.equipmentmanager.user.persist

import arrow.core.getOrElse
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.UserId
import ru.nti.dtps.equipmentmanager.user.domain.User
import java.sql.ResultSet

class UserResultSetExtractor : ResultSetExtractor<User> {
    override fun extractData(rs: ResultSet): User? {
        return if (rs.next()) {
            UserRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class UserRowMapper : RowMapper<User> {

    private val logger = LoggerFactory.getLogger(UserRowMapper::class.java)

    override fun mapRow(rs: ResultSet, rowNum: Int): User? {
        val idString = rs.getString("id")
        val companyIdString = rs.getString("company_id")
        val firstName = rs.getString("first_name")
        val lastName = rs.getString("last_name")
        val removed = rs.getBoolean("removed")
        val id = UserId.from(idString).getOrElse {
            logger.error("User has incorrect id #[[\$]]#idString")
            return null
        }
        val companyId = CompanyId.from(companyIdString).getOrElse {
            logger.error("User has incorrect companyId #[[\$]]#companyIdString")
            return null
        }
        return User.restore(
            id = id,
            companyId = companyId,
            firstName = firstName,
            lastName = lastName,
            removed = removed
        )
    }
}