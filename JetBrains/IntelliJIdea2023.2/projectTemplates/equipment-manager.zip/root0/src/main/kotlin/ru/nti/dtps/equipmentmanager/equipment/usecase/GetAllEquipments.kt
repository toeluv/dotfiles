package ru.nti.dtps.equipmentmanager.equipment.usecase

import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment

interface GetAllEquipments {
    fun execute(): Collection<Equipment>
}