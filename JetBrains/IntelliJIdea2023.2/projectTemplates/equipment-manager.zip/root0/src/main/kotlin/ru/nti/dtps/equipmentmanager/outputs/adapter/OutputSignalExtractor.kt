package ru.nti.dtps.equipmentmanager.outputs.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.OutputSignalId
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal

interface OutputSignalExtractor {
    fun getById(id: OutputSignalId): OutputSignal?
    fun getAllByEquipmentId(equipmentId: EquipmentId): Collection<OutputSignal>
}