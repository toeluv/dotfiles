package ru.nti.dtps.equipmentmanager.equipment.usecase.scenarios

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import org.springframework.kafka.core.KafkaTemplate
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentFullView
import ru.nti.dtps.equipmentmanager.equipment.kafka.EquipmentEventConverter
import ru.nti.dtps.equipmentmanager.equipment.kafka.EquipmentEventMessage
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentPersister
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.ParameterGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.PublishEquipment
import ru.nti.dtps.equipmentmanager.equipment.usecase.PublishEquipmentUseCaseError
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalExtractor
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalExtractor
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import ru.nti.dtps.equipmentmanager.parameter.adapter.ParameterExtractor
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SignalInfoExtractor
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgExtractor
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SvgInfoExtractor
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserInfoProvider

@Component
class PublishEquipmentUseCase(
    private val svgExtractor: SvgExtractor,
    private val schemeExtractor: SchemeExtractor,
    private val svgInfoExtractor: SvgInfoExtractor,
    private val equipmentExtractor: EquipmentExtractor,
    private val equipmentPersister: EquipmentPersister,
    private val inputSignalExtractor: InputSignalExtractor,
    private val outputSignalExtractor: OutputSignalExtractor,
    private val equipmentParameterExtractor: ParameterExtractor,
    private val signalInfoExtractor: SignalInfoExtractor,
    private val userInfoProvider: CurrentUserInfoProvider,
    private val parameterGroupExtractor: ParameterGroupExtractor,
    private val kafkaTemplate: KafkaTemplate<String, EquipmentEventMessage>
) : PublishEquipment {

    //TODO: check algorithm code compiled
    override fun execute(equipmentId: EquipmentId): Either<PublishEquipmentUseCaseError, Unit> {
        val equipment = equipmentExtractor.getById(equipmentId)
            ?: return PublishEquipmentUseCaseError.EquipmentNotFoundError.left()

        val equipmentFullView = equipment.buildEquipmentFullView(
            equipmentParameterExtractor.getAllByEquipmentId(equipment.id).toSet(),
            inputSignalExtractor.getAllByEquipmentId(equipment.id).toSet(),
            outputSignalExtractor.getAllByEquipmentId(equipment.id).toSet()
        )

        val svg = svgExtractor.getById(equipmentId.toUUID())
            ?: return PublishEquipmentUseCaseError.SvgNotFoundError.left()
        val svgInfo = svgInfoExtractor.getById(equipmentId.toUUID())
            ?: return PublishEquipmentUseCaseError.SvgNotFoundError.left()
        val signalInfo = signalInfoExtractor.getById(equipmentId.toUUID())
            ?: return PublishEquipmentUseCaseError.SvgNotFoundError.left()
        val parameterGroups = parameterGroupExtractor.getAllParameterGroupsByCompanyId(equipment.companyId).toList()
        val scheme = schemeExtractor.getById(equipment.id.toUUID())
            ?: return PublishEquipmentUseCaseError.SchemeNotFoundError.left()

        if (!scheme.isValid) {
            return PublishEquipmentUseCaseError.SchemeNotValidError.left()
        }

        val equipmentMessage = EquipmentEventConverter.toEvent(
            equipmentFullView,
            svg,
            svgInfo,
            signalInfo,
            parameterGroups,
            scheme
        ).getOrElse { return it.left() }
        val sendDefault = kafkaTemplate.sendDefault(equipment.id.toStringValue(), equipmentMessage)
        sendDefault.get()

        equipment.publish(userInfoProvider.get())
        return equipmentPersister.save(equipment).right()
    }

    private fun Equipment.buildEquipmentFullView(
        parameters: Set<Parameter>,
        inputSignals: Set<InputSignal>,
        outputSignals: Set<OutputSignal>
    ): EquipmentFullView {

        return EquipmentFullView.restore(
            id = this.id,
            companyId = this.companyId,
            name = this.name,
            groupId = this.groupId,
            description = this.description,
            author = this.author,
            createdAt = this.createdAt,
            publicationInfo = this.publicationInfo,
            published = this.published,
            version = this.version,
            editor = this.editor,
            updatedAt = this.updatedAt,
            parameters = parameters,
            inputSignals = inputSignals,
            outputSignals = outputSignals,
            userVariables = setOf()
        )
    }
}
