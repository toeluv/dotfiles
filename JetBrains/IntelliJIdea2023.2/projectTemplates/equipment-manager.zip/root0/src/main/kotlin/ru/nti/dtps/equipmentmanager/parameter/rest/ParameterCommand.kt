package ru.nti.dtps.equipmentmanager.parameter.rest

import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.types.ParameterName

data class CreateParameterCommand(
    val id: ParameterId,
    val equipmentId: EquipmentId,
    val name: ParameterName,
    val groupId: String,
    val unitType: UnitType,
    val dataType: DataType,
    val minValue: String,
    val maxValue: String,
    val defaultValue: String,
    val variableName: VariableName
)

data class UpdateParameterCommand(
    val id: ParameterId,
    val equipmentId: EquipmentId,
    val name: ParameterName,
    val groupId: String,
    val unitType: UnitType,
    val dataType: DataType,
    val minValue: String,
    val maxValue: String,
    val defaultValue: String,
    val variableName: VariableName
)

data class DeleteParameterCommand(
    val id: ParameterId
)