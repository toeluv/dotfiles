package ru.nti.dtps.equipmentmanager.equipment.usecase

interface GetEquipmentsInfo {
    fun execute(): EquipmentsInfo
}

data class EquipmentsInfo(
    val equipmentsWithGroups: List<EquipmentInfoView>,
    val equipmentsWithoutGroups: List<EquipmentInfoView>
) {
    data class EquipmentInfoView(
        val id: String,
        val name: String,
        val group: String?
    )
}