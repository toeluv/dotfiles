package ru.nti.dtps.equipmentmanager.equipment.rest

import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.equipment.usecase.GetEquipmentsInfo

@RestController
class GetEquipmentsInfoEndpoint(
    private val getEquipmentsInfo: GetEquipmentsInfo
) {

    @GetMapping(API_V1_EQUIPMENTS_INFO)
    fun getInfo(): ResponseEntity<*> {
        return ok(getEquipmentsInfo.execute())
    }
}