package ru.nti.dtps.equipmentmanager.equipment.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.common.util.API_V1_EQUIPMENT
import ru.nti.dtps.equipmentmanager.common.util.GlobalErrorHandler
import ru.nti.dtps.equipmentmanager.equipment.rest.request.CreateEquipmentRequest
import ru.nti.dtps.equipmentmanager.equipment.usecase.CreateEquipment
import ru.nti.dtps.equipmentmanager.equipment.usecase.CreateEquipmentUseCaseError

@RestController
class CreateEquipmentEndpoint(
    private val createEquipment: CreateEquipment,
    private val messageSource: MessageSourceService
) {

    @Operation(summary = "Create new equipment")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Equipment created", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = EquipmentShortView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "403", description = "Current user is not presented in DTPS Platform", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409", description = "Equipment with current name is already exist", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )]
    )
    @PostMapping(API_V1_EQUIPMENT)
    fun create(@RequestBody createEquipmentRequest: CreateEquipmentRequest): ResponseEntity<*> {
        return createEquipmentRequest.buildCommand().fold(
            { it.toRestError() },
            {
                createEquipment.execute(it)
                    .fold(
                        { useCaseError -> useCaseError.toRestError() },
                        { equipment -> ok(equipment.toShortView()) }
                    )
            }
        )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun CreateEquipmentUseCaseError.toRestError() =
        when (this) {
            is CreateEquipmentUseCaseError.EquipmentNameAlreadyExistUseCaseError ->
                restBusinessError(
                    messageSource.getMessage("api.equipment.error.validation.twins")
                        .format(name),
                    HttpStatus.CONFLICT
                )
        }
}
