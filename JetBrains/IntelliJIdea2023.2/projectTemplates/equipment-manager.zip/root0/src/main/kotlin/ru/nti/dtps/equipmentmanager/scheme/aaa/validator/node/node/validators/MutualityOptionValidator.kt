package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.validators

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.MutualBranchId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.MutualBranch
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.MutualBranchExtractor
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.BusinessNodeValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeToValidate
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId
import java.util.*

@Component
class MutualityOptionValidator(
    private val mutualBranchExtractor: MutualBranchExtractor
) : BusinessNodeValidator {

    private val variableNameKeySelector = OptionLibId.MUTUALITY

    override fun order() = 2

    override fun validate(node: NodeToValidate): Either<NodeValidationError, Unit> {
        node.options()[variableNameKeySelector]?.let { idsStringValue ->
            val ids = parseIds(idsStringValue) ?: return InvalidFiledTypeValidationError(
                node.id(),
                node.equipmentId(),
                variableNameKeySelector
            ).left()
            mutualBranchExtractor.extract(ids).forEach {
                if (!it.isMatchWithNode(node)) {
                    return MutualityOptionIsNotValidError(node.id(), node.equipmentId(), it.id).left()
                }
            }
        }
        return Unit.right()
    }

    private fun parseIds(filed: String): List<MutualBranchId>? {
        return try {
            filed.split(",").toList().map { UUID.fromString(it) }.map { MutualBranchId(it) }
        } catch (ex: IllegalArgumentException) {
            null
        }
    }

    private fun MutualBranch.isMatchWithNode(node: NodeToValidate): Boolean {
        //TODO it was more statements to validate
        return this.elementType == node.type()
    }


}

class MutualityOptionIsNotValidError(val id: UUID, val equipmentId: EquipmentId, val mutualityId: MutualBranchId) :
    NodeValidationError
