package ru.nti.dtps.equipmentmanager.scheme.usecase.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.MutualBranch
import ru.nti.dtps.equipmentmanager.scheme.domain.MutualBranchError
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.branch.MutualBranchVariableValidator
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemePersister
import ru.nti.dtps.equipmentmanager.scheme.rest.UpdateBranchCommand
import ru.nti.dtps.equipmentmanager.scheme.usecase.UpdateBranchUseCaseError
import ru.nti.dtps.equipmentmanager.scheme.usecase.UpdateMutualBranch

@Component
class UpdateMutualBranchUseCase(
    private val schemeExtractor: SchemeExtractor,
    private val schemePersister: SchemePersister,
    private val branchVariableValidator: MutualBranchVariableValidator
) : UpdateMutualBranch {
    override fun execute(updateBranchCommand: UpdateBranchCommand): Either<UpdateBranchUseCaseError, MutualBranch> {
        val scheme = schemeExtractor.getById(updateBranchCommand.equipmentId.toUUID())
            ?: return UpdateBranchUseCaseError.SchemeNotFoundError.left()
        return scheme.updateMutualBranch(updateBranchCommand, branchVariableValidator)
            .fold(
                { it.toUseCaseError().left() },
                { it.also { schemePersister.update(scheme) }.right() }
            )
    }

    private fun MutualBranchError.toUseCaseError() = when (this) {
        is MutualBranchError.VariableNameIsNotValidOrUniqueError ->
            UpdateBranchUseCaseError.VariableNameAlreadyExistsError(message)

        is MutualBranchError.MutualBranchNotFound -> UpdateBranchUseCaseError.MutualBranchNotFoundError(message)
    }
}