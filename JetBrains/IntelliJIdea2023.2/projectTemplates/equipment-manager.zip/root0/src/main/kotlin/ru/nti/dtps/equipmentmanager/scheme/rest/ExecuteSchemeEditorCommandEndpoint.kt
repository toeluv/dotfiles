package ru.nti.dtps.equipmentmanager.scheme.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.validated
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.scheme.usecase.ExecuteSchemeEditorCommand
import ru.nti.dtps.equipmentmanager.common.util.API_V1_SCHEME_COMMAND
import ru.nti.dtps.equipmentmanager.user.usecase.access.GetUserIdFromContext
import ru.nti.dtps.equipmentmanager.scheme.usecase.scenarios.CommandExecutionError

@RestController
class ExecuteSchemeEditorCommandEndpoint(
    private val messageSource: MessageSourceService,
    private val getUserIdFromContext: GetUserIdFromContext,
    private val executeSchemeEditorCommand: ExecuteSchemeEditorCommand
) {

    @Operation(summary = "Execute scheme editor command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "Scheme was edited", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = SchemeShortView::class)
                    ))]
            ),
            ApiResponse(responseCode = "400", description = "Unsupported request fields",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Link with current id is already exist",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Primitive equipment does not exist",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Link does not exist",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "400", description = "Primitive equipment with current name is already exist",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "400",
                description = "Options field(-s) for this primitive equipment is not valid",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "400",
                description = "Primitive ports count is more then limit",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "400",
                description = "Primitive equipment option \"Variable name\" has not unique value",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "404", description = "Scheme not found",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(responseCode = "500", description = "Something went wrong, go to admin",content = [
                (Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                ))])
        ]
    )
    @PostMapping("#[[\$]]#API_V1_SCHEME_COMMAND/{equipmentId}")
    fun executeCommand(
        @PathVariable equipmentId: String,
        @RequestBody commandRequest: CommandBatchRequestDto
    ): ResponseEntity<*> {
        val userId = getUserIdFromContext.get()

        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    commandRequest.toDomainCommand(validEquipmentId, userId)
                        .let { command ->
                            executeSchemeEditorCommand.execute(command)
                        }
                        .fold(
                            { error -> error.toRestError() },
                            { ok(Unit) }
                        )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun CommandExecutionError.toRestError() =
        when (this) {
            is CommandExecutionError.LinkWithIdAlreadyPresented ->
                restBusinessError(
                    messageSource.getMessage("api.scheme.command.error.base-execution-error"),
                    HttpStatus.BAD_REQUEST
                )

            is CommandExecutionError.PrimitiveEquipmentDoesNotExistError ->
                restBusinessError(
                    messageSource.getMessage("api.scheme.command.error.base-execution-error"),
                    HttpStatus.BAD_REQUEST
                )

            is CommandExecutionError.LinkDoesNotExistError ->
                restBusinessError(
                    messageSource.getMessage("api.scheme.command.error.base-execution-error"),
                    HttpStatus.BAD_REQUEST
                )

            is CommandExecutionError.PrimitiveEquipmentWithPresentedNameAlreadyExist ->
                restBusinessError(
                    messageSource
                        .getMessage("api.scheme.error.equipment-name.twins")
                        .format(name),
                    HttpStatus.BAD_REQUEST
                )

            is CommandExecutionError.SchemeAlreadyContainsMaxCountPrimitivePortError ->
                restBusinessError(
                    messageSource.getMessage("api.scheme.validation.error.ports.number")
                        .format(allowedPrimitivePortNumber, currentPrimitivePortNumber),
                    HttpStatus.BAD_REQUEST
                )

            is CommandExecutionError.VariableNameOptionIsNotValidError ->
                restBusinessError(
                    messageSource.getMessage("api.scheme.error.equipment.variable.name.twins")
                        .format(value),
                    HttpStatus.BAD_REQUEST
                )

            is CommandExecutionError.RequiredFieldNotFoundError ->
                restBusinessError(
                    messageSource.getMessage("api.scheme.validation.error.field-value.not-found")
                        .format(equipmentName, optionLibId.name),
                    HttpStatus.BAD_REQUEST
                )

            is CommandExecutionError.MutualityOptionIsNotValidError ->
                restBusinessError(
                    messageSource.getMessage("api.scheme.validation.error.field.mutuality.not.same.type")
                        .format(equipmentName),
                    HttpStatus.BAD_REQUEST
                )

            is CommandExecutionError.PrimitiveEquipmentOptionsValidationError ->
                restBusinessError(
                    validationError.toRestError(messageSource).message,
                    HttpStatus.BAD_REQUEST
                )

            is CommandExecutionError.SchemeNotExistError ->
                restBusinessError(
                    messageSource.getMessage("api.scheme.error.not-found"),
                    HttpStatus.NOT_FOUND
                )
        }
}