package ru.nti.dtps.equipmentmanager.scheme.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.domain.MutualBranch

interface GetMutualBranches {
    fun execute(equipmentId: EquipmentId): Either<GetAllBranchesUseCaseError, List<MutualBranch>>
}

sealed class GetAllBranchesUseCaseError {
    object SchemeNotFoundError: GetAllBranchesUseCaseError()
}