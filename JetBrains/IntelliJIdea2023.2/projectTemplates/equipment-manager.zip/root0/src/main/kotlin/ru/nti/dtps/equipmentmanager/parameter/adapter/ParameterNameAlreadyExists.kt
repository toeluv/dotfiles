package ru.nti.dtps.equipmentmanager.parameter.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.ParameterId
import ru.nti.dtps.equipmentmanager.common.types.ParameterName

interface ParameterNameAlreadyExists {
    operator fun invoke(equipmentId: EquipmentId, parameterName: ParameterName): Boolean
    operator fun invoke(equipmentId: EquipmentId, parameterName: ParameterName, excludedParameterId: ParameterId): Boolean
}

