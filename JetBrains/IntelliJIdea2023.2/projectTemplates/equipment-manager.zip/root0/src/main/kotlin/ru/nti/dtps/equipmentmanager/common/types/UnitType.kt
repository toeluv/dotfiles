package ru.nti.dtps.equipmentmanager.common.types

enum class UnitType {
    AMPERE,
    VOLT,
    SIEMENS,
    HERTZ,
    RADIAN,
    SECOND,
    OHM,
    FARAD,
    METRE,
    WATT,
    VAR,
    DEGREE,
    VOLT_AMPERE,
    RELATIVE_UNIT,
    PERCENT,
    AMPERE_HOUR,
    ELECTRON_VOLT,
    KILOWATT_HOUR,
    BAR,
    WEBER,
    TESLA,
    AMPERE_PER_METRE,
    VOLT_PER_METRE,
    CALCULUS,
    PASCAL,
    KELVIN
}

fun UnitType.toUnit() = when (this) {
    UnitType.AMPERE -> "А"
    UnitType.VOLT -> "В"
    UnitType.SIEMENS -> "См"
    UnitType.HERTZ -> "Гц"
    UnitType.RADIAN -> "рад"
    UnitType.SECOND -> "с"
    UnitType.OHM -> "Ом"
    UnitType.FARAD -> "Ф"
    UnitType.METRE -> "м"
    UnitType.WATT -> "Вт"
    UnitType.VAR -> "вар"
    UnitType.DEGREE -> "°"
    UnitType.VOLT_AMPERE -> "В·А"
    UnitType.RELATIVE_UNIT -> "о.е."
    UnitType.PERCENT -> "%"
    UnitType.AMPERE_HOUR -> "А·ч"
    UnitType.ELECTRON_VOLT -> "эВ"
    UnitType.KILOWATT_HOUR -> "кВт·ч"
    UnitType.BAR -> "бар"
    UnitType.WEBER -> "Вб"
    UnitType.TESLA -> "Тл"
    UnitType.AMPERE_PER_METRE -> "А/м"
    UnitType.VOLT_PER_METRE -> "В/м"
    UnitType.CALCULUS -> ""
    UnitType.PASCAL -> "Па"
    UnitType.KELVIN -> "К"
}