package ru.nti.dtps.equipmentmanager.user.usecase.scenarios

import arrow.core.Either
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import ru.nti.dtps.equipmentmanager.user.domain.User
import ru.nti.dtps.equipmentmanager.user.domain.command.UpdatedUserCommand
import ru.nti.dtps.equipmentmanager.user.persist.adapter.UserExtractor
import ru.nti.dtps.equipmentmanager.user.persist.adapter.UserPersister
import ru.nti.dtps.equipmentmanager.user.usecase.UpdateUser

@Service
class UpdateUserUseCase(
    private val userPersister: UserPersister,
    private val userExtractor: UserExtractor
) : UpdateUser {

    private val logger = LoggerFactory.getLogger(javaClass)

    override fun execute(command: UpdatedUserCommand) {
        return Either.catch {
            userExtractor.getById(command.userId)
        }.fold(
            { error -> logger.error("Error update user cause: {}", error.message, error) },
            { user ->
                user?.let {
                    userPersister.update(User.create(it.id, it.companyId, command.firstName, command.lastName))
                    logger.info("User {} was updated", command.userId.toStringValue())
                } ?: userPersister.save(
                    User.create(command.userId, command.companyId, command.firstName, command.lastName)
                )
                logger.info("User {} was created", command.userId.toStringValue())
            }
        )
    }
}
