package ru.nti.dtps.equipmentmanager.scheme.domain.provider

import ru.nti.dtps.equipmentmanager.scheme.domain.FieldTypeId
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment.PrimitiveEquipmentLibId

interface LibInfoExtractor {
    fun getEquipmentLibById(equipmentLibId: PrimitiveEquipmentLibId): EquipmentLib
    fun getFieldTypeLibById(fieldTypeId: FieldTypeId): FieldType
    fun getPrimitivePortSignalInfo(): List<PrimitivePortSignalInfo>
}