package ru.nti.dtps.equipmentmanager.parameter.adapter

import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.ParameterId
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter

interface ParameterExtractor {
    fun getAllByEquipmentId(equipmentId: EquipmentId): Collection<Parameter>
    fun getAllByCompanyId(companyId: CompanyId): Collection<Parameter>

    fun getById(id: ParameterId): Parameter?
}