package ru.nti.dtps.equipmentmanager.svg.domain

data class Dimensions(
    val height: Double = 0.0,
    val width: Double = 0.0
)
