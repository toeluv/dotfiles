package ru.nti.dtps.equipmentmanager.cplus.docker.configuration

import com.github.dockerjava.api.DockerClient
import com.github.dockerjava.core.DefaultDockerClientConfig
import com.github.dockerjava.core.DockerClientBuilder
import com.github.dockerjava.core.DockerClientConfig
import com.github.dockerjava.httpclient5.ApacheDockerHttpClient
import com.github.dockerjava.transport.DockerHttpClient
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Profile
import org.springframework.util.Assert
import ru.nti.dtps.equipmentmanager.common.configuration.PROFILE_DEV
import ru.nti.dtps.equipmentmanager.common.configuration.PROFILE_LOCAL
import ru.nti.dtps.equipmentmanager.common.configuration.PROFILE_PROD
import java.net.URI
import java.time.Duration

@Configuration
class DockerHttpClientConfiguration(
    private val dockerClientProperties: DockerClientProperties
) {

    init {
        Assert.isTrue(
            dockerClientProperties.host.isNotBlank(),
            "Docker client properties must not be blank"
        )
    }

    @Bean
    @Profile(value = [PROFILE_LOCAL])
    fun dockerClientLocal(): DockerClient {
        Assert.isTrue(
            dockerClientProperties.certPath.isNotBlank() &&
                    dockerClientProperties.username.isNotBlank(),
            "Docker client properties local connection to stand need cert and username"
        )
        val dockerClientConfig: DockerClientConfig = DefaultDockerClientConfig.createDefaultConfigBuilder()
            .withDockerHost(dockerClientProperties.host)
            .withDockerCertPath(dockerClientProperties.certPath)
            .withRegistryUsername(dockerClientProperties.username)
            .build()
        val httpClient: DockerHttpClient = ApacheDockerHttpClient.Builder()
            .dockerHost(URI(dockerClientProperties.host))
            .maxConnections(100)
            .connectionTimeout(Duration.ofSeconds(30))
            .responseTimeout(Duration.ofSeconds(45))
            .build()
        return DockerClientBuilder.getInstance(dockerClientConfig)
            .withDockerHttpClient(httpClient)
            .build()
    }

    @Bean
    @Profile(value = [PROFILE_DEV, PROFILE_PROD])
    fun dockerClientProd(): DockerClient {
        val dockerClientConfig = DefaultDockerClientConfig
            .createDefaultConfigBuilder()
            .withDockerHost(dockerClientProperties.host)
            .build()
        return ApacheDockerHttpClient.Builder()
            .dockerHost(URI(dockerClientProperties.host))
            .maxConnections(100)
            .connectionTimeout(Duration.ofSeconds(30))
            .responseTimeout(Duration.ofSeconds(45))
            .build()
            .let { DockerClientBuilder.getInstance(dockerClientConfig).withDockerHttpClient(it).build() }
    }


}
