package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.rest.groups.DeleteParameterGroupCommand

interface DeleteParameterGroup {
    fun execute(command: DeleteParameterGroupCommand): Either<DeleteParameterGroupUseCaseError, ParameterGroup>
}

sealed class DeleteParameterGroupUseCaseError : UseCaseError {
    object ParameterGroupNotExistUseCaseError : DeleteParameterGroupUseCaseError()
    object ParameterGroupIsNotEmptyUseCaseError : DeleteParameterGroupUseCaseError()
}