package ru.nti.dtps.equipmentmanager.scheme.aaa.editor


import ru.nti.dtps.proto.scheme.link.EquipmentLink
import java.util.*

class SchemeLink(
    val id: UUID,
    val parentId: UUID,
    val alignmentType: EquipmentLink.AlignmentType = EquipmentLink.AlignmentType.RECTANGULAR,
    val sourceNode: UUID,
    val targetNode: UUID,
    val sourcePort: UUID,
    val targetPort: UUID,
    val points: List<Point>,
)

data class Port(
    val id: UUID,
    val coords: XyCoords,
    val parentNode: UUID,
    val alignment: Alignment,
    val links: List<UUID>,
    val libId: PortLibId,
    val points: MutableList<Point> = mutableListOf(),
    val payload: Map<String, String>
)

data class Point(
    val id: UUID,
    val coords: XyCoords
)



enum class PortLibId {
    FIRST,
    SECOND,
    THIRD,
    FOURTH
}

enum class Alignment {
    TOP,
    BOTTOM,
    RIGHT,
    LEFT
}
