package ru.nti.dtps.equipmentmanager.equipment.usecase.access

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentName
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.EquipmentNameAlreadyExists
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class CheckEquipmentNameExists(
    private val equipmentExtractor: EquipmentExtractor,
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider
) : EquipmentNameAlreadyExists {
    override fun invoke(equipmentName: EquipmentName, equipmentGroupId: String?): Boolean {
        return equipmentExtractor.checkEquipmentNameExists(
            equipmentName,
            currentUserCompanyIdProvider.get(),
            equipmentGroupId
        )
    }
}