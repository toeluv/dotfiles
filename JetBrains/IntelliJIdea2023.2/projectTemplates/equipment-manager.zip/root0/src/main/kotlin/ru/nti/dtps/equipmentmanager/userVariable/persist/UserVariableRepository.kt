package ru.nti.dtps.equipmentmanager.userVariable.persist

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserVariableId
import ru.nti.dtps.equipmentmanager.userVariable.adapter.UserVariableExtractor
import ru.nti.dtps.equipmentmanager.userVariable.adapter.UserVariablePersister
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable
import javax.sql.DataSource

@Component
class UserVariableRepository(
    dataSource: DataSource
) : UserVariableExtractor, UserVariablePersister {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    override fun getAllByEquipmentId(equipmentId: EquipmentId): Collection<UserVariable> {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.user_variable
            WHERE equipment_id = :equipment_id 
            """.trimMargin(),
            mapOf("equipment_id" to equipmentId.toUUID()),
            UserVariableRowMapper()
        ).toSet()
    }

    override fun getById(id: UserVariableId): UserVariable? {
        return jdbcTemplate.query(
            """
            SELECT * FROM public.user_variable
            WHERE id = :id
            """.trimMargin(),
            mapOf("id" to id.toUUID()),
            UserVariableResultSetExtractor()
        )
    }

    @Transactional
    override fun save(userVariable: UserVariable) {
        val params = mapOf(
            "id" to userVariable.id.toUUID(),
            "equipment_id" to userVariable.equipmentId.toUUID(),
            "variable_name" to userVariable.variableName.toStringValue(),
            "data_type" to userVariable.dataType.name
        )
        jdbcTemplate.update(
            """
            INSERT INTO public.user_variable(id, equipment_id, variable_name, data_type)
            VALUES(
            :id, 
            :equipment_id,
            :variable_name,
            :data_type
            )
            """.trimMargin(), params
        )
    }

    @Transactional
    override fun update(userVariable: UserVariable) {
        val params = mapOf(
            "id" to userVariable.id.toUUID(),
            "variable_name" to userVariable.variableName.toStringValue(),
            "data_type" to userVariable.dataType.name
        )
        jdbcTemplate.update(
            """
            UPDATE public.user_variable SET
            variable_name = :variable_name,
            data_type = :data_type
            WHERE id = :id
            """.trimIndent(), params
        )

    }

    override fun delete(id: UserVariableId) {
        jdbcTemplate.update(
            "DELETE from public.user_variable WHERE id = :id",
            mapOf("id" to id.toUUID())
        )
    }

    override fun deleteAllByEquipmentId(equipmentId: EquipmentId) {
        jdbcTemplate.update(
            "DELETE from public.user_variable WHERE equipment_id = :equipment_id",
            mapOf("equipment_id" to equipmentId.toUUID())
        )
    }
}
