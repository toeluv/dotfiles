package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup

interface GetParameterGroupById {
    fun execute(groupId: String): Either<GetParameterGroupByIdUseCaseError, ParameterGroup>
}

sealed class GetParameterGroupByIdUseCaseError: UseCaseError {
    object ParameterGroupNotExistsUseCaseError : GetParameterGroupByIdUseCaseError()
}
