package ru.nti.dtps.equipmentmanager.minio.rest

import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile
import ru.nti.dtps.equipmentmanager.common.util.ok
import ru.nti.dtps.equipmentmanager.common.util.restBusinessError
import ru.nti.dtps.equipmentmanager.minio.adapter.MinioApi
import ru.nti.dtps.equipmentmanager.minio.adapter.SchemeFile


/*
* raw minio demo w/o usecases and error handling
*
* rest endpoints are need for test (will be deleted)
* */


private const val DEFAULT_CONTENT_TYPE = "application/octet-stream"

@RestController
@RequestMapping("/minio/bucket")
class MinioController(
    private val minioApi: MinioApi
) {

    @PostMapping
    fun create(@RequestParam("bucketName") bucketName: String) {
        minioApi.createBucket(bucketName)
    }

    @PostMapping("/{bucketName}")
    fun upload(@PathVariable bucketName: String, @RequestParam file: MultipartFile): ResponseEntity<*> {
        return minioApi.uploadFile(bucketName, file.toSchemeFile())
            .fold(
                { restBusinessError(it.toString(), HttpStatus.BAD_REQUEST) },
                { ok(it) }
            )
    }

    @PostMapping("/{bucketName}/folder")
    fun uploadFromFolder(@PathVariable bucketName: String, @RequestParam fileName: String): ResponseEntity<*> {
        return minioApi.uploadFileFromSourceFolder(bucketName, fileName)
            .fold(
                { restBusinessError(it.toString(), HttpStatus.BAD_REQUEST) },
                { ok(it) }
            )
    }

    @GetMapping("/{bucketName}")
    fun download(
        @PathVariable bucketName: String,
        @RequestParam fileName: String
    ): ResponseEntity<*> {
        return minioApi.downloadFile(bucketName, fileName)
            .fold(
                { restBusinessError(it.toString(), HttpStatus.BAD_REQUEST) },
                {
                    it.toResponse()
                }
            )
    }

    @GetMapping("/{bucketName}/folder")
    fun downloadToFolder(
        @PathVariable bucketName: String,
        @RequestParam fileName: String
    ): ResponseEntity<*> {
        return minioApi.downloadFileToSourceFolder(bucketName, fileName)
            .fold(
                { restBusinessError(it.toString(), HttpStatus.BAD_REQUEST) },
                { ok(it) }
            )
    }

    @DeleteMapping("/{bucketName}")
    fun delete(@PathVariable bucketName: String, @RequestParam fileName: String): ResponseEntity<*> {
        return minioApi.deleteFile(bucketName, fileName)
            .fold(
                { restBusinessError(it.toString(), HttpStatus.BAD_REQUEST) },
                { ok(it) }
            )
    }
}

private fun SchemeFile.toResponse() = ResponseEntity(
    content,
    HttpHeaders().also { headers ->
        headers["Content-Type"] = contentType
        headers.setContentDispositionFormData(name, name)
    },
    HttpStatus.OK
)

private fun MultipartFile.toSchemeFile() = SchemeFile(
    originalFilename ?: name,
    contentType ?: DEFAULT_CONTENT_TYPE,
    bytes
)