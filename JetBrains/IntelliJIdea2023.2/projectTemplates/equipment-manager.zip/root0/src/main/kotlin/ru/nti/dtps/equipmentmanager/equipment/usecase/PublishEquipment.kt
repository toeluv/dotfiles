package ru.nti.dtps.equipmentmanager.equipment.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId

interface PublishEquipment {
    fun execute(equipmentId: EquipmentId): Either<PublishEquipmentUseCaseError, Unit>
}

sealed class PublishEquipmentUseCaseError {
    object SvgNotFoundError : PublishEquipmentUseCaseError()
    object AlgorithmCodeNotFoundError : PublishEquipmentUseCaseError()
    object EquipmentNotFoundError : PublishEquipmentUseCaseError()
    object SchemeNotFoundError : PublishEquipmentUseCaseError()
    object SchemeNotValidError : PublishEquipmentUseCaseError()
    object PublishEquipmentError : PublishEquipmentUseCaseError()
}