package ru.nti.dtps.equipmentmanager.scheme.usecase.access

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.scheme.domain.OptionLibId
import ru.nti.dtps.equipmentmanager.scheme.persist.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.scheme.usecase.VariableNameOnSchemeAlreadyExist

@Component
class CheckVariableNameOnSchemeAlreadyExist(
    private val schemeExtractor: SchemeExtractor
) : VariableNameOnSchemeAlreadyExist {
    override fun invoke(variableName: VariableName, equipmentId: EquipmentId): Boolean {
        val scheme = schemeExtractor.getById(equipmentId.toUUID()) ?: return false
        val variableNamesFromScheme = scheme.primitiveNodes.values
            .flatMap { primitiveEquipment ->
                primitiveEquipment.options.filter { it.key == OptionLibId.VARIABLE_NAME }.values
            }
            .plus(scheme.mutualBranches.map { it.variableName.toStringValue() })
            .toSet()
        return variableNamesFromScheme.contains(variableName.name)
    }
}