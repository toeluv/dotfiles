package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.NodeOptions
import ru.nti.dtps.equipmentmanager.scheme.domain.OptionLibId
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.OptionLib
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError

@Component
class RequiredOptionExistAndItsValueValidator {
    companion object {
        fun validate(
            equipment: PrimitiveEquipment,
            optionLib: OptionLib
        ): Either<SchemeValidationError, String?> {
            val optionValueString = equipment.getOptionValueOrNull(optionLib.id)
            return if (optionValueString.isNullOrBlank() && !optionLib.optional) {
                RequiredFieldNotFoundError(
                    equipment.id,
                    equipment.name,
                    optionLib
                ).left()
            } else {
                optionValueString.right()
            }
        }

        fun validate(
            nodeOptions: NodeOptions,
            optionLib: OptionLib
        ): Either<SchemeValidationError, String?> {
            val optionValueString = nodeOptions.options[optionLib.id]
            return if (optionValueString.isNullOrBlank() && !optionLib.optional) {
                RequiredFieldNotFoundError(
                    nodeOptions.id.toString(),
                    nodeOptions.options[OptionLibId.NAME].toString(),
                    optionLib
                ).left()
            } else {
                optionValueString.right()
            }
        }
    }

}

class RequiredFieldNotFoundError(
    val equipmentId: String,
    val equipmentName: String,
    val optionLib: OptionLib,
) : SchemeValidationError
