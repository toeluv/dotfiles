package ru.nti.dtps.equipmentmanager.equipment.domain.command

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentName

class CreateEquipmentCommand(
    val id: EquipmentId,
    val name: EquipmentName,
    val groupId: String?,
    val description: String?
)

class UpdateEquipmentCommand(
    val id: EquipmentId,
    val name: EquipmentName,
    val groupId: String?,
    val description: String?
)

class DeleteEquipmentCommand(
    val id: EquipmentId
)
