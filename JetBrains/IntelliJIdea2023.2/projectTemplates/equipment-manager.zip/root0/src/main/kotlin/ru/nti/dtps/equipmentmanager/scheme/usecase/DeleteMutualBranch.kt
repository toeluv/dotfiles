package ru.nti.dtps.equipmentmanager.scheme.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.rest.DeleteBranchCommand

interface DeleteMutualBranch {
    fun execute(equipmentId: EquipmentId, deleteBranchCommand: DeleteBranchCommand): Either<DeleteBranchUseCaseError, Unit>
}

sealed class DeleteBranchUseCaseError {
    object SchemeNotFoundError: DeleteBranchUseCaseError()
    class MutualBranchNotFoundError(val value: String): DeleteBranchUseCaseError()
}