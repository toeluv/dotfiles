package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.scenarios

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.ParameterGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.GetAllParameterGroups
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class GetAllParameterGroupsUseCase(
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider,
    private val parameterGroupExtractor: ParameterGroupExtractor
) : GetAllParameterGroups {
    override fun execute(): Collection<ParameterGroup> {
        return parameterGroupExtractor.getAllParameterGroupsByCompanyId(
            currentUserCompanyIdProvider.get()
        )
    }
}