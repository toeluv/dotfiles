package ru.nti.dtps.equipmentmanager.svg.usecase.scenarios

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.svg.domain.SignalInfo
import ru.nti.dtps.equipmentmanager.svg.persist.adapter.SignalInfoExtractor
import ru.nti.dtps.equipmentmanager.svg.usecase.GetSignalsInfoByEquipment

@Component
class GetSignalsInfoByEquipmentUseCase(
    private val signalInfoExtractor: SignalInfoExtractor
) : GetSignalsInfoByEquipment {
    override fun execute(equipmentId: EquipmentId): List<SignalInfo> {
        return signalInfoExtractor.getById(equipmentId.id)?.let {
            (it.signalsFromMeas + it.signalsFromScheme)
        } ?: listOf()
    }
}
