package ru.nti.dtps.equipmentmanager.scheme.domain.validator.branch

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.scheme.domain.MutualBranchError
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme

interface MutualBranchVariableValidator {
    fun validate(mutualBranchName: VariableName, scheme: Scheme): Either<MutualBranchError, Unit>
}