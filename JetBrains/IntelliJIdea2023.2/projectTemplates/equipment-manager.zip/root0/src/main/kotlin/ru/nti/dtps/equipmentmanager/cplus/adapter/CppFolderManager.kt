package ru.nti.dtps.equipmentmanager.cplus.adapter

import org.springframework.stereotype.Component
import java.io.File

private const val ROOT_FOLDER = "cpp"

@Component
class CppFolderManager {

    init {
        File(ROOT_FOLDER).let { root ->
            if (!root.exists()) {
                root.mkdirs()
            }
        }
    }

    fun createFolderIfNotExists(folderName: String) {
        val folder = File(ROOT_FOLDER, folderName)
        if (!folder.exists()) {
            folder.mkdirs()
        }
    }


    fun deleteFolder(folderName: String) {
        val folder = File(ROOT_FOLDER, folderName)
        if (folder.exists() && folder.isDirectory) {
            folder.deleteRecursively()
        }
    }

    fun getAbsoluteFolderPath(folderName: String): String = File(ROOT_FOLDER, folderName).absolutePath

    fun createFile(folderName: String, fileName: String, payload: ByteArray) {
        val folder = File(ROOT_FOLDER, folderName)
        if (folder.exists() && folder.isDirectory) {
            File(folder, fileName).apply {
                createNewFile()
                writeBytes(payload)
            }
        }
    }
}