package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.NodeOptions
import java.util.*

interface NodeOptionsPersiter {
    fun insert(nodeOptions: NodeOptions)
    fun update(nodeOptions: NodeOptions)
    fun delete(parentId: UUID, id: UUID)
}