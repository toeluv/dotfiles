package ru.nti.dtps.equipmentmanager.equipment.persist.groups

import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import java.sql.ResultSet

class EquipmentGroupResultSetExtractor : ResultSetExtractor<EquipmentGroup> {
    override fun extractData(rs: ResultSet): EquipmentGroup? {
        return if (rs.next()) {
            EquipmentGroupRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class EquipmentGroupRowMapper : RowMapper<EquipmentGroup> {
    override fun mapRow(rs: ResultSet, rowNum: Int): EquipmentGroup {
        val idString = rs.getString("id")
        val companyId = rs.getString("company_id")
        val nameString = rs.getString("name")
        return EquipmentGroup.restore(
            id = idString,
            companyId = companyId,
            name = nameString
        )
    }
}

class ParameterGroupResultSetExtractor : ResultSetExtractor<ParameterGroup> {
    override fun extractData(rs: ResultSet): ParameterGroup? {
        return if (rs.next()) {
            ParameterGroupRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class ParameterGroupRowMapper : RowMapper<ParameterGroup> {
    override fun mapRow(rs: ResultSet, rowNum: Int): ParameterGroup {
        val idString = rs.getString("id")
        val companyIdString = rs.getString("company_id")
        val nameString = rs.getString("name")
        return ParameterGroup.restore(
            id = idString,
            companyId = companyIdString,
            name = nameString
        )
    }
}