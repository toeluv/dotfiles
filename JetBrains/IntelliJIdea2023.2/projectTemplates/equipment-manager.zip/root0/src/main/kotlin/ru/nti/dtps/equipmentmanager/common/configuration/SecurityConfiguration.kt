package ru.nti.dtps.equipmentmanager.common.configuration

import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Profile
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.http.SessionCreationPolicy
import org.springframework.security.oauth2.client.AuthorizedClientServiceOAuth2AuthorizedClientManager
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProviderBuilder
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction
import org.springframework.security.web.SecurityFilterChain
import org.springframework.web.reactive.function.client.WebClient

val OPENAPI_AUTH_WHITELIST = arrayOf(
    "/swagger-resources",
    "/swagger-resources/**",
    "/configuration/ui",
    "/configuration/security",
    "/swagger-ui.html",
    "/webjars/**",
    "/v3/api-docs/**",
    "/api/public/**",
    "/api/public/authenticate",
    "/actuator/*",
    "/swagger-ui/**"
)

@Configuration
@EnableWebSecurity
class SecurityConfiguration(
    @Value("\#[[\$]]#{keycloak.base-url}")
    val baseUrl: String
) {

    @Bean
    @Profile(value = [PROFILE_DEV, PROFILE_PROD])
    fun securityFilterChain(httpSecurity: HttpSecurity): SecurityFilterChain? {
        httpSecurity
            .csrf { it.disable() }
            .cors { it.disable() }
            .authorizeHttpRequests {
                it.requestMatchers(*OPENAPI_AUTH_WHITELIST).permitAll()
                    .anyRequest()
                    .authenticated()
            }
            .sessionManagement { it.sessionCreationPolicy(SessionCreationPolicy.STATELESS) }
            .oauth2ResourceServer { it.jwt {} }
        return httpSecurity.build()
    }

    @Bean
    @Profile(PROFILE_LOCAL)
    fun securityFilterChainUnsecure(httpSecurity: HttpSecurity): SecurityFilterChain? {
        httpSecurity
            .csrf { it.disable() }
            .cors { it.disable() }
            .authorizeHttpRequests {
                it.anyRequest().permitAll()
            }
            .oauth2ResourceServer { it.jwt {} }
        return httpSecurity.build()
    }

    @ConditionalOnProperty(
        name = ["internal.client-enable"],
        havingValue = "true"
    )
    @Bean
    fun authorizedClientManager(
        clientRegistrationRepository: ClientRegistrationRepository?,
        authorizedClientService: OAuth2AuthorizedClientService?
    ): OAuth2AuthorizedClientManager? {
        val authorizedClientProvider = OAuth2AuthorizedClientProviderBuilder.builder()
            .clientCredentials()
            .build()
        val authorizedClientManager = AuthorizedClientServiceOAuth2AuthorizedClientManager(
            clientRegistrationRepository, authorizedClientService
        )
        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider)
        return authorizedClientManager
    }

    @ConditionalOnProperty(
        name = ["internal.client-enable"],
        havingValue = "true"
    )
    @Bean
    fun webClient(authorizedClientManager: OAuth2AuthorizedClientManager?): WebClient? {
        val oauth2 = ServletOAuth2AuthorizedClientExchangeFilterFunction(
            authorizedClientManager
        )
        oauth2.setDefaultOAuth2AuthorizedClient(true)
        oauth2.setDefaultClientRegistrationId("keycloak")
        return WebClient.builder()
            .baseUrl(baseUrl)
            .apply(oauth2.oauth2Configuration())
            .build()
    }
}