package ru.nti.dtps.equipmentmanager.parameter.usecase

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter

interface GetAllParameters {
    fun execute(equipmentId: EquipmentId): List<Parameter>
}