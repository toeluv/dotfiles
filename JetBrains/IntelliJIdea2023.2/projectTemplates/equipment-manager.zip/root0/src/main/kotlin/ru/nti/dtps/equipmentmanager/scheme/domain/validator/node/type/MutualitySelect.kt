package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type

import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.FieldType
import ru.nti.dtps.equipmentmanager.scheme.domain.provider.OptionLib

interface MutualitySelect {
    fun validate(
        optionValueString: String,
        optionLib: OptionLib,
        fieldType: FieldType,
        equipment: PrimitiveEquipment
    )
}