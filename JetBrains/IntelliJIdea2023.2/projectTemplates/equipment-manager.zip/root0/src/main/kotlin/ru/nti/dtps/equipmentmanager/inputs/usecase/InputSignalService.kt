package ru.nti.dtps.equipmentmanager.inputs.usecase

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExists
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalExtractor
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalNameAlreadyExists
import ru.nti.dtps.equipmentmanager.inputs.adapter.InputSignalPersister
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignalError
import ru.nti.dtps.equipmentmanager.inputs.rest.CreateInputSignalCommand
import ru.nti.dtps.equipmentmanager.inputs.rest.DeleteInputSignalCommand
import ru.nti.dtps.equipmentmanager.inputs.rest.UpdateInputSignalCommand

@Component
class InputSignalService(
    private val inputSignalExtractor: InputSignalExtractor,
    private val inputSignalPersister: InputSignalPersister,
    private val variableNameAlreadyExists: VariableNameAlreadyExists,
    private val inputSignalNameAlreadyExists: InputSignalNameAlreadyExists
) : GetAllInputSignalsByEquipment, CreateInputSignal, DeleteInputSignal, UpdateInputSignal {

    override fun execute(command: CreateInputSignalCommand): Either<CreateInputSignalUseCaseError, InputSignal> {
        if (variableNameAlreadyExists(command.variableName, command.equipmentId)) {
            return CreateInputSignalUseCaseError.VariableNameAlreadyExistsError(
                command.variableName.toStringValue()
            ).left()
        }

        return InputSignal.create(
            command.id,
            command.equipmentId,
            command.name,
            command.unitType,
            command.dataType,
            command.variableName, 
            inputSignalNameAlreadyExists
        ).fold(
            { it.toCreateUseCaseError().left() },
            { inputSignal ->
                inputSignalPersister.save(inputSignal)
                inputSignal.right()
            }
        )
    }

    override fun execute(command: DeleteInputSignalCommand): Either<DeleteInputSignalUseCaseError, Unit> {
        return inputSignalExtractor.getById(command.id)?.let {
            inputSignalPersister.delete(it.id).right()
        } ?: DeleteInputSignalUseCaseError.InputSignalNotFoundError.left()
    }

    override fun execute(equipmentId: EquipmentId): List<InputSignal> {
        return inputSignalExtractor.getAllByEquipmentId(equipmentId).toList()
    }

    override fun execute(command: UpdateInputSignalCommand): Either<UpdateInputSignalUseCaseError, InputSignal> {
        if (inputSignalNameAlreadyExists(command.id, command.name, command.equipmentId)) {
            return UpdateInputSignalUseCaseError.InputSignalNameAlreadyExistError(
                command.name.toStringValue()
            ).left()
        }

        if (variableNameAlreadyExists(command.variableName, command.equipmentId, command.id.toUUID())) {
            return UpdateInputSignalUseCaseError.VariableNameAlreadyExistsError(
                command.variableName.toStringValue()
            ).left()
        }

        return inputSignalExtractor.getById(command.id)?.let { inputSignal ->
            inputSignal.update(
                command.name,
                command.unitType,
                command.dataType,
                command.variableName,
                inputSignalNameAlreadyExists
            ).fold(
                { it.toUpdateUseCaseError().left() },
                { 
                    inputSignalPersister.update(it)
                    it.right()
                }
            )
        } ?: UpdateInputSignalUseCaseError.InputSignalNotFoundError.left()
    }
}

private fun InputSignalError.toCreateUseCaseError() = 
    when (this) {
        is InputSignalError.InputSignalNameAlreadyExistError -> 
            CreateInputSignalUseCaseError.InputSignalNameAlreadyExistError(name)
    }

private fun InputSignalError.toUpdateUseCaseError() =
    when (this) {
        is InputSignalError.InputSignalNameAlreadyExistError ->
            UpdateInputSignalUseCaseError.InputSignalNameAlreadyExistError(name)
    }
