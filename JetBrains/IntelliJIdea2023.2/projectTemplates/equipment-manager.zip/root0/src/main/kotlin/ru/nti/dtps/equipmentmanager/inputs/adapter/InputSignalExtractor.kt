package ru.nti.dtps.equipmentmanager.inputs.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.InputSignalId
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal

interface InputSignalExtractor {
    fun getById(id: InputSignalId): InputSignal?
    fun getAllByEquipmentId(equipmentId: EquipmentId): Collection<InputSignal>
}