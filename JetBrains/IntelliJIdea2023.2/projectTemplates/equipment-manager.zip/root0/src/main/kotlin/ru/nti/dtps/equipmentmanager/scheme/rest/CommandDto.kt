package ru.nti.dtps.equipmentmanager.scheme.rest

import com.fasterxml.jackson.annotation.JsonSubTypes
import com.fasterxml.jackson.annotation.JsonTypeInfo
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserId
import ru.nti.dtps.equipmentmanager.scheme.domain.command.*

class CommandBatchRequestDto(
    val id: String,
    val commands: List<CommandDto>
) {
    fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): BatchCommand {
        return BatchCommand(
            id,
            equipmentId,
            userId,
            commands.map { it.toDomainCommand(equipmentId, userId) }
        )
    }
}

@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    include = JsonTypeInfo.As.EXISTING_PROPERTY,
    property = "type",
    visible = true
)
@JsonSubTypes(
    JsonSubTypes.Type(value = CreateNodeCommandDto::class, name = "NODE_CREATE"),
    JsonSubTypes.Type(value = ChangeNodeCoordsCommandDto::class, name = "NODE_COORDS_CHANGE"),
    JsonSubTypes.Type(value = ChangeNodeDimensionsCommandDto::class, name = "NODE_DIMENSIONS_CHANGE"),
    JsonSubTypes.Type(value = ChangeNodeRotationCommandDto::class, name = "NODE_ROTATION_CHANGE"),
    JsonSubTypes.Type(value = ChangeNodeParamsCommandDto::class, name = "NODE_NAME_CHANGE"),
    JsonSubTypes.Type(value = ChangeNodeParamsCommandDto::class, name = "NODE_UPDATE"),
    JsonSubTypes.Type(value = ChangeNodePortsCommandDto::class, name = "NODE_PORTS_CHANGE"),
    JsonSubTypes.Type(value = DeleteNodeCommandDto::class, name = "NODE_DELETE"),
    JsonSubTypes.Type(value = CreateLinkCommandDto::class, name = "LINK_CREATE"),
    JsonSubTypes.Type(value = UpdateLinkCommandDto::class, name = "LINK_UPDATE"),
    JsonSubTypes.Type(value = DeleteLinkCommandDto::class, name = "LINK_DELETE")
)
abstract class CommandDto(val type: CommandType) {
    abstract fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command
}

class CreateNodeCommandDto(
    type: CommandType,
    val body: CreateNode
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return CreateNodeCommand(type, equipmentId, userId, body)
    }
}

class ChangeNodeCoordsCommandDto(
    type: CommandType,
    val body: ChangeNodeCoords
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return ChangeNodeCoordsCommand(type, equipmentId, userId, body)
    }
}

class ChangeNodeDimensionsCommandDto(
    type: CommandType,
    val body: ChangeNodeDimensions
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return ChangeNodeDimensionsCommand(type, equipmentId, userId, body)
    }
}

class ChangeNodeRotationCommandDto(
    type: CommandType,
    val body: ChangeNodeRotation
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return ChangeNodeRotationCommand(type, equipmentId, userId, body)
    }
}

class ChangeNodeParamsCommandDto(
    type: CommandType,
    val body: ChangeNodeParams
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return ChangeNodeParamsCommand(type, equipmentId, userId, body)
    }
}

class ChangeNodePortsCommandDto(
    type: CommandType,
    val body: ChangeNodePorts
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return ChangeNodePortsCommand(type, equipmentId, userId, body)
    }
}

class DeleteNodeCommandDto(
    type: CommandType,
    val body: DeleteNode
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return DeleteNodeCommand(type, equipmentId, userId, body)
    }
}

class CreateLinkCommandDto(
    type: CommandType,
    val body: CreateLink
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return CreateLinkCommand(type, equipmentId, userId, body)
    }
}

class UpdateLinkCommandDto(
    type: CommandType,
    val body: UpdateLink
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return UpdateLinkCommand(type, equipmentId, userId, body)
    }
}

class DeleteLinkCommandDto(
    type: CommandType,
    val body: DeleteLink
) : CommandDto(type) {
    override fun toDomainCommand(equipmentId: EquipmentId, userId: UserId): Command {
        return DeleteLinkCommand(type, equipmentId, userId, body)
    }
}
