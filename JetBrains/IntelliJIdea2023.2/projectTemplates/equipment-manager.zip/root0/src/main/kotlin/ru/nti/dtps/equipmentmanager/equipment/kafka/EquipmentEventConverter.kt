package ru.nti.dtps.equipmentmanager.equipment.kafka

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipment.meta.info.dataclass.common.Language
import ru.nti.dtps.equipment.meta.info.dataclass.equipment.measurement.ShowMeasurement
import ru.nti.dtps.equipmentmanager.common.types.DataType
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentFullView
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.usecase.PublishEquipmentUseCaseError
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.getPhases
import ru.nti.dtps.equipmentmanager.scheme.domain.isPrimitivePort
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SignalInfoDto
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgDto
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgInfoDto

private const val COMMON_GROUP = "COMMON"

class EquipmentEventConverter {
    companion object {
        fun toEvent(
            equipment: EquipmentFullView,
            svg: SvgDto,
            svgInfo: SvgInfoDto,
            signalInfo: SignalInfoDto,
            parameterGroups: List<ParameterGroup>,
            scheme: Scheme
        ): Either<PublishEquipmentUseCaseError, EquipmentEventMessage> {
            val primitivePorts = scheme.primitiveNodes.values
                .filter { it.type.isPrimitivePort() }

            val ports = svgInfo.ports.map { svgPort ->
                PortLib(
                    libId = svgPort.libId,
                    phases = primitivePorts.find { it.id == svgPort.id.toString() }?.getPhases()
                        ?: return PublishEquipmentUseCaseError.PublishEquipmentError.left(),
                    alignment = mapOf(Language.RU to svgPort.alignment),
                    x = mapOf(Language.RU to svgPort.coords.x),
                    y = mapOf(Language.RU to svgPort.coords.y)
                )
            }

            val fields: List<FieldLib> = equipment.parameters.map { parameter ->
                val step = when (parameter.dataType) {
                    DataType.FLOAT -> 0.01
                    DataType.INTEGER -> 1
                    DataType.BOOLEAN -> null
                }

                FieldLib(
                    id = parameter.id.toStringValue(),
                    typeId = parameter.dataType.name,
                    groupId = parameterGroups.find { it.id == parameter.groupId }?.id ?: COMMON_GROUP,
                    name = mapOf(Language.RU to parameter.buildParameterName()),
                    min = parameter.minValue,
                    max = parameter.maxValue,
                    step = step.toString(),
                    defaultValue = parameter.defaultValue,
                    optional = false
                )
            }

            val controls = equipment.inputSignals.map { control ->
                ControlLib(
                    id = control.id.toStringValue(),
                    typeId = control.dataType.name,
                    name = mapOf(Language.RU to control.name.toStringValue())
                )
            }

            val measurements = signalInfo.signalsFromMeas.map { measurementInfo ->
                val measurement = equipment.outputSignals.first { it.id.toStringValue() == measurementInfo.id.toString() }
                val showOnScheme = svgInfo.placeholders.find { it.signalIds.contains(measurementInfo.id.toString()) }

                MeasurementLib(
                    subTypeId = measurementInfo.id.toString(),
                    typeId = measurement.dataType.name,
                    name = mapOf(Language.RU to measurementInfo.buildMeasurementName()),
                    relatedPortLibId = "NO_ID",
                    show = ShowMeasurement(
                        onScheme = showOnScheme != null,
                        inModal = measurementInfo.showOnSimulation
                    )
                )
            } + signalInfo.signalsFromScheme.map { measurementInfo ->
                val showOnScheme = svgInfo.placeholders.find { it.signalIds.contains(measurementInfo.id.toString()) }

                MeasurementLib(
                    subTypeId = measurementInfo.id.toString(),
                    typeId = DataType.FLOAT.name,
                    name = mapOf(Language.RU to measurementInfo.buildMeasurementName()),
                    relatedPortLibId = "NO_ID",
                    show = ShowMeasurement(
                        onScheme = showOnScheme != null,
                        inModal = measurementInfo.showOnSimulation
                    )
                )
            }

            val equipmentLib = EquipmentLib(
                id = equipment.id.toStringValue(),
                height = mapOf(Language.RU to svgInfo.dimensions!!.height),
                width = mapOf(Language.RU to svgInfo.dimensions.width),
                name = mapOf(Language.RU to equipment.name.toStringValue()),
                labelDirection = mapOf(Language.RU to "left"),
                svg = mapOf(Language.RU to svg.svgScheme.toString()),
                ports = ports,
                fields = fields,
                controls = controls,
                measurements = measurements
            )

            val fieldTypes = DataType.entries.map {
                FieldType(
                    id = it.name,
                    valueType = it.name
                )
            }

            val measurementTypes = DataType.entries.map {
                MeasurementType(
                    id = it.name,
                    unit = mapOf(Language.RU to ""),
                    arrowPresence = false,
                    valueType = "SIMPLE",
                    digitsAfterComma = 1,
                    multiplier = 1.0
                )
            }

            val parameterGroupsLib = parameterGroups.map {
                ParameterGroup(
                    id = it.id,
                    name = mapOf(Language.RU to it.name)
                )
            }.plus(
                ParameterGroup(
                    id = COMMON_GROUP,
                    name = mapOf(Language.RU to "Общие")
                )
            ).plus(
                ParameterGroup(
                    id = "AUTOMATION",
                    name = mapOf(Language.RU to "Автоматика")
                )
            )

            return EquipmentEventMessage.buildPublishMessage(
                equipment.id.toStringValue(),
                equipment.companyId.toStringValue(),
                equipmentLib,
                fieldTypes,
                measurementTypes,
                parameterGroupsLib,
                equipment.version + 1
            ).right()
        }
    }
}
