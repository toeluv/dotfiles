package ru.nti.dtps.equipmentmanager.cplus.docker.access

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.cplus.adapter.CppFolderManager
import ru.nti.dtps.equipmentmanager.cplus.docker.adapter.getVolumeName

@Component
class GetDockerVolumePath(
    private val cppFolderManager: CppFolderManager
) : DockerVolumePathProvider {
    override fun getFolderToMount(equipmentId: EquipmentId): String {
        return cppFolderManager.getAbsoluteFolderPath(equipmentId.getVolumeName())
    }
}