package ru.nti.dtps.equipmentmanager.userVariable.rest

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.ArraySchema
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import ru.nti.dtps.equipmentmanager.common.types.*
import ru.nti.dtps.equipmentmanager.common.util.*
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable
import ru.nti.dtps.equipmentmanager.userVariable.usecase.*

@RestController
class UserVariableController(
    private val messageSource: MessageSourceService,
    private val getAllUserVariables: GetAllUserVariables,
    private val createUserVariable: CreateUserVariable,
    private val updateUserVariable: UpdateUserVariable,
    private val deleteUserVariable: DeleteUserVariable
) {

    @Operation(summary = "Execute get all user variables command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "All Users variables are found", content = [
                    (Content(
                        mediaType = "application/json",
                        array = ArraySchema(schema = Schema(implementation = UserVariableView::class))
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @GetMapping("#[[\$]]#API_V1_EQUIPMENT_VARIABLES/{equipmentId}")
    fun getAll(@PathVariable equipmentId: String): ResponseEntity<*> {
        return EquipmentId.validated(equipmentId)
            .fold(
                { it.toRestError() },
                { validEquipmentId ->
                    ok(getAllUserVariables.execute(validEquipmentId).map { it.toView() })
                }
            )
    }

    @Operation(summary = "Execute create user variable command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "User variable was created", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = UserVariableView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409",
                description = "Variable name has not unique value",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PostMapping("#[[\$]]#API_V1_EQUIPMENT_VARIABLES/{equipmentId}")
    fun create(
        @PathVariable equipmentId: String,
        @RequestBody request: CreateUserVariableRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    createUserVariable.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { userVariable -> ok(userVariable.toView()) }
                        )
                }
            )
    }

    @Operation(summary = "Execute update user variable command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "User variable was updated", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = UserVariableView::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "409",
                description = "Variable name has not unique value",
                content = [(Content(
                    mediaType = "application/json",
                    schema = Schema(implementation = BusinessError::class)
                ))]
            ),
            ApiResponse(
                responseCode = "404", description = "User variable not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @PutMapping("#[[\$]]#API_V1_EQUIPMENT_VARIABLES/{equipmentId}")
    fun update(
        @PathVariable equipmentId: String,
        @RequestBody request: UpdateUserVariableRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    updateUserVariable.execute(it)
                        .fold(
                            { error -> error.toRestError() },
                            { userVariable -> ok(userVariable.toView()) }
                        )
                }
            )
    }

    @Operation(summary = "Execute delete user variable command")
    @ApiResponses(
        value = [
            ApiResponse(
                responseCode = "200", description = "User variable was deleted", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = Unit::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "400", description = "Unsupported request fields", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "404", description = "User variable not found", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = BusinessError::class)
                    ))]
            ),
            ApiResponse(
                responseCode = "500", description = "Something went wrong, go to admin", content = [
                    (Content(
                        mediaType = "application/json",
                        schema = Schema(implementation = GlobalErrorHandler.Problem::class)
                    ))]
            )
        ]
    )
    @DeleteMapping("#[[\$]]#API_V1_EQUIPMENT_VARIABLES/{equipmentId}")
    fun delete(
        @PathVariable equipmentId: String,
        @RequestBody request: DeleteUserVariableRequest
    ): ResponseEntity<*> {
        return request.buildCommand(equipmentId)
            .fold(
                { it.toRestError() },
                {
                    deleteUserVariable.execute(it).fold(
                        { error -> error.toRestError() },
                        { unit -> ok(unit) }
                    )
                }
            )
    }

    private fun ValidationError.toRestError() =
        restBusinessError(
            messageSource.getMessage(this.errorCode),
            HttpStatus.BAD_REQUEST
        )

    private fun CreateUserVariableUseCaseError.toRestError() = when (this) {
        is CreateUserVariableUseCaseError.VariableNameAlreadyExistsError ->
            restBusinessError(
                messageSource.getMessage("api.variable.error.validation.twins").format(this.value),
                HttpStatus.CONFLICT
            )
    }

    private fun UpdateUserVariableUseCaseError.toRestError() = when (this) {
        is UpdateUserVariableUseCaseError.VariableNameAlreadyExistsError -> restBusinessError(
            messageSource.getMessage("api.scheme.error.equipment.variable.name.twins").format(this.value),
            HttpStatus.CONFLICT
        )

        UpdateUserVariableUseCaseError.UserVariableNotFoundError -> restBusinessError(
            messageSource.getMessage("api.user-variable.error.not-found"),
            HttpStatus.NOT_FOUND
        )
    }

    private fun DeleteUserVariableUseCaseError.toRestError() = when (this) {
        DeleteUserVariableUseCaseError.UserVariableNotFoundError -> restBusinessError(
            messageSource.getMessage("api.user-variable.error.not-found"),
            HttpStatus.NOT_FOUND
        )
    }
}

data class UserVariableView(
    val id: String,
    val equipmentId: String,
    val variableName: String,
    val dataType: String
)

private fun UserVariable.toView() = UserVariableView(
    id.toStringValue(),
    equipmentId.toStringValue(),
    variableName.toStringValue(),
    dataType.name
)
