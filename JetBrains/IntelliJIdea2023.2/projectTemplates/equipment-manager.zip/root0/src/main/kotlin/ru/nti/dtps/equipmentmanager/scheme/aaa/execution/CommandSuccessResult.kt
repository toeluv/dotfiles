package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import ru.nti.dtps.equipmentmanager.scheme.aaa.command.UserCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.EditorCommand

interface CommandSuccessResult {
    fun undo(): UserCommand
    fun editorCommands(): List<EditorCommand>
}