package ru.nti.dtps.equipmentmanager.inputs.usecase

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.inputs.domain.InputSignal

interface GetAllInputSignalsByEquipment {
    fun execute(equipmentId: EquipmentId): List<InputSignal>
}