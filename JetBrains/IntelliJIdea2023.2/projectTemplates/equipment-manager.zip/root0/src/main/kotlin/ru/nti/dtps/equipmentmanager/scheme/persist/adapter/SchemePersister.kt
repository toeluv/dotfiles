package ru.nti.dtps.equipmentmanager.scheme.persist.adapter

import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.Scheme
import java.util.UUID

interface SchemePersister {
    fun save(scheme: Scheme)
    fun update(scheme: Scheme)
    fun delete(id: UUID)
}