package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.Alignment
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.PortLibId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.PrimitiveEquipmentLibId
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.validators.*
import java.util.*

const val EQUIPMENT_LIB_PATH = "library/PrimitiveEquipmentLibrary.json"

@Component
class LibInfoProvider(): OptionsValidatorProvider {

    private final val optionValidatorByEquipmentLibId: Map<PrimitiveEquipmentLibId, List<OptionFieldsValidator>>

    init {
        val objectMapper = jacksonObjectMapper()
        val classLoader = Thread.currentThread().contextClassLoader

        optionValidatorByEquipmentLibId = load(
            objectMapper,
            classLoader,
            Array<EquipmentLib>::class.java,
            EQUIPMENT_LIB_PATH
        ).associate { equipmentLib -> Pair(equipmentLib.id, equipmentLib.getValidators().sortedBy { it.order() }) }

    }

    override fun get(type: PrimitiveEquipmentLibId): List<OptionFieldsValidator> {
        return optionValidatorByEquipmentLibId[type] ?: emptyList()
    }


    private fun <K> load(
        objectMapper: ObjectMapper,
        classloader: ClassLoader,
        clazz: Class<Array<K>>?,
        path: String?,
    ): Array<K> {
        val inputStream = classloader.getResourceAsStream(path)
        val libElements = objectMapper.readValue(Objects.requireNonNull(inputStream).readAllBytes(), clazz)
        inputStream?.close()
        return libElements
    }
}

data class EquipmentLib(
    val id: PrimitiveEquipmentLibId,
    val height: Double,
    val width: Double,
    val name: Map<String, String>,
    val labelDirection: String,
    val svg: String,
    val ports: List<PortLib> = listOf(),
    val options: List<OptionLib> = listOf()
) {
    fun getValidators(): List<OptionFieldsValidator> {
        val requiredFieldValidator = options.filter { !it.optional }
            .map { it.id }
            .toSet()
            .let { RequiredOptionExistenceValidator(it) }
        val equipmentValidator = options.flatMap { it.getValidators() } + requiredFieldValidator
        return equipmentValidator
    }
}

data class OptionLib(
    val id: OptionLibId,
    val typeId: FieldTypeId,
    val name: Map<String, String>,
    val regex: String?,
    val minLength: Int?,
    val maxLength: Int?,
    val min: Double?,
    val max: Double?,
    val step: Double?,
    val optional: Boolean = false
) {
    fun getValidators(): List<OptionFieldsValidator> {
        val validators = mutableListOf<OptionFieldsValidator>()
        minLength?.let {
            validators.add(MinLengthTextValidator(id, it))
        }
        maxLength?.let {
            validators.add(MaxLengthTextValidator(id, it))
        }
        min?.let {
            validators.add(MinNumberValidator(id, it))
        }
        max?.let {
            validators.add(MaxNumberValidator(id, it))
        }
        regex?.let {
            validators.add(RegexTextValidator(id, it))
        }
        return validators.toList()
    }

}

data class PortLib(
    val libId: PortLibId,
    val alignment: Alignment,
    val x: Double,
    val y: Double
)

data class FieldType(
    val id: FieldTypeId,
    val valueType: OptionValueType,
    val min: Double?,
    val max: Double?,
    val step: Double?,
    val regex: String?,
    val length: Int?,
    val minLength: Int?,
    val maxLength: Int?,
    val options: List<Option> = listOf(),
) {
    data class Option(
        val key: String,
        val value: String
    )
}

data class PrimitivePortSignalInfo(
    val id: String,
    val name: String,
    val dimension: String
)

enum class OptionLibId {
    VARIABLE_NAME,
    NAME,
    CONDUCTIVITY,
    CURRENT_VALUE,
    RESISTANCE,
    EMF_VALUE,
    INDUCTANCE_L1,
    INDUCTANCE_L2,
    COUPLING_COEFFICIENT,
    MUTUAL_INDUCTANCE,
    INDUCTANCE,
    CAPACITANCE,
    MUTUALITY
}

enum class FieldTypeId {
    NUMERIC,
    CURRENT,
    VOLTAGE,
    RESISTANCE,
    CONDUCTIVITY,
    INDUCTANCE,
    CAPACITANCE,
    TEXT,
    MUTUALITY_SELECT
}

enum class OptionValueType { NUMBER, MUTUALITY_SELECT, TEXT }