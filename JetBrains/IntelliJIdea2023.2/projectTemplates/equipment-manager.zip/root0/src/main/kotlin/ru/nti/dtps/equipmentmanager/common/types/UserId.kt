package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError
import java.util.*

data class UserId(
    val id: UUID
) {
    companion object {
        fun from(id: String): Either<InvalidUserIdError, UserId> {
            return Either.catch { UUID.fromString(id) }
                .fold(
                    { InvalidUserIdError.left() },
                    { UserId(it).right() }
                )
        }

        fun from(id: UUID): UserId = UserId(id)
    }

    fun toStringValue() = id.toString()
    fun toUUID() = id
}

object InvalidUserIdError : BusinessError
