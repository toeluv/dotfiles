package ru.nti.dtps.equipmentmanager.outputs.usecase

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExists
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalExtractor
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalNameAlreadyExists
import ru.nti.dtps.equipmentmanager.outputs.adapter.OutputSignalPersister
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignal
import ru.nti.dtps.equipmentmanager.outputs.domain.OutputSignalError
import ru.nti.dtps.equipmentmanager.outputs.rest.CreateOutputSignalCommand
import ru.nti.dtps.equipmentmanager.outputs.rest.DeleteOutputSignalCommand
import ru.nti.dtps.equipmentmanager.outputs.rest.UpdateOutputSignalCommand

@Component
class OutputSignalService(
    private val outputSignalExtractor: OutputSignalExtractor,
    private val outputSignalPersister: OutputSignalPersister,
    private val variableNameAlreadyExists: VariableNameAlreadyExists,
    private val outputSignalNameAlreadyExists: OutputSignalNameAlreadyExists
) : GetAllOutputSignalsByEquipment, CreateOutputSignal, DeleteOutputSignal, UpdateOutputSignal {

    override fun execute(command: CreateOutputSignalCommand): Either<CreateOutputSignalUseCaseError, OutputSignal> {
        if (variableNameAlreadyExists(command.variableName, command.equipmentId)) {
            return CreateOutputSignalUseCaseError.VariableNameAlreadyExistsError(
                command.variableName.toStringValue()
            ).left()
        }

        return OutputSignal.create(
            command.id,
            command.equipmentId,
            command.name,
            command.unitType,
            command.dataType,
            command.variableName,
            outputSignalNameAlreadyExists
        ).fold(
            { it.toCreateUseCaseError().left() },
            {
                outputSignalPersister.save(it)
                it.right()
            }
        )
    }

    override fun execute(command: DeleteOutputSignalCommand): Either<DeleteOutputSignalUseCaseError, Unit> {
        return outputSignalExtractor.getById(command.id)?.let {
            outputSignalPersister.delete(it.id).right()
        } ?: DeleteOutputSignalUseCaseError.OutputSignalNotFoundError.left()
    }

    override fun execute(equipmentId: EquipmentId): List<OutputSignal> {
        return outputSignalExtractor.getAllByEquipmentId(equipmentId).toList()
    }

    override fun execute(command: UpdateOutputSignalCommand): Either<UpdateOutputSignalUseCaseError, OutputSignal> {
        if (outputSignalNameAlreadyExists(command.id, command.name, command.equipmentId)) {
            return UpdateOutputSignalUseCaseError.OutputSignalNameAlreadyExistError(
                command.name.toStringValue()
            ).left()
        }

        if (variableNameAlreadyExists(command.variableName, command.equipmentId, command.id.toUUID())) {
            return UpdateOutputSignalUseCaseError.VariableNameAlreadyExistsError(
                command.variableName.toStringValue()
            ).left()
        }

        return outputSignalExtractor.getById(command.id)?.let { outputSignal ->
            outputSignal.update(
                command.name,
                command.unitType,
                command.dataType,
                command.variableName,
                outputSignalNameAlreadyExists
            ).fold(
                { it.toUpdateUseCaseError().left() },
                {
                    outputSignalPersister.update(it)
                    it.right()
                }
            )
        } ?: return UpdateOutputSignalUseCaseError.OutputSignalNotFoundError.left()
    }
}

private fun OutputSignalError.toCreateUseCaseError() =
    when (this) {
        is OutputSignalError.OutputSignalNameAlreadyExistError ->
            CreateOutputSignalUseCaseError.OutputSignalNameAlreadyExistError(name)
    }

private fun OutputSignalError.toUpdateUseCaseError() =
    when (this) {
        is OutputSignalError.OutputSignalNameAlreadyExistError ->
            UpdateOutputSignalUseCaseError.OutputSignalNameAlreadyExistError(name)
    }
