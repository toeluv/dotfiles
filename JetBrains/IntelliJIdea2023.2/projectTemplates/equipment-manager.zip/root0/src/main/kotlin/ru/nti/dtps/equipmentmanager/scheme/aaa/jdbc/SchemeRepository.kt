package ru.nti.dtps.equipmentmanager.scheme.aaa.jdbc

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.Scheme
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeExtractor
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemePersister
import java.sql.ResultSet
import java.util.*

@Component
class SchemeRepository(
    private val jdbcTemplate: NamedParameterJdbcTemplate,
) : SchemeExtractor, SchemePersister {
    private val jackObjectMapper: ObjectMapper = jacksonObjectMapper()

    override fun extract(id: EquipmentId): Scheme? {
        val params = mapOf(
            "id" to id.toUUID()
        )
        return jdbcTemplate.query(
            "SELECT * FROM public.scheme WHERE id = :id",
            params,
            SchemeResultSetExtractor()
        )
    }

    override fun persist(scheme: Scheme) {
        if (scheme.version == 0L) {
            insert(scheme)
        }
        update(scheme)
    }

    override fun remove(equipmentId: EquipmentId) {
        val params = mapOf(
            "id" to equipmentId.toUUID()
        )
        jdbcTemplate.update(
            """
                DELETE FROM public.scheme_node where parent_id = :id;
                DELETE FROM public.scheme_link where parent_id = :id;
                DELETE FROM public.node_options where parent_id = :id;
                DELETE from public.scheme where id = :id
            """.trimIndent(),
            params
        )
    }

    private fun insert(scheme: Scheme) {
        val params = mapOf(
            "id" to scheme,
            "version" to scheme.version,
            "is_valid" to scheme.isValid,
        )
        jdbcTemplate.update(
            """
        INSERT INTO public.scheme(id, version, is_valid)
        VALUES(
            :id, 
            :version,
            :is_valid
        )
        """.trimIndent(), params
        )
    }

    private fun update(scheme: Scheme) {
        val params = mapOf(
            "id" to scheme,
            "version" to scheme.version,
            "previous_version" to scheme.version - 1,
            "is_valid" to scheme.isValid,
        )
        jdbcTemplate.update(
            """
            UPDATE public.scheme SET
            version = :version,
            is_valid = :is_valid
            WHERE id = :id AND version = :previous_version
        """.trimIndent(), params
        )
    }

}

class SchemeResultSetExtractor : ResultSetExtractor<Scheme> {
    override fun extractData(rs: ResultSet): Scheme? {
        return if (rs.next()) {
            SchemeRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class SchemeRowMapper : RowMapper<Scheme> {
    override fun mapRow(rs: ResultSet, rowNum: Int): Scheme {

        val id = rs.getObject("id", UUID::class.java)
        val version = rs.getLong("version")
        val isValid = rs.getBoolean("is_valid")

        return Scheme(
            EquipmentId(id), version, isValid
        )
    }
}