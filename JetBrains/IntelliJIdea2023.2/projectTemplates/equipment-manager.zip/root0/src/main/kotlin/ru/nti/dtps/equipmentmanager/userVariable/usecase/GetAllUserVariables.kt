package ru.nti.dtps.equipmentmanager.userVariable.usecase

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.userVariable.domain.UserVariable

interface GetAllUserVariables {
    fun execute(equipmentId: EquipmentId): List<UserVariable>
}
