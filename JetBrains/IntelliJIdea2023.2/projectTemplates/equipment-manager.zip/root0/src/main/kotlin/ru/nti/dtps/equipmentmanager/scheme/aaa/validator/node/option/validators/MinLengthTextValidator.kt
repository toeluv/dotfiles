package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.validators

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionFieldsValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId


class MinLengthTextValidator(
    val field: OptionLibId,
    private val minLength: Int
) : OptionFieldsValidator {

//    override fun field() = field
    override fun order() = 1000

    override fun validate(options: Map<OptionLibId, String?>): Either<OptionValidationError, Unit> {
        return options[field]?.let {
            if (it.length < minLength) {
                TextFieldLengthLessThenMinValueError(
                    field, minLength
                ).left()
            }
            Unit.right()
        } ?: Unit.right()
    }

}

class TextFieldLengthLessThenMinValueError(
    val optionLib: OptionLibId,
    val boundValue: Int
) : OptionValidationError
