package ru.nti.dtps.equipmentmanager.inputs.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.InputSignalId
import ru.nti.dtps.equipmentmanager.common.types.InputSignalName

interface InputSignalNameAlreadyExists {
    operator fun invoke(name: InputSignalName, equipmentId: EquipmentId): Boolean
    operator fun invoke(id: InputSignalId, name: InputSignalName, equipmentId: EquipmentId): Boolean
}