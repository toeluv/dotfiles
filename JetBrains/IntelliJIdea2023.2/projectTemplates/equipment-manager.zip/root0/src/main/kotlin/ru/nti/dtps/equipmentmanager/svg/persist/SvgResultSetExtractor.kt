package ru.nti.dtps.equipmentmanager.svg.persist

import arrow.core.getOrElse
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgDto
import java.sql.ResultSet

class SvgResultSetExtractor : ResultSetExtractor<SvgDto> {
    override fun extractData(rs: ResultSet): SvgDto? {
        return if (rs.next()) {
            SvgRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class SvgRowMapper : RowMapper<SvgDto> {

    private val logger = LoggerFactory.getLogger(SvgRowMapper::class.java)
    override fun mapRow(rs: ResultSet, rowNum: Int): SvgDto? {
        val id = rs.getString("id")
        val svgScheme = rs.getBytes("svg_scheme")
        val svgLib = rs.getBytes("svg_lib")

        return SvgDto.restore(
            id = EquipmentId.from(id).getOrElse {
                logger.error("Incorrect equipment id #[[\$]]#id")
                return null
            }.id,
            svgScheme,
            svgLib
        )
    }
}