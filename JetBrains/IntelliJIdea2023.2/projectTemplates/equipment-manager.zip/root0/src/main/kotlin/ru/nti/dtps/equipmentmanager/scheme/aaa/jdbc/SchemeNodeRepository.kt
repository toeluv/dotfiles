package ru.nti.dtps.equipmentmanager.scheme.aaa.jdbc

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.springframework.jdbc.core.ResultSetExtractor
import org.springframework.jdbc.core.RowMapper
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.Dimensions
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.Port
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeNode
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.XyCoords
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeNodeExtractor
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeNodePersister
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import java.sql.ResultSet
import java.util.*

@Component
class SchemeNodeRepository(
    private val jdbcTemplate: NamedParameterJdbcTemplate,
) : SchemeNodePersister, SchemeNodeExtractor {

    private val jackObjectMapper: ObjectMapper = jacksonObjectMapper()

    override fun extract(equipmentId: EquipmentId, nodeId: UUID): SchemeNode? {
        val params = mapOf(
            "node_id" to nodeId,
            "parent_id" to equipmentId.toUUID()
        )
        return jdbcTemplate.query(
            "SELECT * FROM public.scheme_node WHERE node_id = :node_id AND parent_id = :parent_id",
            params,
            SchemeNodeResultSetExtractor()
        )?.toDomain()
    }

    override fun insert(schemeNode: SchemeNode) {
        val params = mapOf(
            "node_id" to schemeNode.id,
            "parent_id" to schemeNode.parentId,
            "params" to jackObjectMapper.writeValueAsString(schemeNode.toJdbcDto().params),
            "payload" to jackObjectMapper.writeValueAsString(schemeNode.payload)
        )
        jdbcTemplate.update(
            """
        INSERT INTO public.scheme_node(node_id, parent_id, params, payload)
        VALUES(
            :node_id, 
            :parent_id,
            :params, 
            :payload
        )
        """.trimIndent(), params
        )
    }

    override fun update(schemeNode: SchemeNode) {
        val params = mapOf(
            "node_id" to schemeNode.id,
            "parent_id" to schemeNode.parentId,
            "params" to jackObjectMapper.writeValueAsString(schemeNode.toJdbcDto().params),
            "payload" to jackObjectMapper.writeValueAsString(schemeNode.payload)
        )
        jdbcTemplate.update(
            """
            UPDATE public.scheme_node SET
            params = :params,
            payload = :payload
            WHERE node_id = :node_id AND parent_id = :parent_id
        """.trimIndent(), params
        )
    }

    override fun delete(parentId: UUID, id: UUID) {
        val params = mapOf(
            "node_id" to id,
            "parent_id" to parentId,
        )
        jdbcTemplate.update(
            "DELETE from public.scheme_node where node_id = :node_id AND parent_id = :parent_id",
            params
        )
    }

    class SchemeNodeJdbc(
        val id: UUID,
        val parentId: UUID,
        val params: SchemeNodeParamsJdbc,
        val payload: Map<String, String>,
    )

    class SchemeNodeParamsJdbc(
        val type: PrimitiveEquipment.PrimitiveEquipmentLibId,
        val ports: List<Port>,
        val hour: Int = 0,
        val coords: XyCoords,
        val dimensions: Dimensions,
    )

    private fun SchemeNode.toJdbcDto() = SchemeNodeJdbc(
        id = this.id,
        parentId = this.parentId,
        params = SchemeNodeParamsJdbc(
            type = this.type,
            ports = this.ports,
            hour = this.hour,
            coords = this.coords,
            dimensions = this.dimensions
        ),
        payload = this.payload
    )

    private fun SchemeNodeJdbc.toDomain() = SchemeNode(
        id = this.id,
        parentId = this.parentId,
        type = this.params.type,
        ports = this.params.ports,
        hour = this.params.hour,
        coords = this.params.coords,
        dimensions = this.params.dimensions,
        payload = this.payload,
    )
}

class SchemeNodeResultSetExtractor : ResultSetExtractor<SchemeNodeRepository.SchemeNodeJdbc> {
    override fun extractData(rs: ResultSet): SchemeNodeRepository.SchemeNodeJdbc? {
        return if (rs.next()) {
            SchemeNodeRowMapper().mapRow(rs, 0)
        } else {
            null
        }
    }
}

class SchemeNodeRowMapper : RowMapper<SchemeNodeRepository.SchemeNodeJdbc> {
    private val objectMapper = jacksonObjectMapper()
    private val payloadTypeRef = object : TypeReference<Map<String, String>>() {}

    override fun mapRow(rs: ResultSet, rowNum: Int): SchemeNodeRepository.SchemeNodeJdbc {
        val id = rs.getObject("id", UUID::class.java)
        val parentId = rs.getObject("parent_id", UUID::class.java)

        val paramsString = rs.getString("params")
        val payloadString = rs.getString("payload")
        val params =
            objectMapper.readValue(paramsString, SchemeNodeRepository.SchemeNodeParamsJdbc::class.java)
        val payload = objectMapper.readValue(payloadString, payloadTypeRef)


        return SchemeNodeRepository.SchemeNodeJdbc(
            id, parentId, params, payload
        )
    }
}