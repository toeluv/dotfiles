package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError
import java.util.*

data class CompanyId(
    val id: UUID
) {
    companion object {
        fun from(id: String): Either<InvalidCompanyIdError, CompanyId> {
            return Either.catch { UUID.fromString(id) }
                .fold(
                    { InvalidCompanyIdError.left() },
                    { CompanyId(it).right() }
                )
        }

        fun from(id: UUID): CompanyId = CompanyId(id)
    }

    fun toStringValue() = id.toString()
    fun toUUID() = id
}

object InvalidCompanyIdError : BusinessError