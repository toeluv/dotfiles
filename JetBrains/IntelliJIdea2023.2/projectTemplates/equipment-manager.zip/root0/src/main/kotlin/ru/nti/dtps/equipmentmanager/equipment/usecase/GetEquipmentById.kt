package ru.nti.dtps.equipmentmanager.equipment.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.error.UseCaseError
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.equipment.domain.Equipment

interface GetEquipmentById {
    fun execute(equipmentId: EquipmentId): Either<GetEquipmentByIdUseCaseError, Equipment>
}

sealed class GetEquipmentByIdUseCaseError : UseCaseError {
    object EquipmentNotExistsUseCaseError : GetEquipmentByIdUseCaseError()
}