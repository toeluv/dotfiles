package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.scheme

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme

@Component
class RequiredEquipmentsValidator : AbstractSchemeValidator(Level.FIRST) {

    private val requiredPrimitiveEquipmentLibIds = setOf(
        PrimitiveEquipment.PrimitiveEquipmentLibId.GROUNDING,
        PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH,
        PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH
    )

    override fun validate(scheme: Scheme): Either<SchemeValidationError, Unit> {
        val schemeContainsAllRequiredEquipments = scheme.primitiveNodes.values
            .map { it.type }
            .let {
                it.contains(PrimitiveEquipment.PrimitiveEquipmentLibId.GROUNDING) &&
                    (it.contains(PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_3PH) ||
                        it.contains(PrimitiveEquipment.PrimitiveEquipmentLibId.PORT_1PH))
            }

        return if (!schemeContainsAllRequiredEquipments) {
            return SchemeDoesNotContainsRequiredEquipmentErrorScheme(requiredPrimitiveEquipmentLibIds).left()
        } else {
            Unit.right()
        }
    }
}

class SchemeDoesNotContainsRequiredEquipmentErrorScheme(
    val requiredEquipmentLibIds: Set<PrimitiveEquipment.PrimitiveEquipmentLibId>
) : SchemeValidationError