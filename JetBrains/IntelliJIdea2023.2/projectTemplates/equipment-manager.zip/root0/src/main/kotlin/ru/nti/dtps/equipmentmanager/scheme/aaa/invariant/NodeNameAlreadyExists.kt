package ru.nti.dtps.equipmentmanager.scheme.aaa.invariant

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import java.util.*

interface NodeNameAlreadyExists {
    operator fun invoke(nodeId: UUID, equipmentId: EquipmentId, nodeName: String): Boolean
}