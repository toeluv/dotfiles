package ru.nti.dtps.equipmentmanager.svg.persist.adapter

import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgInfoDto
import java.util.*

interface SvgInfoPersister {
    fun save(svgInfoDto: SvgInfoDto)
    fun update(svgInfoDto: SvgInfoDto)
    fun delete(id: UUID)
}