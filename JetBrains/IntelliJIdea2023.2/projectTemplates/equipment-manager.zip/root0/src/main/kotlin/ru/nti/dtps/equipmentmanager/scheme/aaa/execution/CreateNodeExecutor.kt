package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.CreateNodeOptionsEditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.CreateSchemeNodeEditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.EditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.PrimitiveEquipmentLibId
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.ComplexNodeValidator
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeToValidate
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node.NodeValidationError
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId

@Component
class CreateNodeExecutor(
    private val validator: ComplexNodeValidator
) : CommandExecutor<CreateNodeUserCommand> {

    override fun execute(command: CreateNodeUserCommand): Either<CommandExecutionError, CommandSuccessResult> {
        return CreateNodeCommandSuccessResult(command).let { commandResult ->
            validator.validate(commandResult.getNodeToValidate()).fold(
                { ValidationCommandExecutionError(it).left() },
                { commandResult.right() }
            )
        }

    }
}

class CreateNodeCommandSuccessResult(
    val command: CreateNodeUserCommand
) : CommandSuccessResult {
    override fun undo() = DeleteNodeUserCommand(
        command.nodeId, command.equipmentId, DeleteNode(command.nodeId)
    )

    override fun editorCommands(): List<EditorCommand> {
        return listOf(
            CreateSchemeNodeEditorCommand.build(command),
            CreateNodeOptionsEditorCommand.build(command)
        )
    }

    fun getNodeToValidate(): NodeToValidate {
        return object : NodeToValidate {
            override fun id() = command.nodeId

            override fun equipmentId() = command.equipmentId

            override fun options(): Map<OptionLibId, String?> = command.body.options

            override fun type(): PrimitiveEquipmentLibId = command.body.type

        }
    }
}

data class ValidationCommandExecutionError(val error: NodeValidationError) : CommandExecutionError()

