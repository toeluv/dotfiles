package ru.nti.dtps.equipmentmanager.scheme.aaa.electricalScheme

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.MutualBranch
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeLink
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeNode

data class ElectricalScheme(
    val equipmentId: EquipmentId,
    val nodes: SchemeNode,
    val links: SchemeLink,
    val mutualBranch: MutualBranch
) {
}