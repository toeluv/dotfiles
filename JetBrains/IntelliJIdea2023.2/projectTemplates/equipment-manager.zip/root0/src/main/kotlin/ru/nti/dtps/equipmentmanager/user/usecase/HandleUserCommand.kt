package ru.nti.dtps.equipmentmanager.user.usecase

import ru.nti.dtps.equipmentmanager.user.domain.command.UserCommand

interface HandleUserCommand {
    fun handle(userCommand: UserCommand)
}
