package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.common.MutualBranchId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.MutualBranch

interface MutualBranchPersister {
    fun insert(mutualBranch: MutualBranch)
    fun update(mutualBranch: MutualBranch)
    fun delete(mutualBranchId: MutualBranchId)
}