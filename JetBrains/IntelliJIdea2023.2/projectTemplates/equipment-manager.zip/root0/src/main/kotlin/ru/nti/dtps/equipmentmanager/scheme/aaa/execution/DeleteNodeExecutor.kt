package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.NodeOptionsExtractor
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter.SchemeNodeExtractor

@Component
class DeleteNodeExecutor(
    private val nodeOptionsExtractor: NodeOptionsExtractor,
    private val schemeNodeExtractor: SchemeNodeExtractor
): CommandExecutor<DeleteNodeUserCommand> {

    private val logger = LoggerFactory.getLogger(DeleteNodeExecutor::class.java)

    override fun execute(command: DeleteNodeUserCommand): Either<CommandExecutionError, CommandSuccessResult> {
        val nodeOptions = nodeOptionsExtractor.extract(command.equipmentId, command.nodeId)
        val schemeNode = schemeNodeExtractor.extract(command.equipmentId, command.nodeId)

        if(nodeOptions == null || schemeNode == null){
            logger.warn("Node with id #[[\$]]#{command.nodeId} not found, unredoable was canceled for batch command")
            return NodeNotFoundError(command.nodeId.toString()).left()
        }

        return DeleteNodeCommandSuccessResult(schemeNode, nodeOptions, command).right()
    }
}

class DeleteNodeCommandSuccessResult(
    val schemeNode: SchemeNode,
    val nodeOptions: NodeOptions,
    val command: DeleteNodeUserCommand
): CommandSuccessResult {
    override fun undo(): UserCommand {
        return CreateNodeUserCommand(
            nodeId = command.nodeId,
            equipmentId = command.equipmentId,
            body = CreateNode(
                id = command.nodeId,
                type = schemeNode.type,
                hour = schemeNode.hour,
                coords = schemeNode.coords,
                dimensions = schemeNode.dimensions,
                ports = schemeNode.ports,
                options = nodeOptions.options,
                payload = schemeNode.payload
            )
        )
    }

    override fun editorCommands(): List<EditorCommand> {
        return listOf(
            DeleteSchemeNodeEditorCommand.build(command),
            DeleteNodeOptionsEditorCommand.build(command)
        )
    }
}


