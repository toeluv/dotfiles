package ru.nti.dtps.equipmentmanager.equipment.domain

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.EquipmentName
import ru.nti.dtps.equipmentmanager.equipment.domain.command.CreateEquipmentCommand
import ru.nti.dtps.equipmentmanager.equipment.domain.command.UpdateEquipmentCommand
import ru.nti.dtps.equipmentmanager.equipment.usecase.EquipmentNameAlreadyExists
import ru.nti.dtps.equipmentmanager.user.domain.User
import java.time.Instant

class Equipment(
    val id: EquipmentId,
    val companyId: CompanyId,
    var name: EquipmentName,
    var groupId: String?,
    var description: String?,
    val author: String,
    val createdAt: Instant
) {
    var publicationInfo: PublicationInfo? = null
    var published: Boolean = false
    var version: Long = 0L
    var editor: String? = null
    var updatedAt: Instant? = null

    companion object {
        fun create(
            command: CreateEquipmentCommand,
            nameAlreadyExists: EquipmentNameAlreadyExists,
            validUser: User
        ): Either<EquipmentError, Equipment> {
            if (nameAlreadyExists(command.name, command.groupId)) {
                return EquipmentError.EquipmentExistWithSameNameError(command.name.toStringValue()).left()
            }

            return Equipment(
                id = command.id,
                companyId = validUser.companyId,
                name = command.name,
                groupId = command.groupId,
                description = command.description,
                author = validUser.generateFullName(),
                createdAt = Instant.now(),
            ).right()
        }

        fun restore(
            id: EquipmentId, companyId: CompanyId, name: EquipmentName, groupId: String?,
            description: String?, author: String, createdAt: Instant, published: Boolean,
            publicationInfo: PublicationInfo?, version: Long, editor: String?, updatedAt: Instant?
        ) = Equipment(
            id,
            companyId,
            name,
            groupId,
            description,
            author,
            createdAt
        ).apply {
            this.published = published
            this.publicationInfo = publicationInfo
            this.version = version
            this.editor = editor
            this.updatedAt = updatedAt
        }
    }

    fun update(
        command: UpdateEquipmentCommand,
        nameAlreadyExists: EquipmentNameAlreadyExists,
        validUser: User
    ): Either<EquipmentError, Equipment> {
        if (nameAlreadyExists(command.name, command.groupId)) {
            return EquipmentError.EquipmentExistWithSameNameError(command.name.toStringValue()).left()
        }

        this.name = command.name
        this.groupId = command.groupId
        this.description = command.description
        this.published = false
        this.publicationInfo = null
        this.editor = validUser.generateFullName()
        this.updatedAt = Instant.now()

        return this.right()
    }

    fun publish(
        validUser: User
    ) {
        this.published = true
        this.publicationInfo = PublicationInfo(
            Instant.now(),
            validUser.generateFullName()
        )
        this.version += 1L
    }
}

data class PublicationInfo(
    val publishedAt: Instant,
    val authorOfPublish: String,
)

sealed class EquipmentError : BusinessError {
    class EquipmentExistWithSameNameError(val name: String) : EquipmentError()
}
