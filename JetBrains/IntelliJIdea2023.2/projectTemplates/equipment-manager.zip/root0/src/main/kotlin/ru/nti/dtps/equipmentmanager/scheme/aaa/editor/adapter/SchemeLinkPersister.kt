package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeLink
import java.util.*

interface SchemeLinkPersister {
    fun insert(schemeLink: SchemeLink)
    fun update(schemeLink: SchemeLink)
    fun delete(parentId: UUID, id: UUID)

}