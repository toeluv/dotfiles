package ru.nti.dtps.equipmentmanager.cplus.docker.domain

import arrow.core.Either
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import java.util.*

interface DockerApi {
    fun createContainer(equipmentId: EquipmentId, image: Image): Either<DockerAdapterExecuteCommandError, ContainerId>
    fun startContainer(containerId: ContainerId): Either<DockerAdapterExecuteCommandError, Unit>
    fun restartContainer(containerId: ContainerId): Either<DockerAdapterExecuteCommandError, Unit>
    fun stopContainer(containerId: ContainerId): Either<DockerAdapterExecuteCommandError, Unit>
    fun removeContainer(containerId: ContainerId)
    fun getContainerLogs(containerId: ContainerId): Either<DockerAdapterExecuteCommandError, ContainerLog>
    fun getContainerInfo(containerId: ContainerId): ContainerInfo?
    fun createVolumeIfNotExist(equipmentId: EquipmentId): Either<DockerAdapterExecuteCommandError, Unit>
    fun removeVolume(equipmentId: EquipmentId)
    fun getCppCompilerImageId(imageTag: String): List<String>
}

object DockerAdapterExecuteCommandError : BusinessError

data class ContainerInfo(
    val image: Image,
    val containerId: ContainerId,
    val state: ContainerState,
)

data class Image(
    val image: String,
    val tag: String
) {
    fun getImageTag() = "#[[\$]]#image:#[[\$]]#tag"
}

data class ContainerId(val id: String) {
    companion object {
        fun from(value: String): Either<InvalidContainerId, ContainerId> {
            return ContainerId(value).right()
        }
    }

}

data class ContainerLog(
    var logs: String
) {
    val buildResult = if (!logs.contains("STDERR") && logs.isNotBlank()) {
        BuildResult.SUCCESS
    } else {
        BuildResult.ERROR
    }
}

enum class BuildResult { SUCCESS, ERROR }

data class ContainerState(val value: State) {

    companion object {
        fun from(state: String): ContainerState {
            return when (state.lowercase(Locale.getDefault())) {
                "running" -> State.RUNNING
                "paused" -> State.PAUSED
                "exited" -> State.EXITED
                else -> State.EXITED
            }.let {
                ContainerState(it)
            }
        }
    }

    enum class State {
        RUNNING, EXITED, PAUSED
    }
}

object InvalidContainerId : BusinessError