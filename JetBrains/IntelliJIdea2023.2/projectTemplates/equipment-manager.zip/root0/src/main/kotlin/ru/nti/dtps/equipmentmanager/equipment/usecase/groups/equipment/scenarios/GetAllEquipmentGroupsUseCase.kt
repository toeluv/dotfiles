package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.scenarios

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.EquipmentGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.GetAllEquipmentGroups
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class GetAllEquipmentGroupsUseCase(
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider,
    private val equipmentGroupExtractor: EquipmentGroupExtractor
) : GetAllEquipmentGroups {
    override fun execute(): Collection<EquipmentGroup> {
        return equipmentGroupExtractor.getAllEquipmentGroupsByCompanyId(
            currentUserCompanyIdProvider.get()
        )
    }
}