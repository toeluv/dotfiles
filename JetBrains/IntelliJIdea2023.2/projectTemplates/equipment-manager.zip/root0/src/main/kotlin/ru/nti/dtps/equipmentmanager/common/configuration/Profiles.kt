package ru.nti.dtps.equipmentmanager.common.configuration

const val PROFILE_DEV = "dev"
const val PROFILE_PROD = "prod"
const val PROFILE_LOCAL = "local"
