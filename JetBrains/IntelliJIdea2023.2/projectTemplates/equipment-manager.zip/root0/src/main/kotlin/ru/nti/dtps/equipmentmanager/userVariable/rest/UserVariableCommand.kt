package ru.nti.dtps.equipmentmanager.userVariable.rest

import ru.nti.dtps.equipmentmanager.common.types.DataType
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.common.types.UserVariableId
import ru.nti.dtps.equipmentmanager.common.types.VariableName

data class CreateUserVariableCommand(
    val id: UserVariableId,
    val equipmentId: EquipmentId,
    val name: VariableName,
    val dataType: DataType
)

data class UpdateUserVariableCommand(
    val id: UserVariableId,
    val equipmentId: EquipmentId,
    val name: VariableName,
    val dataType: DataType
)

data class DeleteUserVariableCommand(
    val id: UserVariableId
)