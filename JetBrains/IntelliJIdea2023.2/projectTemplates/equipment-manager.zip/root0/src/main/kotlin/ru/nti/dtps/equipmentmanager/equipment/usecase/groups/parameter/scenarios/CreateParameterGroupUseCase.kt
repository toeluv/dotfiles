package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.ParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.ParameterGroupPersister
import ru.nti.dtps.equipmentmanager.equipment.rest.groups.CreateParameterGroupCommand
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.CreateParameterGroup
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.CreateParameterGroupUseCaseError
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.parameter.ParameterGroupAlreadyExists
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class CreateParameterGroupUseCase(
    private val parameterGroupPersister: ParameterGroupPersister,
    private val parameterGroupAlreadyExists: ParameterGroupAlreadyExists,
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider
) : CreateParameterGroup {
    override fun execute(command: CreateParameterGroupCommand): Either<CreateParameterGroupUseCaseError, ParameterGroup> {
        if (parameterGroupAlreadyExists(command.name)) {
            return CreateParameterGroupUseCaseError.ParameterGroupNameAlreadyExistUseCaseError(command.name).left()
        }
        val createdGroup = ParameterGroup.create(
            command.id,
            currentUserCompanyIdProvider.get().toStringValue(),
            command.name
        ).apply { parameterGroupPersister.save(this) }
        return createdGroup.right()
    }
}
