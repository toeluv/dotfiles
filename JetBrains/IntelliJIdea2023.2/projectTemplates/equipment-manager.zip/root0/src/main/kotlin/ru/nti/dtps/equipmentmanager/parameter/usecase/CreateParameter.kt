package ru.nti.dtps.equipmentmanager.parameter.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.parameter.domain.Parameter
import ru.nti.dtps.equipmentmanager.parameter.rest.CreateParameterCommand

interface CreateParameter {
    fun execute(command: CreateParameterCommand): Either<CreateParameterUseCaseError, Parameter>
}

sealed class CreateParameterUseCaseError {
    object ParameterHasInvalidValueFormatError : CreateParameterUseCaseError()
    object ParameterHasInvalidValueRangeError : CreateParameterUseCaseError()
    class ParameterNameAlreadyExistsError(val name: String) : CreateParameterUseCaseError()
    class VariableNameAlreadyExistsError(val name: String) : CreateParameterUseCaseError()
}