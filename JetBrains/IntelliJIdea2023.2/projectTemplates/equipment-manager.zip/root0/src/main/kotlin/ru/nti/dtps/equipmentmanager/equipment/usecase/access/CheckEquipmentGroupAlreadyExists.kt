package ru.nti.dtps.equipmentmanager.equipment.usecase.access

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.EquipmentGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.EquipmentGroupAlreadyExists
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class CheckEquipmentGroupAlreadyExists(
    private val equipmentGroupExtractor: EquipmentGroupExtractor,
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider
) : EquipmentGroupAlreadyExists {
    override fun invoke(equipmentGroupName: String): Boolean {
        return equipmentGroupExtractor.checkEquipmentGroupAlreadyExists(
            equipmentGroupName,
            currentUserCompanyIdProvider.get()
        )
    }
}