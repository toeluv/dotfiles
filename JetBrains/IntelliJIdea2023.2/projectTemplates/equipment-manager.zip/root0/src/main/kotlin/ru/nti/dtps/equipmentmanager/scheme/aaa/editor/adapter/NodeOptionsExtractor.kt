package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.NodeOptions
import java.util.*

interface NodeOptionsExtractor {
    fun extract(equipmentId: EquipmentId, nodeId: UUID): NodeOptions?
}