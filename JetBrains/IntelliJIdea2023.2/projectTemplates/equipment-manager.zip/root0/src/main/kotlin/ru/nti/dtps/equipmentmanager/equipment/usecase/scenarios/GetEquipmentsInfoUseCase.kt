package ru.nti.dtps.equipmentmanager.equipment.usecase.scenarios

import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.EquipmentGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.usecase.EquipmentsInfo
import ru.nti.dtps.equipmentmanager.equipment.usecase.GetEquipmentsInfo
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class GetEquipmentsInfoUseCase(
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider,
    private val equipmentExtractor: EquipmentExtractor,
    private val equipmentGroupExtractor: EquipmentGroupExtractor
) : GetEquipmentsInfo {
    override fun execute(): EquipmentsInfo {
        val companyId = currentUserCompanyIdProvider.get()
        val groups = equipmentGroupExtractor.getAllEquipmentGroupsByCompanyId(companyId)
        val equipmentsWithGroups = mutableListOf<EquipmentsInfo.EquipmentInfoView>()
        val equipmentsWithoutGroups = mutableListOf<EquipmentsInfo.EquipmentInfoView>()
        equipmentExtractor.getAllByCompanyId(companyId)
            .forEach { equipment ->
                groups.find { it.id == equipment.groupId }
                    ?.let { group ->
                    equipmentsWithGroups.add(
                        EquipmentsInfo.EquipmentInfoView(
                            id = equipment.id.toStringValue(),
                            name = equipment.name.toStringValue(),
                            group = group.name
                        )
                    )
                } ?: equipmentsWithoutGroups.add(
                    EquipmentsInfo.EquipmentInfoView(
                        id = equipment.id.toStringValue(),
                        name = equipment.name.toStringValue(),
                        group = null
                    )
                )

            }
        return EquipmentsInfo(
            equipmentsWithGroups = equipmentsWithGroups,
            equipmentsWithoutGroups = equipmentsWithoutGroups
        )
    }
}