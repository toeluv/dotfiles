package ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.scenarios

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.equipment.domain.EquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.persist.adapter.EquipmentExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.EquipmentGroupExtractor
import ru.nti.dtps.equipmentmanager.equipment.persist.groups.adapter.EquipmentGroupPersister
import ru.nti.dtps.equipmentmanager.equipment.rest.groups.DeleteEquipmentGroupCommand
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.DeleteEquipmentGroup
import ru.nti.dtps.equipmentmanager.equipment.usecase.groups.equipment.DeleteEquipmentGroupUseCaseError
import ru.nti.dtps.equipmentmanager.user.usecase.access.CurrentUserCompanyIdProvider

@Component
class DeleteEquipmentGroupUseCase(
    private val equipmentExtractor: EquipmentExtractor,
    private val equipmentGroupPersister: EquipmentGroupPersister,
    private val equipmentGroupExtractor: EquipmentGroupExtractor,
    private val currentUserCompanyIdProvider: CurrentUserCompanyIdProvider
) : DeleteEquipmentGroup {
    override fun execute(command: DeleteEquipmentGroupCommand): Either<DeleteEquipmentGroupUseCaseError, EquipmentGroup> {
        val allCompanyEquipments = equipmentExtractor.getAllByCompanyId(currentUserCompanyIdProvider.get())

        if (allCompanyEquipments.any { it.groupId == command.id }) {
            return DeleteEquipmentGroupUseCaseError.EquipmentGroupIsNotEmptyUseCaseError.left()
        }

        return equipmentGroupExtractor.getEquipmentGroupById(command.id)?.let { groupToDelete ->
            equipmentGroupPersister.delete(groupToDelete)
            groupToDelete.right()
        } ?: DeleteEquipmentGroupUseCaseError.EquipmentGroupNotExistUseCaseError.left()
    }
}