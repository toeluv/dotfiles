package ru.nti.dtps.equipmentmanager

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class EquipmentManagerApp

fun main(args: Array<String>) {
	runApplication<EquipmentManagerApp>(*args)
}
