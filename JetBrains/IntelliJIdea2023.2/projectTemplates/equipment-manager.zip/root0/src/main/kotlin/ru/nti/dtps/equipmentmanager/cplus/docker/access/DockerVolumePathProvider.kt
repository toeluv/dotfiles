package ru.nti.dtps.equipmentmanager.cplus.docker.access

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId

fun interface DockerVolumePathProvider {
    fun getFolderToMount(equipmentId: EquipmentId): String?
}

