package ru.nti.dtps.equipmentmanager.minio.configuration

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.stereotype.Component

@Component
@ConfigurationProperties(prefix = "minio.client")
data class MinioClientProperties(
    var host: String = "",
    var username: String = "",
    var password: String = ""
)
