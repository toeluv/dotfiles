package ru.nti.dtps.equipmentmanager.scheme.domain

import ru.nti.dtps.proto.scheme.link.EquipmentLink.AlignmentType

data class PrimitiveEquipmentLink(
    val id: String,
    val alignmentType: AlignmentType = AlignmentType.RECTANGULAR,
    val locked: Boolean = false,
    val selected: Boolean = false,
    val source: String,
    val target: String,
    val sourcePort: String,
    val targetPort: String,
    val points: List<Point> = listOf()
)