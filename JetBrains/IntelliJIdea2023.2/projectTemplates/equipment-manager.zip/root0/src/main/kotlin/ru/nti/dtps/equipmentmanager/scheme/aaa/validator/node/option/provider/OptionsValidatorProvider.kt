package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider

import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.PrimitiveEquipmentLibId
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.OptionFieldsValidator

interface OptionsValidatorProvider{
    fun get(type: PrimitiveEquipmentLibId): List<OptionFieldsValidator>
}