package ru.nti.dtps.equipmentmanager.common.configuration.kafka

import org.springframework.context.annotation.Configuration
import org.springframework.kafka.annotation.EnableKafka
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory
import org.springframework.kafka.core.ConsumerFactory
import org.springframework.kafka.core.DefaultKafkaConsumerFactory
import org.apache.kafka.clients.consumer.ConsumerConfig
import org.apache.kafka.common.serialization.StringDeserializer
import org.springframework.context.annotation.Bean
import org.springframework.kafka.listener.ContainerProperties
import ru.nti.dtps.equipmentmanager.user.kafka.UserEventDto
import ru.nti.dtps.equipmentmanager.user.kafka.UserEventDtoDeserializer

@EnableKafka
@Configuration
class ConsumersConfig(
    private val kafkaProperties: KafkaProperties,
    private val kafkaSaslProperties: KafkaSaslProperties
) {

    @Bean
    fun userEventKafkaListenerContainerFactory(): ConcurrentKafkaListenerContainerFactory<String, UserEventDto> {
        return createKafkaListenerContainerFactory(UserEventDtoDeserializer::class.java)
    }

    private fun <D, V> createKafkaListenerContainerFactory(deserializerClass: Class<D>):
            ConcurrentKafkaListenerContainerFactory<String, V> {
        val factory: ConsumerFactory<String, V> = DefaultKafkaConsumerFactory(
            mapOf(
                ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG to kafkaProperties.bootstrapServer,
                ConsumerConfig.GROUP_ID_CONFIG to kafkaProperties.consumerGroupId,
                ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG to StringDeserializer::class.java,
                ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG to deserializerClass,
                ConsumerConfig.AUTO_OFFSET_RESET_CONFIG to "latest"
            ) + kafkaSaslProperties.getSaslProperties()
        )

        return ConcurrentKafkaListenerContainerFactory<String, V>().apply {
            consumerFactory = factory
            containerProperties.ackMode = ContainerProperties.AckMode.MANUAL_IMMEDIATE
            containerProperties.isSyncCommits = true
        }
    }
}
