package ru.nti.dtps.equipmentmanager.scheme.usecase.commandHandler

import ru.nti.dtps.equipmentmanager.scheme.domain.command.Command

interface BaseCommandHandler {
    fun handle(command: Command)
    fun type(): Command
}