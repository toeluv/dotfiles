package ru.nti.dtps.equipmentmanager.scheme.usecase

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.scheme.domain.command.SchemeValidateCommand
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.SchemeValidationError

interface ValidateScheme {
    fun execute(command: SchemeValidateCommand): Either<SchemeValidationError, Unit>
}