package ru.nti.dtps.equipmentmanager.svg.domain

import ru.nti.dtps.equipmentmanager.svg.persist.dto.SignalInfoDto
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgDto
import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgInfoDto
import java.util.UUID

class SvgInfo private constructor(
    val id: UUID,
    var svgForScheme: ByteArray,
    var svgForLibrary: ByteArray,
    val coords: XyCoords,
    val dimensions: Dimensions,
    val hour: Int,
    val ports: List<SvgPort>,
    val placeholders: List<Placeholder>,
    val signalsFromMeasurement: List<SignalInfo>,
    val signalsFromScheme: List<SignalInfo>
) {

    companion object {
        fun create(
            id: UUID,
            svgForScheme: ByteArray,
            svgForLibrary: ByteArray,
            coords: XyCoords,
            dimensions: Dimensions,
            hour: Int,
            ports: List<SvgPort>,
            placeholders: List<Placeholder>,
            signalsFromMeasurement: List<SignalInfo>,
            signalsFromScheme: List<SignalInfo>
        ) = SvgInfo(
            id,
            svgForScheme,
            svgForLibrary,
            coords,
            dimensions,
            hour,
            ports,
            placeholders,
            signalsFromMeasurement,
            signalsFromScheme
        )
    }
}

fun SvgInfo.toSvgInfoDto() = SvgInfoDto(
    this.id,
    this.coords,
    this.dimensions,
    this.hour,
    this.ports,
    this.placeholders
)

fun SvgInfo.toSvgDto() = SvgDto(
    this.id,
    this.svgForScheme,
    this.svgForLibrary
)

fun SvgInfo.toSignalInfoDto() = SignalInfoDto.restore(
    this.id,
    this.signalsFromMeasurement,
    this.signalsFromScheme
)
