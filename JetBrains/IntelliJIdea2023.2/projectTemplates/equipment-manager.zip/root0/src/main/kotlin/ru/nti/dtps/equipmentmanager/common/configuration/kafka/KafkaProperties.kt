package ru.nti.dtps.equipmentmanager.common.configuration.kafka

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.stereotype.Component

@Component
@ConfigurationProperties(prefix = "kafka")
data class KafkaProperties(
    var producerName: String = "equipment-manager",
    var consumerGroupId: String = "equipment-manager",
    var bootstrapServer: String = ""
)
