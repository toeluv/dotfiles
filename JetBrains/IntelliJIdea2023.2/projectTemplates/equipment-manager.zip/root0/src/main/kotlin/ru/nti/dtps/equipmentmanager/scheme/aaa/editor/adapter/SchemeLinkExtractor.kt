package ru.nti.dtps.equipmentmanager.scheme.aaa.editor.adapter

import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.SchemeLink
import java.util.*

interface SchemeLinkExtractor {
    fun extract(equipmentId: EquipmentId, linkId: UUID): SchemeLink?
}