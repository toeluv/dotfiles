package ru.nti.dtps.equipmentmanager.scheme.domain.graphsearch

import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import java.util.*

class BreadthFirstSearch(
    private val scheme: Scheme
) {

    private val adjacencyMap = HashMap<String, HashSet<PrimitiveEquipment>>()

    val allVisitedNodesIds = mutableSetOf<String>()

    init {
        scheme.links.values.forEach { link ->
            val source = scheme.primitiveNodes[link.source] ?: return@forEach
            val target = scheme.primitiveNodes[link.target] ?: return@forEach
            adjacencyMap.getOrPut(source.id) { HashSet() }.add(target)
            adjacencyMap.getOrPut(target.id) { HashSet() }.add(source)
        }
    }

    fun walkThroughScheme(startNode: PrimitiveEquipment): Set<PrimitiveEquipment> {
        val visited = mutableSetOf<PrimitiveEquipment>()
        val queue = ArrayDeque<PrimitiveEquipment>()
        queue.add(startNode)
        while (queue.isNotEmpty()) {
            val vertex = queue.removeFirst()
            if (!visited.contains(vertex)) {
                visited.add(vertex)
                adjacencyMap[vertex.id]?.let { neighbors -> queue.addAll(neighbors.filterNot { it in visited }) }
            }
        }
        allVisitedNodesIds.addAll(visited.map { it.id })
        return visited
    }
}