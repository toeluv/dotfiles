package ru.nti.dtps.equipmentmanager.user.persist

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.CompanyId
import ru.nti.dtps.equipmentmanager.common.types.UserId
import ru.nti.dtps.equipmentmanager.user.domain.User
import ru.nti.dtps.equipmentmanager.user.persist.adapter.UserExtractor
import ru.nti.dtps.equipmentmanager.user.persist.adapter.UserPersister
import java.util.*
import javax.sql.DataSource

@Component
class UserRepository(
    dataSource: DataSource,
) : UserPersister, UserExtractor {

    private val jdbcTemplate = NamedParameterJdbcTemplate(dataSource)

    override fun getById(userId: UserId): User? {
        return jdbcTemplate.query(
            "SELECT * FROM public.user WHERE id = :id",
            mapOf("id" to userId.toUUID()),
            UserResultSetExtractor()
        )
    }

    override fun getAll(): List<User> {
        return jdbcTemplate.query(
            "SELECT * FROM public.user",
            UserRowMapper()
        )
    }

    override fun getAllByCompanyId(companyId: CompanyId): List<User> {
        return jdbcTemplate.query(
            "SELECT * FROM public.user WHERE company_id = :company_id",
            mapOf("company_id" to companyId.toUUID()),
            UserRowMapper()
        )
    }

    override fun save(user: User) {
        val params = mapOf(
            "id" to user.id.toUUID(),
            "company_id" to user.companyId.toUUID(),
            "first_name" to user.firstName,
            "last_name" to user.lastName,
            "removed" to user.removed
            )
        jdbcTemplate.update(
            """
            INSERT INTO public.user(id, company_id, first_name, last_name, removed)
            VALUES(
            :id, 
            :company_id,
            :first_name,
            :last_name,
            :removed)
        """.trimMargin(), params
        )
    }

    override fun saveUsersIfNotExist(users: List<User>) {
        saveAll(users.minus(getAll().toSet()))
    }

    override fun update(user: User) {
        val params = mapOf(
            "id" to user.id.toUUID(),
            "first_name" to user.firstName,
            "last_name" to user.lastName,
            )
        jdbcTemplate.update(
            """
            UPDATE public.user SET 
            first_name = :first_name,
            last_name = :last_name
            WHERE id = :id
            """.trimMargin(), params
        )
    }

    override fun markUserAsDeleted(userId: UserId) {
        jdbcTemplate.update(
            "UPDATE public.user SET removed = true WHERE id = :id",
            mapOf("id" to userId.toUUID())
        )
    }

    private fun saveAll(users: Collection<User>) {
        jdbcTemplate.batchUpdate(
            """
            INSERT INTO public.user(id, company_id, first_name, last_name, removed)
            VALUES(
            :id, 
            :companyId,
            :firstName,
            :lastName,
            :removed)
            """.trimMargin(),
            SqlParameterSourceUtils.createBatch(users.map {
                UserBatchInsertData(
                    it.id.toUUID(),
                    it.companyId.toUUID(),
                    it.firstName,
                    it.lastName
                )
            }
            )
        )
    }
}

data class UserBatchInsertData(
    val id: UUID,
    val companyId: UUID,
    val firstName: String,
    val lastName: String,
    val removed: Boolean = false
)
