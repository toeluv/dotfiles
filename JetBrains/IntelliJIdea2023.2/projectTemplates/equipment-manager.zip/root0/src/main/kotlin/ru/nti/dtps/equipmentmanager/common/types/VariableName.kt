package ru.nti.dtps.equipmentmanager.common.types

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import ru.nti.dtps.equipmentmanager.common.error.BusinessError
import java.util.regex.Pattern

data class VariableName(
    val name: String
) {
    companion object {
        fun from(name: String): Either<CreateVariableNameError, VariableName> =
            if (Pattern.compile(
                    "^[a-z][-a-z0-9_]*\\\#[[\$]]#?\#[[\$]]#",
                    Pattern.CASE_INSENSITIVE
                )
                    .matcher(name).matches()
            ) {
                VariableName(name).right()
            } else {
                CreateVariableNameError.EmptyVariableName.left()
            }
    }

    fun toStringValue() = name

}

sealed class CreateVariableNameError : BusinessError {
    object EmptyVariableName : CreateVariableNameError()
}