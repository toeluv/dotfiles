package ru.nti.dtps.equipmentmanager.svg.persist.adapter

import ru.nti.dtps.equipmentmanager.svg.persist.dto.SvgDto
import java.util.*

interface SvgPersister {
    fun save(svgDto: SvgDto)
    fun update(svgDto: SvgDto)
    fun delete(id: UUID)
}