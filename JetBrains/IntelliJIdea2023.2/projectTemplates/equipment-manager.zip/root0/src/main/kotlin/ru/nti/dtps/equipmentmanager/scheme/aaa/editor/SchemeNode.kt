package ru.nti.dtps.equipmentmanager.scheme.aaa.editor

import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import java.util.*

class SchemeNode(
    val id: UUID,
    val parentId: UUID,
    val type: PrimitiveEquipment.PrimitiveEquipmentLibId,
    val ports: List<Port>,
    val hour: Int = 0,
    val coords: XyCoords,
    val dimensions: Dimensions,
    val payload: Map<String, String>,
)

data class Dimensions(
    val height: Double = 0.0,
    val width: Double = 0.0
)

data class XyCoords(
    val x: Double = 0.0,
    val y: Double = 0.0
)