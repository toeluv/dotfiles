package ru.nti.dtps.equipmentmanager.scheme.domain.validator.node

import arrow.core.Either
import arrow.core.getOrElse
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.common.types.VariableName
import ru.nti.dtps.equipmentmanager.equipment.usecase.VariableNameAlreadyExists
import ru.nti.dtps.equipmentmanager.scheme.domain.OptionLibId
import ru.nti.dtps.equipmentmanager.scheme.domain.PrimitiveEquipment
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme
import ru.nti.dtps.equipmentmanager.scheme.domain.SchemeEditorError
import ru.nti.dtps.equipmentmanager.scheme.domain.validator.node.type.CustomValidator
import ru.nti.dtps.equipmentmanager.scheme.usecase.VariableNameOnSchemeAlreadyExist

@Component
class VariableNameOptionValidator(
    private val variableNameAlreadyExists: VariableNameAlreadyExists,
    private val variableNameOnSchemeAlreadyExist: VariableNameOnSchemeAlreadyExist,
) : CustomValidator {

    override fun validate(node: PrimitiveEquipment, scheme: Scheme): Either<SchemeEditorError, Unit> {
        val variableNameOptionValue = node.options[OptionLibId.VARIABLE_NAME]
            ?: return SchemeEditorError.RequiredFieldNotFoundError(node.id, node.name, OptionLibId.VARIABLE_NAME).left()

        val validVariableName = VariableName.from(variableNameOptionValue).getOrElse {
            return SchemeEditorError.VariableNameOptionIsNotValidOrUniqueError(variableNameOptionValue).left()
        }

        return if (variableNameAlreadyExists(validVariableName, scheme.id) ||
            variableNameOnSchemeAlreadyExist.invoke(validVariableName, scheme.id)
        ) {
            SchemeEditorError.VariableNameOptionIsNotValidOrUniqueError(variableNameOptionValue).left()
        } else {
            Unit.right()
        }
    }
}
