package ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.node

import arrow.core.Either
import ru.nti.dtps.equipmentmanager.common.types.EquipmentId
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.PrimitiveEquipmentLibId
import ru.nti.dtps.equipmentmanager.scheme.aaa.validator.node.option.provider.OptionLibId
import java.util.*

interface BusinessNodeValidator {
    fun validate(
        node: NodeToValidate,
    ): Either<NodeValidationError, Unit>
    fun order(): Int
}

interface AffectedByNodeTypeValidator{
    fun type(): PrimitiveEquipmentLibId
}

interface AffectedByOptionLibIdValidator{
    fun option(): OptionLibId
}

interface NodeToValidate{
    fun id(): UUID
    fun equipmentId(): EquipmentId
    fun options(): Map<OptionLibId, String?>
    fun type(): PrimitiveEquipmentLibId
}

interface NodeValidationError

data class InvalidNodeValue(val nodeId: UUID, val equipmentId: EquipmentId, val option: OptionLibId): NodeValidationError
data class UnknownNodeValidationError(val nodeId: UUID, val equipmentId: EquipmentId): NodeValidationError