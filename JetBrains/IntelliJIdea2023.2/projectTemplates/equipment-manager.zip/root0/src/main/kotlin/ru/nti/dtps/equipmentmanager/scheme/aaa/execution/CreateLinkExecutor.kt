package ru.nti.dtps.equipmentmanager.scheme.aaa.execution

import arrow.core.Either
import arrow.core.right
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.aaa.command.*
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.CreateSchemeLinkEditorCommand
import ru.nti.dtps.equipmentmanager.scheme.aaa.editor.EditorCommand

@Component
class CreateLinkExecutor : CommandExecutor<CreateLinkUserCommand> {

    private val logger = LoggerFactory.getLogger(CreateLinkExecutor::class.java)

    override fun execute(command: CreateLinkUserCommand): Either<CommandExecutionError, CreateLinkUserCommandSuccessResult> {
        return CreateLinkUserCommandSuccessResult(command).right()
    }
}

class CreateLinkUserCommandSuccessResult(
    val command: CreateLinkUserCommand
) : CommandSuccessResult {
    override fun undo() = DeleteLinkUserCommand(
        nodeId = command.nodeId,
        equipmentId = command.equipmentId,
        body = DeleteLink(
            id = command.nodeId
        )
    )

    override fun editorCommands(): List<EditorCommand> {
        return listOf(
            CreateSchemeLinkEditorCommand.build(command),
        )
    }
}