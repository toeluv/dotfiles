package ru.nti.dtps.equipmentmanager.scheme.domain.validator

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import org.springframework.stereotype.Component
import ru.nti.dtps.equipmentmanager.scheme.domain.Scheme

@Component
class LinkConnectingPortValidator : AbstractSchemeValidator(Level.THIRD) {
    override fun validate(scheme: Scheme): Either<SchemeValidationError, Unit> {
        val portsOnScheme = scheme.primitiveNodes.values
            .flatMap { equipment ->
                equipment.ports.map { port ->
                    port.id
                }
            }

        val portsInLinks =
            (scheme.links.values.map { it.sourcePort } + scheme.links.values.map { it.targetPort }).toSet()

        if (portsOnScheme.any { !portsInLinks.contains(it) }) {
            return SchemeConnectionValidationError.SchemeContainsBlankPortConnection.left()
        }

        return Unit.right()
    }
}

sealed class SchemeConnectionValidationError : SchemeValidationError {
    object SchemeContainsBlankPortConnection : SchemeConnectionValidationError()
}