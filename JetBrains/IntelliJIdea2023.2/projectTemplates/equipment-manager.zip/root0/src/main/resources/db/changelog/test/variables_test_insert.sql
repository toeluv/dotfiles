/*
* insert one equipment containing variables: parameter_variable, input_variable, output_variable, user_variable
*/

INSERT INTO public.equipment (id, company_id, name, group_id, description, published, published_at, author_of_publish,
                              version, author, created_at, editor, updated_at)
VALUES ('123e4567-e89b-12d3-a456-426614174000', '987e4567-e89b-12d3-a456-426614174000', 'Test Equipment', null,
        'This is an example equipment', true, '2023-04-25 12:00:00', 'Publisher', 1, 'Creator', '2023-04-25 10:00:00',
        'Editor', '2023-04-25 11:00:00');

INSERT INTO public.equipment_parameter (id, equipment_id, name, group_id, unit_type, data_type, min_value, max_value,
                                        default_value, variable_name)
VALUES ('123e4567-e89b-12d3-a456-426614174100', '123e4567-e89b-12d3-a456-426614174000', 'Example Parameter', null,
        'AMPERE', 'INTEGER', '0', '100', '50', 'parameter_variable');

INSERT INTO public.input_signal (id, equipment_id, name, unit_type, data_type, variable_name)
VALUES ('123e4562-e89b-12d3-a452-426614174000', '123e4567-e89b-12d3-a456-426614174000', 'Example Input Signal',
        'VOLT', 'FLOAT', 'input_variable');

INSERT INTO public.output_signal (id, equipment_id, name, unit_type, data_type, variable_name)
VALUES ('123e4562-e89b-12d3-a456-426614174000', '123e4567-e89b-12d3-a456-426614174000', 'Example Output Signal',
        'VOLT', 'FLOAT', 'output_variable');

INSERT INTO public.user_variable (id, equipment_id, variable_name, data_type)
VALUES ('123e4567-e89b-12d3-a456-426614174001', '123e4567-e89b-12d3-a456-426614174000', 'user_variable', 'INTEGER');