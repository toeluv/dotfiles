alter table equipment
drop constraint fk_equipments_group_id;

alter table equipment
    add constraint fk_equipments_group_id
        foreign key (group_id) references groups
            on update cascade on delete set null;